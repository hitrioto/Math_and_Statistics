"""Binary metrics: spam is the positive class (1)."""

def divide(numerator, denominator):
    # Report 0 when a metric has no applicable cases, rather than dividing by 0.
    return numerator / denominator if denominator else 0.0


def calculate_metrics(actual_labels, predictions):
    # Rows are actual labels; columns are predicted labels. Order: ham, spam.
    matrix = [[0, 0], [0, 0]]
    for actual, predicted in zip(actual_labels, predictions, strict=True):
        matrix[actual][predicted] += 1

    true_negative, false_positive = matrix[0]
    false_negative, true_positive = matrix[1]
    total = true_negative + false_positive + false_negative + true_positive
    metrics = {
        "Accuracy": divide(true_positive + true_negative, total),
        "Spam precision": divide(true_positive, true_positive + false_positive),
        "Spam recall": divide(true_positive, true_positive + false_negative),
        "Spam F1": divide(2 * true_positive, 2 * true_positive + false_positive + false_negative),
        "False-positive rate": divide(false_positive, false_positive + true_negative),
    }
    return matrix, metrics


