"""Paths are relative to this project, not the terminal's working directory."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW_PATH = ROOT / 'data/raw'
PREPARED_PATH = ROOT / 'data/prepared/prepared_emails.jsonl'
TRAIN_PATH = ROOT / 'data/splits/train_emails.jsonl'
TEST_PATH = ROOT / 'data/splits/test_emails.jsonl'
MODEL_PATH = ROOT / 'models/manual_naive_bayes.json'
REPORTS_PATH = ROOT / 'reports'
