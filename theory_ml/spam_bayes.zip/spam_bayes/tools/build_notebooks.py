"""Build two lesson notebooks. Execute separately to populate their outputs."""
from pathlib import Path
from textwrap import dedent

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / 'notebooks'


def md(text):
    return nbf.v4.new_markdown_cell(dedent(text).strip())


def code(text):
    return nbf.v4.new_code_cell(dedent(text).strip())


def setup(lesson):
    return code('''
        from pathlib import Path
        from collections import Counter
        import json
        import math
        import os
        import sys

        def locate_project():
            for parent in [Path.cwd(), *Path.cwd().parents]:
                for candidate in [parent, parent / "spam_bayes"]:
                    if (candidate / "naive_bayes.py").exists() and (candidate / "data/splits/train_emails.jsonl").exists():
                        return candidate
            raise FileNotFoundError("Open the notebook inside the exercise workspace.")

        PROJECT = locate_project()
        OUTPUT = PROJECT / "notebooks/outputs/LESSON"
        OUTPUT.mkdir(parents=True, exist_ok=True)
        os.environ["MPLCONFIGDIR"] = str(OUTPUT / "matplotlib_cache")
        sys.path.insert(0, str(PROJECT))

        import numpy as np
        import pandas as pd
        import matplotlib.pyplot as plt
        from IPython.display import display
        from dataset_utils import load_records, split_records, check_split, word_count_key
        from naive_bayes import NaiveBayesSpamFilter
        from evaluation import calculate_metrics

        print("Python:", sys.executable)
        print("Project:", PROJECT)
        print("Notebook outputs:", OUTPUT)
    '''.replace('LESSON', lesson))


def first_notebook():
    return [
        md('''
        # From raw email to manual Naive Bayes

        **Goal:** explain how an email becomes word counts and how those counts become a classification.
        Basic Python, dictionaries and logarithms are helpful; the small worked example introduces the mathematics.

        **Route:** inspect a message → prepare text → preserve the split → work through a tiny model → fit the real training data.
        This lesson follows scripts **01–04**. Run cells from top to bottom with the shared `.venv` kernel.
        It fits demonstrations in memory and writes only under `notebooks/outputs/01_email_to_naive_bayes/`.
        The saved model, reports and dataset are not overwritten.

        The corpus is historical SpamAssassin email. **0 = ham (legitimate mail), 1 = spam.**
        We use `easy_ham` and `spam`; `hard_ham` and `spam_2` remain later extensions.
        The original test set was already examined. Reproducing the existing split does not make it a fresh test.
        '''),
        md('''
        ## 1. Find the project and check the interpreter

        Confirm that the printed interpreter is the shared `.venv/Scripts/python.exe`.
        Paths are found from the workspace, project or notebook directory.
        The imports reuse the scripts' tested functions; the important modelling calculations remain visible below.
        '''),
        setup('01_email_to_naive_bayes'),
        md('''
        ## 2. What is inside a raw email?

        Count only digit-prefixed message filenames, excluding `cmds` metadata.
        We inspect one training email, so the demonstration does not select a test example.
        Notice the blank line separating headers and body, and the MIME content types.
        '''),
        code('''
        from email import policy
        from email.parser import BytesParser

        train = load_records(PROJECT / "data/splits/train_emails.jsonl")
        counts = []
        for subset in ["easy_ham", "spam", "hard_ham", "spam_2"]:
            folder = PROJECT / "data/raw" / subset
            count = sum(path.is_file() and path.name[0].isdigit() for path in folder.iterdir())
            counts.append({"subset": subset, "emails": count, "used_for_baseline": subset in ["easy_ham", "spam"]})
        display(pd.DataFrame(counts))

        example_path = PROJECT / "data/raw" / train[0]["source"]
        raw = example_path.read_bytes()
        message = BytesParser(policy=policy.default).parsebytes(raw)
        print("Training source:", train[0]["source"])
        print(raw.decode("utf-8", errors="replace")[:1500])
        display(pd.DataFrame([{"type": part.get_content_type(),
                               "charset": part.get_content_charset(),
                               "disposition": part.get_content_disposition()}
                              for part in message.walk()]))
        '''),
        md('''
        ## 3. Choose text deliberately

        The shared preparation function uses the decoded subject plus **one** body. It prefers plain text,
        falls back to HTML text, and excludes attachments. This avoids counting both versions of a multipart alternative.
        HTML extraction ignores head/script/style/template content, but does not interpret CSS visibility.

        Tokenization lowercases text and keeps matches of `[a-z]{2,}`. This simple English-oriented baseline
        discards numbers and single-letter words and loses some multilingual clues. It retains stopwords,
        signatures and quoted replies. A charset fallback is a decoding choice, not necessarily an error.
        No vocabulary is learned at this stage.
        '''),
        code('''
        import re
        from email_preparation import prepare_email, html_to_text

        prepared, fallback = prepare_email(example_path, train[0]["source"].split("/")[0])
        assert prepared == train[0], "Prepared example differs from the saved training record."
        print("Subject:", prepared["subject"])
        print("Prepared text:", prepared["text"][:1000])
        print("First 30 tokens:", prepared["tokens"][:30])
        print("Charset fallback:", fallback)
        print("Small token example:", re.findall(r"[a-z]{2,}", "FREE offer: win 100 prizes!".lower()))
        print("Small HTML example:", html_to_text("<style>hidden</style><p>Hello <b>world</b></p>"))

        preparation_report = json.loads((PROJECT / "reports/preparation.json").read_text(encoding="utf-8"))
        display(pd.Series(preparation_report["counts"], name="Recorded preparation counts"))
        '''),
        md('''
        ## 4. Preserve the split and prevent duplicate leakage

        Word order does not matter to this classifier, but word frequency does. Messages with identical word counts
        stay in the same partition. Grouping catches exact feature duplicates, not every related message or conversation.
        The split is stratified by label with seed 42 and 20% testing; whole groups can prevent exact proportions in other datasets.

        The following cell recreates the original split **in memory** and verifies membership and order.
        Reading test membership for this check is not an invitation to tune on test performance.
        '''),
        code('''
        prepared_records = load_records(PROJECT / "data/prepared/prepared_emails.jsonl")
        reproduced_train, reproduced_test = split_records(prepared_records, test_size=0.20, seed=42)
        check_split(prepared_records, reproduced_train, reproduced_test)
        saved_test = load_records(PROJECT / "data/splits/test_emails.jsonl")
        assert reproduced_train == train
        assert reproduced_test == saved_test
        display(pd.DataFrame([
            {"partition": name, "emails": len(records),
             "ham": sum(r["label"] == 0 for r in records), "spam": sum(r["label"] == 1 for r in records)}
            for name, records in [("training", train), ("test", saved_test)]
        ]))
        a = {"tokens": ["win", "prize", "win"]}
        b = {"tokens": ["prize", "win", "win"]}
        print("Same word-count group:", word_count_key(a) == word_count_key(b))
        '''),
        md(r'''
        ## 5. Work through a tiny training set

        For class $c$, let $N_c$ be its email count, $T_c$ its total token count, $n_{w,c}$ a word's count,
        and $|V|$ the training vocabulary size. With additive smoothing $α=1$:

        $$P(c)=N_c/N, \qquad P(w\mid c)=\frac{n_{w,c}+\alpha}{T_c+\alpha |V|}.$$

        Smoothing gives a known word a nonzero likelihood even when it never appeared in one class.
        It does not add words from future messages to the vocabulary. The toy counts below are small enough to check by hand.
        '''),
        code('''
        toy = [
            {"label": 0, "tokens": ["meeting", "today"]},
            {"label": 0, "tokens": ["meeting", "hello"]},
            {"label": 1, "tokens": ["win", "prize", "win"]},
        ]
        toy_model = NaiveBayesSpamFilter(alpha=1.0)
        toy_model.fit(toy)
        rows = []
        for label in [0, 1]:
            total = sum(toy_model.word_counts[label].values())
            for word in sorted(toy_model.vocabulary):
                count = toy_model.word_counts[label][word]
                probability = (count + toy_model.alpha) / (total + toy_model.alpha * len(toy_model.vocabulary))
                assert math.isclose(math.log(probability), toy_model.log_word_probabilities[label][word])
                rows.append({"class": "ham" if label == 0 else "spam", "word": word,
                             "count": count, "class_token_total": total, "P(word | class)": probability})
        display(pd.DataFrame(rows).round(4))
        print("Priors:", toy_model.class_priors)
        '''),
        md(r'''
        ## 6. Add log contributions to classify a message

        For message word counts $x_w$, score each class:

        $$s_c=\log P(c)+\sum_{w\in V}x_w\log P(w\mid c).$$

        Choose spam when its score is larger, otherwise ham. An exact tie goes to ham.
        Logs replace products of tiny values with sums. These are **unnormalized log scores**, not probabilities.
        The conditional-independence assumption is a useful simplification; words in real email are not independent.
        '''),
        code('''
        message_tokens = ["win", "win", "today", "unknown"]
        contributions = []
        manual_scores = {}
        for label in [0, 1]:
            score = toy_model.log_priors[label]
            contributions.append({"class": label, "term": "log prior", "contribution": score})
            for word, count in Counter(message_tokens).items():
                contribution = count * toy_model.log_word_probabilities[label].get(word, 0.0)
                contributions.append({"class": label, "term": f"{count} x {word}", "contribution": contribution})
                score += contribution
            manual_scores[label] = score
        display(pd.DataFrame(contributions).round(4))
        assert manual_scores == toy_model.predict_log_scores(message_tokens)
        print("Scores:", manual_scores, "Prediction:", toy_model.predict(message_tokens))
        print("Empty message:", toy_model.predict_log_scores([]))
        print("Only unknown words:", toy_model.predict_log_scores(["unknown"]))
        '''),
        md('''
        **Pause and explain:** Why does `win` contribute twice? Why does `unknown` contribute zero?
        Why do empty/no-known-word messages use only priors? Try changing the toy tokens or alpha,
        then rerun the toy cells. These examples are safe places to explore without choosing settings on test data.

        ## 7. Fit the real training data in memory

        We now use the same manual implementation with fixed alpha=1. Read `naive_bayes.py` alongside this section:
        its loops implement exactly the calculation above. Training examples illustrate predictions; they do not measure generalization.
        '''),
        code('''
        model = NaiveBayesSpamFilter(alpha=1.0)
        model.fit(train)
        display(pd.DataFrame([
            {"class": label, "emails": model.class_counts[label], "prior": model.class_priors[label],
             "token_total": sum(model.word_counts[label].values())} for label in [0, 1]
        ]))
        print("Training vocabulary:", len(model.vocabulary))
        display(pd.DataFrame([
            {"source": r["source"], "actual": r["label"], "predicted": model.predict(r["tokens"]),
             "subject": r["subject"][:90]} for r in train[:5]
        ]))
        summary = {"training_emails": len(train), "vocabulary_size": len(model.vocabulary),
                   "alpha": model.alpha, "class_priors": model.class_priors}
        (OUTPUT / "training_demonstration.json").write_text(json.dumps(summary, indent=2) + "\\n", encoding="utf-8")
        '''),
        md('''
        ## 8. What have we learned?

        - Preparation is a set of choices, not neutral housekeeping. We have made its losses explicit.
        - Vocabulary and word probabilities are learned from training data only.
        - Naive Bayes adds log evidence from token counts to class priors.
        - An impressive training example is not evidence of held-out performance.

        **Next:** open [02_evaluation_and_experiments.ipynb](02_evaluation_and_experiments.ipynb) for metrics,
        actual errors, sklearn equivalence and training-only validation experiments. It runs independently of this kernel.
        For the decisions behind the baseline, see [development_decisions.txt](../development_decisions.txt).
        '''),
    ]


def second_notebook():
    return [
        md('''
        # Evaluate, verify and compare the spam classifiers

        **Goal:** distinguish spam detection from incorrectly blocking good mail, verify the manual model against
        sklearn, and compare model choices without using test results for selection.

        This independent notebook follows scripts **05–07**. It loads the saved fixed baseline and reproduces its
        **previously examined historical test results**. These are not a new untouched holdout evaluation.
        The second half uses only the original training partition for fitting and validation.
        It does not automatically choose a winner or replace the saved model.

        Run top to bottom using the shared `.venv`. Notebook files are written only under
        `notebooks/outputs/02_evaluation_and_experiments/`. For a new modelling project, choose settings within
        training data first, freeze them, and only then use the reserved test set.
        '''),
        md('## 1. Set up an independent session'),
        setup('02_evaluation_and_experiments'),
        md('''
        ## 2. Load the fixed baseline and reproduce its historical predictions

        The model loader checks hashes for the training data and core model/preparation code.
        If it reports stale artifacts, rerun the affected numbered scripts before using this lesson.
        We verify alignment with the saved predictions and metrics so mismatched reports do not silently enter the lesson.
        '''),
        code('''
        from artifacts import load_model
        from sklearn_models import fit_sklearn, run_experiment

        train = load_records(PROJECT / "data/splits/train_emails.jsonl")
        test = load_records(PROJECT / "data/splits/test_emails.jsonl")
        model = load_model()
        labels = [r["label"] for r in test]
        predictions = [model.predict(r["tokens"]) for r in test]
        prediction_table = pd.DataFrame({"source": [r["source"] for r in test],
                                         "actual": labels, "predicted": predictions})
        saved_predictions = pd.read_csv(PROJECT / "reports/test_predictions.csv")
        pd.testing.assert_frame_equal(prediction_table, saved_predictions)
        matrix, metrics = calculate_metrics(labels, predictions)
        historical = json.loads((PROJECT / "reports/evaluation.json").read_text(encoding="utf-8"))
        assert matrix == historical["confusion_matrix"]
        assert metrics == historical["metrics"]
        print("Reproduced predictions:", len(predictions), "Fixed alpha:", model.alpha)
        '''),
        md('''
        ## 3. Read the confusion matrix before the percentages

        Rows are actual labels and columns are predicted labels; **spam is positive**.
        A false positive blocks legitimate email. A false negative allows spam through.
        These errors have different consequences, so accuracy alone is insufficient.
        '''),
        code('''
        fig, ax = plt.subplots(figsize=(5.5, 4))
        ax.imshow(matrix, cmap="Blues")
        ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["Ham", "Spam"],
               yticklabels=["Ham", "Spam"], xlabel="Predicted", ylabel="Actual",
               title="Historical test: fixed manual baseline")
        for row in range(2):
            for column in range(2):
                ax.text(column, row, str(matrix[row][column]), ha="center", va="center",
                        color="white" if matrix[row][column] > 250 else "black", fontsize=18)
        fig.tight_layout()
        fig.savefig(OUTPUT / "confusion_matrix.png", dpi=150)
        plt.show()
        tn, fp = matrix[0]
        fn, tp = matrix[1]
        print(f"Detected {tp}/{tp + fn} spam messages; blocked {fp}/{tn + fp} legitimate messages.")
        '''),
        md('''
        ## 4. Compare metrics with a trivial baseline

        Precision = TP / (TP + FP): of messages flagged as spam, how many were spam?
        Recall = TP / (TP + FN): of actual spam, how much did we detect?
        False-positive rate = FP / (FP + TN): how much legitimate mail did we block?
        F1 balances precision and recall; it does not encode a business cost.
        Undefined ratios are reported as zero by our helper; always look at the counts.

        Always predicting ham has high accuracy in this imbalanced dataset and detects no spam.
        '''),
        code('''
        _, always_ham = calculate_metrics(labels, [0] * len(labels))
        metric_table = pd.DataFrame({"Manual baseline": metrics, "Always ham": always_ham})
        display(metric_table.map(lambda value: f"{value:.2%}"))
        metric_table.to_csv(OUTPUT / "historical_metrics.csv")
        '''),
        md('''
        **Interpretation:** the fixed baseline detects 89 of 100 spam messages and misses 11.
        It blocks none of the 500 legitimate messages in this particular sample.
        Zero observed false positives does not establish a zero future false-positive rate or perfect future precision.
        The historical corpus and remaining related messages also limit generalization.

        ## 5. Read actual errors

        Inspect a few missed messages as a description of this baseline. Do not turn these test examples into a
        feature-tuning checklist. New feature choices should be investigated on training/validation examples.
        Email text below is displayed as plain text, not rendered HTML.
        '''),
        code('''
        errors = [r for r, p in zip(test, predictions, strict=True) if r["label"] != p]
        error_table = pd.DataFrame([
            {"source": r["source"], "actual": r["label"], "subject": r["subject"][:100],
             "token_count": len(r["tokens"]),
             "known_token_fraction": sum(t in model.vocabulary for t in r["tokens"]) / max(1, len(r["tokens"]))}
            for r in errors
        ])
        display(error_table.head(5))
        if errors:
            print("First misclassified message, excerpt:")
            print(errors[0]["text"][:1200])
        print("Total errors:", len(errors))
        '''),
        md('''
        ## 6. Verify the mathematics against sklearn

        Both implementations must use the same training vocabulary, token counts, alpha and priors.
        The custom analyzer takes our saved tokens directly. Default sklearn text preprocessing would change the comparison.
        Compare unnormalized class scores; `predict_log_proba` returns normalized values and is not the same quantity.
        '''),
        code('''
        vectorizer, library_model = fit_sklearn(model, train)
        test_tokens = [r["tokens"] for r in test]
        X_test = vectorizer.transform(test_tokens)
        library_predictions = library_model.predict(X_test)
        manual_scores = np.array([[model.predict_log_scores(tokens)[c] for c in [0, 1]] for tokens in test_tokens])
        library_scores = X_test @ library_model.feature_log_prob_.T + library_model.class_log_prior_
        np.testing.assert_array_equal(predictions, library_predictions)
        np.testing.assert_allclose(manual_scores, library_scores, rtol=1e-10, atol=1e-8)
        print(f"Matching predictions: {np.sum(library_predictions == predictions)}/{len(test)}")
        print("Largest absolute log-score difference:", np.abs(manual_scores - library_scores).max())
        '''),
        md('''
        Agreement supports correctness of the implementation under these assumptions.
        It does not prove that the representation or model is suitable for current email traffic.

        ## 7. Start a separate validation exercise inside training

        From here onward, model comparisons use only the original training records.
        Split them into 80% fitting and 20% validation using the same grouping rule and seed 42.
        Vocabulary and priors are learned on the fitting portion, never on validation.
        This leaves 1,920 fitting emails and 480 validation emails.
        '''),
        code('''
        fitting, validation = split_records(train, test_size=0.20, seed=42)
        check_split(train, fitting, validation)
        validation_labels = [r["label"] for r in validation]
        saved_validation = json.loads((PROJECT / "reports/validation.json").read_text(encoding="utf-8"))
        assert [r["source"] for r in fitting] == saved_validation["fitting_sources"]
        assert [r["source"] for r in validation] == saved_validation["validation_sources"]
        display(pd.DataFrame([
            {"partition": name, "emails": len(records), "spam": sum(r["label"] for r in records)}
            for name, records in [("fitting", fitting), ("validation", validation)]
        ]))
        '''),
        md('''
        ## 8. Change one choice at a time

        - **Smoothing:** compare alpha 0.1, 1 and 10 with all fitting words.
        - **Vocabulary:** keep the 1,000 or 5,000 most frequent fitting words, or all words, at alpha=1.
        - **Model:** compare Multinomial counts with Bernoulli presence **and absence**, at alpha=1 with all words.

        This is a teaching comparison, not a joint grid search. The baseline appears in each group to show what changed.
        No automatic winner is selected. Inspect `sklearn_models.run_experiment` for vocabulary construction and fitting.
        '''),
        code('''
        settings = [
            ("smoothing", "alpha=0.1", {"alpha": 0.1}),
            ("smoothing", "alpha=1", {"alpha": 1.0}),
            ("smoothing", "alpha=10", {"alpha": 10.0}),
            ("vocabulary", "top 1000 words", {"max_words": 1000}),
            ("vocabulary", "top 5000 words", {"max_words": 5000}),
            ("vocabulary", "all words", {}),
            ("model", "MultinomialNB", {}),
            ("model", "BernoulliNB", {"bernoulli": True}),
        ]
        results = []
        for group, name, options in settings:
            predicted, size = run_experiment(fitting, validation, **options)
            _, scores = calculate_metrics(validation_labels, predicted)
            results.append({"experiment": group, "setting": name, "vocabulary_size": size, **scores})
        comparison = pd.DataFrame(results)
        saved_comparison = pd.read_csv(PROJECT / "reports/validation_experiments.csv")
        pd.testing.assert_frame_equal(comparison, saved_comparison, check_exact=False, rtol=1e-12, atol=1e-12)
        display(comparison.round(4))
        comparison.to_csv(OUTPUT / "validation_comparison.csv", index=False)
        '''),
        md('''
        ## 9. Compare detection and false alarms together

        Percentages in the table above are stored as proportions. The chart uses percentages.
        A high precision value alone can conceal poor recall; check the alpha=10 and Bernoulli rows.
        One additional detected spam message moves validation recall by 1.25 percentage points;
        one falsely blocked legitimate message moves FPR by 0.25 percentage points.
        '''),
        code('''
        fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
        names = comparison["experiment"] + ": " + comparison["setting"]
        positions = np.arange(len(comparison))
        axes[0].barh(positions, 100 * comparison["Spam recall"], color="#246b8e")
        axes[1].barh(positions, 100 * comparison["False-positive rate"], color="#c07635")
        axes[0].set_yticks(positions, names)
        axes[0].invert_yaxis()
        axes[0].set(xlabel="Spam detected (%)", xlim=(0, 100))
        axes[1].set(xlabel="Legitimate email blocked (%)", xlim=(0, 1))
        for ax in axes:
            ax.grid(axis="x", alpha=0.2)
        fig.suptitle("Training-only validation: one setting changes at a time")
        fig.tight_layout()
        fig.savefig(OUTPUT / "validation_tradeoffs.png", dpi=150)
        plt.show()
        '''),
        md('''
        ## 10. What can we conclude?

        The 5,000-word variant has the strongest F1 in this particular comparison. That makes it a candidate
        for further validation, not an automatically approved replacement. Rankings can change with another split.
        Bernoulli performs poorly here; this does not prove that it is always inferior for text classification.

        **Discuss before extending the model:**
        1. Is missing spam or blocking legitimate email more costly? Would uncertain cases go to a review folder?
        2. Which validation design would give more confidence in the apparent vocabulary improvement?
        3. How would we check duplicate overlap before using `hard_ham` or `spam_2` as additional evaluation data?
        4. What would a more representative assessment of today's incoming email require?

        Cross-validation, thresholds, new features and additional-corpus evaluation remain separate future decisions.
        See [README.txt](../README.txt) and [development_decisions.txt](../development_decisions.txt).
        The saved baseline and its historical test results remain unchanged.
        '''),
    ]


def main():
    DESTINATION.mkdir(exist_ok=True)
    lessons = [('01_email_to_naive_bayes', first_notebook()),
               ('02_evaluation_and_experiments', second_notebook())]
    for name, cells in lessons:
        notebook = nbf.v4.new_notebook(cells=cells, metadata={
            'kernelspec': {'display_name': 'Python 3 (use shared .venv)', 'language': 'python', 'name': 'python3'},
            'language_info': {'name': 'python'},
        })
        nbf.validate(notebook)
        nbf.write(notebook, DESTINATION / (name + '.ipynb'))
        print('Built', name, 'with', len(cells), 'cells')


if __name__ == '__main__':
    main()
