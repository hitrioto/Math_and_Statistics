"""Execute one lesson with this interpreter and verify baseline files unchanged."""
import hashlib
import json
import os
from pathlib import Path
import sys

import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = ['01_email_to_naive_bayes.ipynb', '02_evaluation_and_experiments.ipynb']


def protected_hashes():
    return {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for folder in ['data', 'models', 'reports', 'docs/history']
            for path in (ROOT / folder).rglob('*') if path.is_file()}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ALLOWED:
        raise SystemExit('Supply one notebook filename: ' + ', '.join(ALLOWED))
    path = ROOT / 'notebooks' / sys.argv[1]
    output = path.parent / 'outputs' / path.stem
    output.mkdir(parents=True, exist_ok=True)
    for key, folder in [('JUPYTER_RUNTIME_DIR', 'runtime'), ('IPYTHONDIR', 'ipython'),
                        ('MPLCONFIGDIR', 'matplotlib_cache')]:
        os.environ[key] = str(output / folder)
    before = protected_hashes()
    notebook = nbformat.read(path, as_version=4)
    nbformat.validate(notebook)
    manager = KernelManager(kernel_name='python3')
    manager.kernel_spec.argv[0] = sys.executable
    try:
        NotebookClient(notebook, km=manager, timeout=180,
                       resources={'metadata': {'path': str(path.parent)}}).execute()
    finally:
        if manager.has_kernel:
            manager.shutdown_kernel(now=True)
        if protected_hashes() != before:
            raise RuntimeError('Protected baseline files changed during notebook execution.')
    nbformat.validate(notebook)
    nbformat.write(notebook, path)
    status = {'notebook': path.name, 'python': sys.executable,
              'executed_code_cells': sum(c.cell_type == 'code' for c in notebook.cells),
              'protected_files_unchanged': len(before),
              'notebook_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (output / 'execution_check.json').write_text(json.dumps(status, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(status, indent=2))


if __name__ == '__main__':
    main()
