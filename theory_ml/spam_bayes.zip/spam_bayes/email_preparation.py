"""Email decoding and tokenization; no vocabulary is learned here."""
import re
from email import policy
from email.parser import BytesParser
from html.parser import HTMLParser


class HTMLTextExtractor(HTMLParser):
    """Collect HTML text, skipping head, script, style, and template content.

    This small parser does not evaluate CSS visibility.
    """

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.fragments = []
        self.ignored_tags = []

    def handle_starttag(self, tag, attrs):
        if tag in ["head", "script", "style", "template"]:
            self.ignored_tags.append(tag)
        if not self.ignored_tags:
            self.fragments.append(" ")

    def handle_endtag(self, tag):
        if tag in self.ignored_tags:
            while self.ignored_tags.pop() != tag:
                pass
        if not self.ignored_tags:
            self.fragments.append(" ")

    def handle_startendtag(self, tag, attrs):
        if not self.ignored_tags:
            self.fragments.append(" ")

    def handle_data(self, text):
        if not self.ignored_tags:
            self.fragments.append(text)


def html_to_text(html):
    parser = HTMLTextExtractor()
    parser.feed(html)
    parser.close()
    return " ".join("".join(parser.fragments).split())


def select_body(message):
    # Attached files and forwarded messages are not part of our initial input.
    if message.get_content_disposition() == "attachment" or message.get_filename():
        return None
    if message.get_content_maintype() == "message":
        return None
    if not message.is_multipart():
        if message.get_content_type() in ["text/plain", "text/html"]:
            return message
        return None

    parts = list(message.iter_parts())
    if message.get_content_type() == "multipart/related":
        # Only the root is the body; the remaining parts are resources.
        root = parts[0] if parts else None
        start = message.get_param("start")
        if start is not None:
            for part in parts:
                if part.get("Content-ID") == start:
                    root = part
                    break
        parts = [root] if root is not None else []

    candidates = []
    for part in parts:
        body = select_body(part)
        if body is not None:
            candidates.append(body)
    for body in candidates:
        if body.get_content_type() == "text/plain":
            return body
    return candidates[0] if candidates else None


def decode_body(body):
    payload = body.get_payload(decode=True) or b""
    charset = body.get_content_charset()
    if charset:
        try:
            return payload.decode(charset, errors="replace"), False
        except (LookupError, UnicodeError):
            pass
    return payload.decode("utf-8", errors="replace"), True


def prepare_email(path, subset):
    message = BytesParser(policy=policy.default).parsebytes(path.read_bytes())
    subject = str(message.get("Subject", ""))
    body = select_body(message)
    body_text, fallback = "", False
    if body is not None:
        body_text, fallback = decode_body(body)
        if body.get_content_type() == "text/html":
            body_text = html_to_text(body_text)

    text = f"{subject}\n{body_text}".strip()
    record = {
        "source": f"{subset}/{path.name}",
        "label": 1 if subset.startswith("spam") else 0,
        "subject": subject,
        "text": text,
        "tokens": re.findall(r"[a-z]{2,}", text.lower()),
    }
    return record, fallback


