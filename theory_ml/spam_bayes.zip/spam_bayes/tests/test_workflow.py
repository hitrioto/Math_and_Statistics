"""Behavior checks for the teaching pipeline; run with unittest discover."""
import sys
import shutil
import uuid
from contextlib import contextmanager
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from email_preparation import select_body, decode_body, html_to_text, prepare_email
from dataset_utils import split_records, check_split, word_count_key
from naive_bayes import NaiveBayesSpamFilter
from sklearn_models import fit_sklearn, run_experiment
from evaluation import calculate_metrics
import artifacts


@contextmanager
def test_directory():
    # Use ordinary inherited Windows permissions for these disposable files.
    path = Path(__file__).resolve().parent / ('test_work_' + uuid.uuid4().hex)
    path.mkdir()
    try:
        yield path
    finally:
        shutil.rmtree(path)


def record(source, label, tokens):
    return {'source': source, 'label': label, 'tokens': tokens}


class PreparationTests(unittest.TestCase):
    def test_plain_body_preferred_and_attachment_excluded(self):
        raw = b'''MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="outer"

--outer
Content-Type: text/plain
Content-Disposition: attachment; filename="note.txt"

attachment words
--outer
Content-Type: multipart/alternative; boundary="inner"

--inner
Content-Type: text/html

<p>html words</p>
--inner
Content-Type: text/plain; charset=utf-8

plain words
--inner--
--outer--
'''
        message = BytesParser(policy=policy.default).parsebytes(raw)
        body = select_body(message)
        self.assertEqual(body.get_content_type(), 'text/plain')
        self.assertEqual(decode_body(body), ('plain words', False))

    def test_related_root_and_charset_fallback(self):
        raw = b'''Content-Type: multipart/related; boundary="x"; start="<root>"

--x
Content-Type: text/plain
Content-ID: <resource>

wrong resource
--x
Content-Type: text/html; charset=not-a-charset
Content-ID: <root>

<b>right body</b>
--x--
'''
        body = select_body(BytesParser(policy=policy.default).parsebytes(raw))
        text, fallback = decode_body(body)
        self.assertTrue(fallback)
        self.assertEqual(html_to_text(text), 'right body')

    def test_html_and_subject_tokenization(self):
        self.assertEqual(html_to_text('<head>hidden</head><p>Hello &amp; world</p><script>bad</script>'), 'Hello & world')
        with test_directory() as directory:
            path = Path(directory) / '001'
            path.write_bytes(b'Subject: =?utf-8?q?FREE_Offer?=\nContent-Type: text/plain; charset=utf-8\n\nWin 123 a PRIZE!')
            prepared, fallback = prepare_email(path, 'spam')
        self.assertEqual(prepared['tokens'], ['free', 'offer', 'win', 'prize'])
        self.assertEqual(prepared['label'], 1)
        self.assertFalse(fallback)


class SplitTests(unittest.TestCase):
    def test_counts_not_order_define_groups_and_split_is_repeatable(self):
        records = [record(str(i), label, [str(i)]) for label in (0, 1) for i in range(label * 10, label * 10 + 10)]
        records += [record('duplicate1', 0, ['hello', 'world']), record('duplicate2', 0, ['world', 'hello'])]
        train, test = split_records(records)
        check_split(records, train, test)
        self.assertEqual((train, test), split_records(list(reversed(records))))
        self.assertEqual(word_count_key(records[-1]), word_count_key(records[-2]))
        self.assertNotEqual(word_count_key(records[-1]), word_count_key(record('x', 0, ['hello', 'hello', 'world'])))

    def test_conflicting_labels_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'conflicting labels'):
            split_records([record('a', 0, ['same']), record('b', 1, ['same'])])


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.records = [record('a', 0, ['meeting', 'meeting', 'today']), record('b', 0, ['hello']), record('c', 1, ['win', 'prize'])]

    def test_smoothing_unknown_empty_and_sklearn_scores(self):
        for alpha in (0.1, 1, 10):
            manual = NaiveBayesSpamFilter(alpha)
            manual.fit(self.records)
            vectorizer, library = fit_sklearn(manual, self.records)
            inputs = [[], ['unseen'], ['win', 'win', 'today'], ['meeting']]
            matrix = vectorizer.transform(inputs)
            expected = matrix @ library.feature_log_prob_.T + library.class_log_prior_
            actual = [[manual.predict_log_scores(tokens)[i] for i in (0, 1)] for tokens in inputs]
            np.testing.assert_allclose(actual, expected)
            np.testing.assert_array_equal([manual.predict(t) for t in inputs], library.predict(matrix))
            self.assertEqual(manual.predict_log_scores(['unseen']), manual.log_priors)
        with self.assertRaises(ValueError):
            NaiveBayesSpamFilter(0)

    def test_validation_only_words_do_not_expand_vocabulary(self):
        validation = [record('v', 1, ['unseen'] * 100)]
        _, size = run_experiment(self.records, validation)
        self.assertEqual(size, 5)

    def test_save_load_scores_and_stale_training_detection(self):
        model = NaiveBayesSpamFilter()
        model.fit(self.records)
        with test_directory() as directory:
            root = Path(directory)
            train = root / 'train.jsonl'
            train.write_text('original training input')
            (root / 'naive_bayes.py').write_text('model source')
            (root / 'email_preparation.py').write_text('preparation source')
            with patch.multiple(artifacts, ROOT=root, TRAIN_PATH=train, MODEL_PATH=root / 'model.json', REPORTS_PATH=root / 'reports'):
                artifacts.save_model(model)
                loaded = artifacts.load_model()
                self.assertEqual(model.predict_log_scores(['win', 'today']), loaded.predict_log_scores(['win', 'today']))
                train.write_text('changed input')
                with self.assertRaisesRegex(ValueError, 'changed'):
                    artifacts.load_model()

    def test_metric_orientation(self):
        matrix, metrics = calculate_metrics([0, 0, 1, 1, 1], [0, 1, 0, 1, 1])
        self.assertEqual(matrix, [[1, 1], [1, 2]])
        self.assertAlmostEqual(metrics['Spam recall'], 2 / 3)
        self.assertEqual(metrics['False-positive rate'], 0.5)


if __name__ == '__main__':
    unittest.main()
