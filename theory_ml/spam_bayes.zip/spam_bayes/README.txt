SPAM BAYES -- REPRODUCIBLE TEACHING PACKAGE
=========================================

This package contains source code, two notebooks, guides and dependency lists.
It contains no email data, trained model, generated reports, virtual environment,
caches or development history. Notebook outputs are cleared for distribution.
Python 3.13 is recommended (the original exercise used Python 3.13.16).

Quick start -- Windows PowerShell
--------------------------------
Extract the ZIP and open a terminal in the extracted spam_bayes folder:
  py -3.13 -m venv .venv
  .\.venv\Scripts\python.exe -m pip install -r requirements-notebooks.txt
  .\.venv\Scripts\python.exe download_data.py
  .\.venv\Scripts\python.exe run_all.py
  .\.venv\Scripts\python.exe -m unittest discover -s tests -v
  .\.venv\Scripts\python.exe -m notebook notebooks

On macOS/Linux, use python3.13 -m venv .venv and .venv/bin/python instead.
An existing compatible environment is also fine. For scripts only, install
requirements.txt instead of requirements-notebooks.txt.
Package installation and the first data download require internet access.

If Jupyter selects a different interpreter, register this environment:
  .\.venv\Scripts\python.exe -m ipykernel install --user --name spam-bayes --display-name "Spam Bayes"
Choose Spam Bayes in the notebook interface. Check the Python path printed by
the first cell. Restart the kernel and run all cells in order.

Data reference
--------------
Apache SpamAssassin Public Corpus:
  https://spamassassin.apache.org/old/publiccorpus/
Corpus description and usage information:
  https://spamassassin.apache.org/old/publiccorpus/readme.html

download_data.py downloads these exact versions, checks their SHA-256 hashes,
and extracts ordinary files into data/raw/ without retaining compressed copies:
  20030228_easy_ham.tar.bz2     2,500 ham messages (baseline)
  20030228_spam.tar.bz2           500 spam messages (baseline)
  20030228_hard_ham.tar.bz2       250 messages (inspection only)
  20050311_spam_2.tar.bz2       1,396 messages (inspection only)

Hashes are pinned to the archives used in the original exercise. A changed
download fails verification. Running the downloader again checks existing
files against the downloaded bytes; it refuses to overwrite differing files.
If the upstream server is unavailable, retry later. No silent mirror/version
substitution is made. Data is not redistributed inside this package.

Learning route
--------------
Read step_objectives.txt and then run scripts 01-07 individually or run_all.py:
1. Inspect MIME email structure.
2. Prepare subject/body text and tokens.
3. Split with identical word-count groups kept together.
4. Fit and save manual Multinomial Naive Bayes.
5. Evaluate and inspect errors.
6. Check agreement with sklearn.
7. Compare choices using validation inside training only.

The notebooks follow the same route:
  notebooks/01_email_to_naive_bayes.ipynb       Steps 1-4, with toy calculations.
  notebooks/02_evaluation_and_experiments.ipynb Steps 5-7, with tables and charts.
Run run_all.py first: notebooks depend on its generated data/model/reports.
Both notebooks run independently and write only to notebooks/outputs/.

Regenerated outputs
-------------------
data/prepared/       Text/tokens JSONL.
data/splits/         Reproducible training/test JSONL.
models/              Readable JSON model with vocabulary, counts and parameters.
reports/             Preparation/split/training details, test metrics and
                     predictions, errors, sklearn comparison, validation tables.
reports/run_logs/    Console output from run_all.py.
notebooks/outputs/   Notebook demonstrations, charts and execution checks.

run_all.py replaces generated outputs. It never downloads data automatically.
After changing preparation, rerun from step 2; after changing alpha, rerun from
step 4. Steps 5-6 detect changed training data/core model code. Step 7 chooses
no winner and does not replace the baseline. Paths are relative to the project.

The original test set has already been examined. Reproduction is historical
evidence, not a new untouched test. Use training/validation for further choices.
The original fixed baseline has 98.17% accuracy and 89% spam recall on 600
test emails; zero observed false positives is not a guarantee about future mail.

Maintenance
-----------
Shared modules hold parsing, splitting, model mathematics and metrics.
development_decisions.txt explains the choices and trade-offs.
tools/build_notebooks.py rebuilds both notebooks and clears their outputs;
it overwrites direct notebook edits. Execute with the current interpreter:
  python tools/execute_notebook.py 01_email_to_naive_bayes.ipynb
  python tools/execute_notebook.py 02_evaluation_and_experiments.ipynb
The executor uses a fresh kernel and checks the generated baseline is unchanged.
The standard-library downloader can run before installing ML dependencies.
