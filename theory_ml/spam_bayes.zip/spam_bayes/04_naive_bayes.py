"""Exercise 4: train Multinomial Naive Bayes from scratch.

Use only training records. Test-set evaluation belongs to Exercise 5.
"""

import json
import sys
from paths import TRAIN_PATH, MODEL_PATH
from naive_bayes import NaiveBayesSpamFilter
from artifacts import save_model

ALPHA = 1.0
SAMPLES = 5
CLASS_NAMES = {0: "ham", 1: "spam"}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    with TRAIN_PATH.open(encoding="utf-8") as source:
        records = [json.loads(line) for line in source]

    model = NaiveBayesSpamFilter(alpha=ALPHA)
    model.fit(records)
    save_model(model)
    print("Saved model:", MODEL_PATH)

    print("TRAINING SUMMARY:")
    print("Training emails:", len(records))
    print("Vocabulary size:", len(model.vocabulary))
    print("Smoothing alpha:", model.alpha)
    for label in [0, 1]:
        print(f"{CLASS_NAMES[label]}: {model.class_counts[label]} emails, "
              f"prior = {model.class_priors[label]:.4f}")

    print("\nTRAINING EXAMPLES (illustrations, not held-out evaluation):")
    for record in records[:SAMPLES]:
        scores = model.predict_log_scores(record["tokens"])
        prediction = model.predict(record["tokens"])
        print("\nSource:", record["source"])
        print("Subject:", record["subject"])
        print("Actual:", CLASS_NAMES[record["label"]],
              "| Predicted:", CLASS_NAMES[prediction])
        print(f"Log scores: ham = {scores[0]:.3f}, spam = {scores[1]:.3f}")
    print("\nUnknown tokens are ignored. No test emails were read.")


if __name__ == "__main__":
    main()
