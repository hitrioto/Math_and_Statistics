"""Exercise 3: split emails, keeping identical word-count groups together."""

import json
from collections import Counter
from paths import PREPARED_PATH, TRAIN_PATH, TEST_PATH, REPORTS_PATH
from dataset_utils import split_records, check_split, save_records
from artifacts import save_json, provenance

INPUT_PATH = PREPARED_PATH
TEST_SIZE = 0.20
SEED = 42


def main():
    with INPUT_PATH.open(encoding="utf-8") as source:
        records = [json.loads(line) for line in source]
    train, test = split_records(records, test_size=TEST_SIZE, seed=SEED)
    check_split(records, train, test)
    save_records(TRAIN_PATH, train)
    save_records(TEST_PATH, test)
    save_json(REPORTS_PATH / "split.json", {
        "seed": SEED, "test_size": TEST_SIZE,
        "train_counts": dict(Counter(r["label"] for r in train)),
        "test_counts": dict(Counter(r["label"] for r in test)),
        "provenance": provenance([INPUT_PATH, TRAIN_PATH, TEST_PATH]),
    })

    print(f"Seed: {SEED}; requested test fraction: {TEST_SIZE:.0%}")
    for name, partition in [("Training", train), ("Test", test)]:
        counts = Counter(record["label"] for record in partition)
        print(f"{name}: {len(partition)} emails, {counts[0]} ham, {counts[1]} spam")
    print("Verified: all records retained and duplicate groups kept together.")
    print("Saved:", TRAIN_PATH, "and", TEST_PATH)
    print("Each run replaces these files. Learn the vocabulary from training only.")


if __name__ == "__main__":
    main()
