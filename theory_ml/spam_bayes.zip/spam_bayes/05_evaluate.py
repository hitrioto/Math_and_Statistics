"""Exercise 5: evaluate the existing classifier on held-out test emails.

Load the model saved by step 4. Use the previously examined test set for reporting, not tuning.
"""

import sys
from paths import TRAIN_PATH, TEST_PATH, MODEL_PATH, REPORTS_PATH
from dataset_utils import load_records
from evaluation import calculate_metrics
from artifacts import load_model, save_json, save_table, provenance

ERROR_SAMPLES = 5


def show_errors(title, records):
    print(f"\n{title}: {len(records)} emails")
    for record in records[:ERROR_SAMPLES]:
        print("Source:", record["source"])
        print("Subject:", record["subject"] or "[Missing or empty]")
    if not records:
        print("No errors of this type.")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    model = load_model()
    train_records = load_records(TRAIN_PATH)
    test_records = load_records(TEST_PATH)

    actual_labels = []
    predictions = []
    false_positives = []
    false_negatives = []
    for record in test_records:
        actual = record["label"]
        predicted = model.predict(record["tokens"])
        actual_labels.append(actual)
        predictions.append(predicted)
        if actual == 0 and predicted == 1:
            false_positives.append(record)
        elif actual == 1 and predicted == 0:
            false_negatives.append(record)

    matrix, metrics = calculate_metrics(actual_labels, predictions)
    print("HELD-OUT EVALUATION:")
    print("Training emails:", len(train_records))
    print("Test emails:", len(test_records))
    print("Smoothing alpha:", model.alpha)
    print("\nCONFUSION MATRIX (rows = actual, columns = predicted):")
    print("                  Predicted ham   Predicted spam")
    print(f"Actual ham        {matrix[0][0]:>13}  {matrix[0][1]:>15}")
    print(f"Actual spam       {matrix[1][0]:>13}  {matrix[1][1]:>15}")
    print("\nMETRICS (spam is the positive class):")
    for name, value in metrics.items():
        print(f"{name}: {value:.2%}")
    print("Metrics with a zero denominator are reported as 0.")

    # A majority-class baseline makes the effect of class imbalance visible.
    _, baseline = calculate_metrics(actual_labels, [0] * len(test_records))
    print("\nBASELINE: ALWAYS PREDICT HAM:")
    for name, value in baseline.items():
        print(f"{name}: {value:.2%}")
    save_json(REPORTS_PATH / "evaluation.json", {
        "confusion_matrix": matrix, "metrics": metrics, "always_ham": baseline,
        "test_status": "Previously examined historical test set; not for tuning",
        "provenance": provenance([TRAIN_PATH, TEST_PATH, MODEL_PATH]),
    })
    rows = [{"source": r["source"], "actual": r["label"], "predicted": p}
            for r, p in zip(test_records, predictions, strict=True)]
    save_table(REPORTS_PATH / "test_predictions.csv", rows)
    save_json(REPORTS_PATH / "errors.json", {
        "false_positives": false_positives, "false_negatives": false_negatives,
    })
    improvement = metrics["Accuracy"] - baseline["Accuracy"]
    print(f"Model accuracy gain: {100 * improvement:.2f} percentage points")

    show_errors("False positives: ham marked as spam", false_positives)
    show_errors("False negatives: spam missed", false_negatives)
    print("\nINTERPRETATION:")
    print("A false positive can hide a legitimate email; a false negative lets spam through.")
    print("These results describe this historical corpus, not current email traffic.")
    print("Identical word counts were grouped, but related or near-duplicate emails may remain.")
    print("Choose future settings using training/validation data, not these test results.")


if __name__ == "__main__":
    main()
