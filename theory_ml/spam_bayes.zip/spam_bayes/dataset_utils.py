"""JSONL records and a stratified split that keeps word-count groups together."""
import json
import random
from collections import Counter


def word_count_key(record):
    # Word order is irrelevant to Multinomial Naive Bayes; counts are relevant.
    return tuple(sorted(Counter(record["tokens"]).items()))


def choose_test_groups(groups, target):
    """Choose whole groups whose total size is closest to the target.

    A dictionary maps each possible email count to the group indices producing
    it. This avoids breaking duplicates just to achieve an exact percentage.
    """
    total = sum(len(group) for group in groups)
    if len(groups) < 2:
        raise ValueError("Each class needs at least two distinct groups.")
    target = min(max(target, 1), total - 1)
    choices = {0: []}
    for index, group in enumerate(groups):
        # Copy the current choices so each group is used at most once.
        for count, indices in list(choices.items()):
            new_count = count + len(group)
            if new_count not in choices:
                choices[new_count] = indices + [index]
        if target in choices:
            break
    possible_counts = [count for count in choices if 0 < count < total]
    closest = min(possible_counts, key=lambda count: (abs(count - target), count))
    return set(choices[closest])


def split_records(records, test_size=0.20, seed=42):
    groups = {}
    for record in sorted(records, key=lambda record: record["source"]):
        key = word_count_key(record)
        groups.setdefault(key, []).append(record)

    for group in groups.values():
        if len({record["label"] for record in group}) != 1:
            raise ValueError("Identical word counts have conflicting labels.")

    rng = random.Random(seed)
    train, test = [], []
    for label in [0, 1]:
        class_groups = [group for group in groups.values()
                        if group[0]["label"] == label]
        rng.shuffle(class_groups)
        class_count = sum(len(group) for group in class_groups)
        selected = choose_test_groups(class_groups, round(class_count * test_size))
        for index, group in enumerate(class_groups):
            if index in selected:
                test.extend(group)
            else:
                train.extend(group)
    rng.shuffle(train)
    rng.shuffle(test)
    return train, test


def check_split(records, train, test):
    # Keep the essential checks: every email appears once, with no leakage.
    all_sources = [record["source"] for record in records]
    split_sources = [record["source"] for record in train + test]
    assert len(set(all_sources)) == len(all_sources), "Duplicate source IDs"
    assert Counter(all_sources) == Counter(split_sources), "Lost or repeated emails"
    train_keys = {word_count_key(record) for record in train}
    test_keys = {word_count_key(record) for record in test}
    assert train_keys.isdisjoint(test_keys), "Duplicate groups cross the split"


def save_records(path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as output:
        for record in records:
            output.write(json.dumps(record, ensure_ascii=False) + "\n")



def load_records(path):
    with path.open(encoding="utf-8") as source:
        return [json.loads(line) for line in source]
