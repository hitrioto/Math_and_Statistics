"""Exercise 2: turn each email into text, tokens, a label, and a source ID."""

import json
import sys
from collections import Counter

from email_preparation import prepare_email
from paths import RAW_PATH, PREPARED_PATH, REPORTS_PATH
from artifacts import save_json, provenance

DATASET_PATH = RAW_PATH
SUBSETS = ["easy_ham", "spam"]
OUTPUT_PATH = PREPARED_PATH
SAMPLES = 2


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    counts = Counter()
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    # JSONL stores one complete email record on each line. Each run replaces it.
    with OUTPUT_PATH.open("w", encoding="utf-8", newline="\n") as output:
        for subset in SUBSETS:
            folder = DATASET_PATH / subset
            files = sorted(path for path in folder.iterdir()
                           if path.is_file() and path.name[0].isdigit())
            for index, path in enumerate(files):
                record, fallback = prepare_email(path, subset)
                output.write(json.dumps(record, ensure_ascii=False) + "\n")
                counts[subset] += 1
                counts["charset fallbacks"] += fallback
                counts["replacement characters"] += "\ufffd" in record["text"]
                counts["empty text"] += not record["text"]
                counts["empty tokens"] += not record["tokens"]
                if index < SAMPLES:
                    print("\nSOURCE:", record["source"], "LABEL:", record["label"])
                    print("RAW PREVIEW:")
                    print(path.read_bytes().decode("utf-8", errors="replace")[:600])
                    print("PREPARED TEXT:", record["text"][:600])
                    print("FIRST 30 TOKENS:", record["tokens"][:30])

    save_json(REPORTS_PATH / "preparation.json", {"counts": dict(counts), "subsets": SUBSETS, "provenance": provenance([OUTPUT_PATH])})
    print("\nSUMMARY:")
    for name, count in counts.items():
        print(f"{name}: {count}")
    print("Saved:", OUTPUT_PATH)
    print("Empty-token records are retained. No vocabulary has been learned.")


if __name__ == "__main__":
    main()
