"""Exercise 1: look at raw emails, their headers, and their MIME parts."""

import sys
from email import policy
from email.parser import BytesParser
from paths import RAW_PATH

# Change these settings before running the script in Spyder or a terminal.
DATASET_PATH = RAW_PATH
SUBSETS = ["easy_ham", "hard_ham", "spam", "spam_2"]
SAMPLES = 3


def body_preview(message):
    body = message.get_body(preferencelist=("plain", "html"))
    if body is None:
        return "[No textual body found.]"

    payload = body.get_payload(decode=True) or b""
    charset = body.get_content_charset() or "utf-8"
    try:
        return payload.decode(charset, errors="replace")
    except (LookupError, UnicodeError):
        return payload.decode("utf-8", errors="replace")


def inspect_email(path):
    raw = path.read_bytes()
    message = BytesParser(policy=policy.default).parsebytes(raw)

    print("\n" + "=" * 60)
    print("FILE:", path.name)
    print("\nRAW EMAIL PREVIEW:")
    print(raw.decode("utf-8", errors="replace")[:2000])

    print("\nPARSED HEADERS:")
    for header in ["From", "To", "Subject", "Date"]:
        print(f"{header}: {message.get(header, '[Missing]')}")
    print("Content type:", message.get_content_type())
    print("Multipart:", message.is_multipart())

    print("\nMIME PARTS:")
    for part in message.walk():
        print("Type:", part.get_content_type(),
              "| Charset:", part.get_content_charset(),
              "| Encoding:", part.get("Content-Transfer-Encoding"),
              "| Disposition:", part.get_content_disposition())

    print("\nBODY PREVIEW:")
    print(body_preview(message)[:1000])


def inspect_folder(folder):
    # Email filenames begin with a digit. This excludes the 'cmds' metadata file.
    files = sorted(path for path in folder.iterdir()
                   if path.is_file() and path.name[0].isdigit())
    print(f"\n=== {folder.name}: {len(files)} emails ===")
    for path in files[:SAMPLES]:
        inspect_email(path)


def main():
    # Let Windows consoles replace characters they cannot display.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    for subset in SUBSETS:
        inspect_folder(DATASET_PATH / subset)

    print("\nEXERCISE QUESTIONS:")
    print("1. Where do headers end and the body begin?")
    print("2. How do HTML, multipart messages, and encodings affect the body?")
    print("3. What differences do you notice between ham and spam?")
    print("4. Which parts should the first text classifier use, and why?")


if __name__ == "__main__":
    main()
