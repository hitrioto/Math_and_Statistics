"""Library comparison and training-only validation experiments."""
from collections import Counter
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB, BernoulliNB


def use_saved_tokens(tokens):
    # A custom analyzer bypasses sklearn's default text preprocessing.
    return tokens


def fit_sklearn(manual_model, train_records):
    vocabulary = {}
    for index, word in enumerate(sorted(manual_model.vocabulary)):
        vocabulary[word] = index
    vectorizer = CountVectorizer(analyzer=use_saved_tokens, vocabulary=vocabulary)
    train_tokens = [record["tokens"] for record in train_records]
    train_counts = vectorizer.fit_transform(train_tokens)
    labels = [record["label"] for record in train_records]
    priors = [manual_model.class_priors[0], manual_model.class_priors[1]]
    model = MultinomialNB(alpha=manual_model.alpha, class_prior=priors)
    model.fit(train_counts, labels)
    return vectorizer, model


def run_experiment(fit_records, validation_records, alpha=1.0,
                   max_words=None, bernoulli=False):
    # Rank words by total frequency using fitting data only; break ties by word.
    word_counts = Counter()
    for record in fit_records:
        word_counts.update(record["tokens"])
    words = sorted(word_counts, key=lambda word: (-word_counts[word], word))
    if max_words is not None:
        words = words[:max_words]
    vocabulary = {word: index for index, word in enumerate(words)}

    vectorizer = CountVectorizer(analyzer=use_saved_tokens, vocabulary=vocabulary)
    fit_tokens = [record["tokens"] for record in fit_records]
    validation_tokens = [record["tokens"] for record in validation_records]
    fit_counts = vectorizer.fit_transform(fit_tokens)
    validation_counts = vectorizer.transform(validation_tokens)
    labels = [record["label"] for record in fit_records]

    if bernoulli:
        # Convert positive counts to presence; BernoulliNB also models absence.
        model = BernoulliNB(alpha=alpha, binarize=0.0)
    else:
        model = MultinomialNB(alpha=alpha)
    model.fit(fit_counts, labels)
    predictions = model.predict(validation_counts)
    return predictions, len(vocabulary)


