"""Manual Multinomial Naive Bayes: counts, smoothing, and log scores."""
import math
from collections import Counter


class NaiveBayesSpamFilter:
    """Learn word counts per class, then score emails using log probabilities."""

    def __init__(self, alpha=1.0):
        if alpha <= 0:
            raise ValueError("Smoothing alpha must be positive.")
        self.alpha = alpha

    def fit(self, records):
        # Reset the counts so calling fit again starts a new model.
        self.class_counts = Counter()
        self.word_counts = {0: Counter(), 1: Counter()}
        self.vocabulary = set()

        for record in records:
            label = record["label"]
            tokens = record["tokens"]
            self.class_counts[label] += 1
            self.word_counts[label].update(tokens)
            self.vocabulary.update(tokens)

        if not self.class_counts[0] or not self.class_counts[1] or not self.vocabulary:
            raise ValueError("Training needs both classes and a nonempty vocabulary.")

        self.class_priors = {}
        self.log_priors = {}
        self.log_word_probabilities = {0: {}, 1: {}}
        total_emails = sum(self.class_counts.values())
        vocabulary_size = len(self.vocabulary)

        for label in [0, 1]:
            # P(class) = number of class emails / number of training emails.
            prior = self.class_counts[label] / total_emails
            self.class_priors[label] = prior
            self.log_priors[label] = math.log(prior)

            # P(word | class) = (word count + alpha) / (token total + alpha * |V|).
            token_total = sum(self.word_counts[label].values())
            denominator = token_total + self.alpha * vocabulary_size
            for word in sorted(self.vocabulary):
                numerator = self.word_counts[label][word] + self.alpha
                probability = numerator / denominator
                self.log_word_probabilities[label][word] = math.log(probability)

    def predict_log_scores(self, tokens):
        """Return unnormalized class scores, not posterior log probabilities.

        Call fit first. Empty inputs and inputs with no known words use priors.
        """
        token_counts = Counter(tokens)
        scores = {}
        for label in [0, 1]:
            score = self.log_priors[label]
            for word, count in token_counts.items():
                if word in self.vocabulary:
                    score += count * self.log_word_probabilities[label][word]
            scores[label] = score
        return scores

    def predict(self, tokens):
        scores = self.predict_log_scores(tokens)
        # Choose the larger score. An exact tie goes to ham (label 0).
        if scores[1] > scores[0]:
            return 1
        return 0


