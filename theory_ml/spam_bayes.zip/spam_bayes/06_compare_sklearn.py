"""Exercise 6: compare the manual model with sklearn under identical settings.

Requires scikit-learn: install it in the interpreter used to run this file.
Terminal command: python -m pip install scikit-learn
"""

import sys
from paths import TRAIN_PATH, TEST_PATH, MODEL_PATH, REPORTS_PATH
from dataset_utils import load_records
from evaluation import calculate_metrics
from sklearn_models import fit_sklearn
from artifacts import load_model, save_json, provenance

import numpy as np

TOP_WORDS = 10
DIFFERENCE_SAMPLES = 5


def show_word_associations(manual_model):
    associations = []
    for word in manual_model.vocabulary:
        # log(P(word | spam) / P(word | ham)) = log P(word | spam) - log P(word | ham).
        ratio = (manual_model.log_word_probabilities[1][word]
                 - manual_model.log_word_probabilities[0][word])
        associations.append((word, ratio))

    for name, descending in [("Spam-associated", True), ("Ham-associated", False)]:
        ranked = sorted(associations, key=lambda item: (-item[1] if descending else item[1], item[0]))
        print(f"\n{name} words (log likelihood ratio):")
        print("Word                Log ratio   Ham count   Spam count")
        for word, ratio in ranked[:TOP_WORDS]:
            print(f"{word:<20} {ratio:>8.3f} {manual_model.word_counts[0][word]:>11} "
                  f"{manual_model.word_counts[1][word]:>12}")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    train_records = load_records(TRAIN_PATH)
    test_records = load_records(TEST_PATH)
    manual_model = load_model()
    vectorizer, sklearn_model = fit_sklearn(manual_model, train_records)
    test_tokens = [record["tokens"] for record in test_records]
    test_counts = vectorizer.transform(test_tokens)

    manual_predictions = []
    manual_scores = []
    for tokens in test_tokens:
        manual_predictions.append(manual_model.predict(tokens))
        scores = manual_model.predict_log_scores(tokens)
        manual_scores.append([scores[0], scores[1]])
    sklearn_predictions = sklearn_model.predict(test_counts)

    # Matrix multiplication sums count * log P(word | class) for each email.
    # Add log P(class) to obtain the same unnormalized scores as the manual model.
    # predict_log_proba returns normalized values, so it is not comparable here.
    sklearn_scores = test_counts @ sklearn_model.feature_log_prob_.T + sklearn_model.class_log_prior_
    score_difference = np.max(np.abs(np.array(manual_scores) - sklearn_scores))
    scores_match = np.allclose(manual_scores, sklearn_scores, rtol=1e-10, atol=1e-8)
    differences = np.flatnonzero(np.array(manual_predictions) != sklearn_predictions)

    print("IMPLEMENTATION COMPARISON:")
    print("Vocabulary size:", len(manual_model.vocabulary))
    print("Training emails:", len(train_records), "| Test emails:", len(test_records))
    print("Smoothing alpha:", manual_model.alpha)
    print(f"Matching predictions: {len(test_records) - len(differences)}/{len(test_records)}")
    print("Log scores match within floating-point tolerance:", scores_match)
    print(f"Largest absolute log-score difference: {score_difference:.3e}")
    for index in differences[:DIFFERENCE_SAMPLES]:
        print("Difference:", test_records[index]["source"],
              "| manual:", manual_predictions[index], "| sklearn:", sklearn_predictions[index])
    if len(differences) or not scores_match:
        print("Review token counts, vocabulary, priors, smoothing, and summation order.")
    else:
        print("The implementations agree; tiny score differences come from floating-point arithmetic.")

    labels = [record["label"] for record in test_records]
    print("\nHELD-OUT METRICS:")
    for name, predictions in [("Manual", manual_predictions), ("sklearn", sklearn_predictions)]:
        matrix, metrics = calculate_metrics(labels, predictions)
        print(name, "confusion matrix:", matrix)
        for metric, value in metrics.items():
            print(f"  {metric}: {value:.2%}")

    save_json(REPORTS_PATH / "sklearn_comparison.json", {
        "test_count": len(test_records), "matching_predictions": len(test_records) - len(differences),
        "scores_match": bool(scores_match), "maximum_score_difference": float(score_difference),
        "provenance": provenance([TRAIN_PATH, TEST_PATH, MODEL_PATH]),
    })
    if len(differences) or not scores_match:
        raise AssertionError("Manual/sklearn comparison failed; see saved report.")
    show_word_associations(manual_model)
    print("\nWord associations come from training data only and may reflect corpus-specific topics.")
    print("Keep this comparison fixed; use training/validation data for future tuning.")


if __name__ == "__main__":
    main()
