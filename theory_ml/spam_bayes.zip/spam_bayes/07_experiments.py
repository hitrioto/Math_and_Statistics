"""Exercise 7: compare model choices using validation data inside training.

Requires scikit-learn. Reads training data only and saves validation results.
"""

from collections import Counter
from paths import TRAIN_PATH, REPORTS_PATH
from dataset_utils import load_records, split_records, check_split
from evaluation import calculate_metrics
from sklearn_models import run_experiment
from artifacts import save_json, save_table, provenance


VALIDATION_SIZE = 0.20
SEED = 42
ALPHAS = [0.1, 1.0, 10.0]
VOCABULARY_SIZES = [1000, 5000, None]  # None means all fitting-data words.


def show_result(name, predictions, labels, vocabulary_size):
    _, metrics = calculate_metrics(labels, predictions)
    print(f"{name:<24} {vocabulary_size:>7} "
          f"{metrics['Accuracy']:>8.2%} {metrics['Spam precision']:>9.2%} "
          f"{metrics['Spam recall']:>8.2%} {metrics['Spam F1']:>8.2%} "
          f"{metrics['False-positive rate']:>8.2%}")
    return {"setting": name, "vocabulary_size": vocabulary_size, **metrics}


def main():
    records = load_records(TRAIN_PATH)
    fit_records, validation_records = split_records(
        records, test_size=VALIDATION_SIZE, seed=SEED,
    )
    check_split(records, fit_records, validation_records)
    labels = [record["label"] for record in validation_records]
    results = []

    print("VALIDATION EXPERIMENTS:")
    print(f"Grouped validation split: {VALIDATION_SIZE:.0%}; seed: {SEED}")
    for name, partition in [("Fitting", fit_records), ("Validation", validation_records)]:
        counts = Counter(record["label"] for record in partition)
        print(f"{name}: {len(partition)} emails, {counts[0]} ham, {counts[1]} spam")
    print("Vocabulary and priors are learned from fitting data only.")
    print("Each experiment changes one choice from MultinomialNB, alpha=1, all words.")
    header = "Setting                    Words Accuracy Precision   Recall       F1      FPR"

    print("\n1. SMOOTHING (MultinomialNB, all words)")
    print(header)
    for alpha in ALPHAS:
        predictions, size = run_experiment(fit_records, validation_records, alpha=alpha)
        result = show_result(f"alpha={alpha:g}", predictions, labels, size)
        results.append({"experiment": "smoothing", **result})

    print("\n2. VOCABULARY SIZE (MultinomialNB, alpha=1)")
    print(header)
    for limit in VOCABULARY_SIZES:
        predictions, size = run_experiment(fit_records, validation_records, max_words=limit)
        name = "all words" if limit is None else f"top {limit} words"
        result = show_result(name, predictions, labels, size)
        results.append({"experiment": "vocabulary", **result})

    print("\n3. MODEL (alpha=1, all words)")
    print(header)
    for bernoulli in [False, True]:
        predictions, size = run_experiment(fit_records, validation_records, bernoulli=bernoulli)
        name = "BernoulliNB" if bernoulli else "MultinomialNB"
        result = show_result(name, predictions, labels, size)
        results.append({"experiment": "model", **result})

    save_table(REPORTS_PATH / "validation_experiments.csv", results)
    save_json(REPORTS_PATH / "validation.json", {
        "seed": SEED, "validation_size": VALIDATION_SIZE,
        "fitting_sources": [r["source"] for r in fit_records],
        "validation_sources": [r["source"] for r in validation_records],
        "results": results, "automatic_selection": False,
        "provenance": provenance([TRAIN_PATH]),
    })
    print("\nDISCUSSION:")
    print("FPR is the proportion of ham incorrectly marked as spam; spam is the positive class.")
    print("Compare precision, recall, and FPR alongside F1 and accuracy.")
    print("BernoulliNB uses word presence and absence; MultinomialNB uses counts.")
    print("One validation split is an illustration; rankings may change with another split.")
    print("This script chooses no automatic winner and performs no test-set evaluation.")
    print("Validation reports saved. Subject/body and additional-corpus experiments remain future work.")


if __name__ == "__main__":
    main()
