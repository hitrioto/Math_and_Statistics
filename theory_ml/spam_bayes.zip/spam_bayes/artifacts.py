"""Small helpers for saving results and checking which data trained a model."""
import csv
import hashlib
import json
import platform
from importlib.metadata import version

from paths import ROOT, MODEL_PATH, TRAIN_PATH, REPORTS_PATH


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def provenance(paths):
    return {
        'python': platform.python_version(),
        'packages': {name: version(name) for name in ('numpy', 'scikit-learn')},
        'sha256': {path.relative_to(ROOT).as_posix(): file_hash(path) for path in paths},
    }


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')


def save_table(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError('A table needs at least one row to define its columns.')
    with path.open('w', encoding='utf-8', newline='') as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_model(model):
    # JSON keeps the learned parameters readable and avoids executable pickles.
    sources = [TRAIN_PATH, ROOT / 'naive_bayes.py', ROOT / 'email_preparation.py']
    artifact = {
        'format_version': 1,
        'provenance': provenance(sources),
        'preprocessing': 'Decoded subject + selected body; lowercase [a-z]{2,}; token counts',
        'alpha': model.alpha,
        'class_counts': dict(model.class_counts),
        'word_counts': {label: dict(counts) for label, counts in model.word_counts.items()},
        'vocabulary': sorted(model.vocabulary),
        'class_priors': model.class_priors,
        'log_priors': model.log_priors,
        'log_word_probabilities': model.log_word_probabilities,
    }
    save_json(MODEL_PATH, artifact)
    save_json(REPORTS_PATH / 'training.json', {
        'alpha': model.alpha, 'vocabulary_size': len(model.vocabulary),
        'class_counts': dict(model.class_counts), 'class_priors': model.class_priors,
        'provenance': artifact['provenance'],
    })


def load_model():
    from collections import Counter
    from naive_bayes import NaiveBayesSpamFilter

    if not MODEL_PATH.exists():
        raise FileNotFoundError('Run 04_naive_bayes.py first to save the model.')
    artifact = json.loads(MODEL_PATH.read_text(encoding='utf-8'))
    if artifact['format_version'] != 1:
        raise ValueError('Unsupported model format; rerun step 4.')
    for relative, expected in artifact['provenance']['sha256'].items():
        if file_hash(ROOT / relative) != expected:
            raise ValueError('Training data or model/preparation code changed; rerun the affected steps and step 4.')
    model = NaiveBayesSpamFilter(alpha=artifact['alpha'])
    model.vocabulary = set(artifact['vocabulary'])
    model.class_counts = Counter({int(k): v for k, v in artifact['class_counts'].items()})
    model.word_counts = {int(k): Counter(v) for k, v in artifact['word_counts'].items()}
    for name in ('class_priors', 'log_priors', 'log_word_probabilities'):
        setattr(model, name, {int(k): v for k, v in artifact[name].items()})
    return model
