"""Regenerate data products, model and reports using this Python interpreter."""
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    missing = [name for name in ('easy_ham', 'hard_ham', 'spam', 'spam_2')
               if not (ROOT / 'data/raw' / name).is_dir()]
    if missing:
        raise SystemExit('Missing raw data. Run python download_data.py first.')
    logs = ROOT / 'reports/run_logs'
    logs.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, PYTHONIOENCODING='utf-8')
    for script in sorted(ROOT.glob('[0-9][0-9]_*.py')):
        result = subprocess.run([sys.executable, str(script)], cwd=ROOT,
                                env=environment, capture_output=True, encoding='utf-8')
        (logs / (script.stem + '.txt')).write_text(result.stdout + result.stderr, encoding='utf-8')
        if result.returncode:
            raise RuntimeError(f'{script.name} failed. See {logs / (script.stem + ".txt")}')
        print('Completed:', script.name, flush=True)
    print('Generated model and reports. Run notebooks separately when ready.')


if __name__ == '__main__':
    main()
