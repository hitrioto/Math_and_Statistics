"""Download the exact SpamAssassin corpus versions used by this exercise.

Python standard library only. SHA-256 checks pin the original archive bytes.
Existing matching files are retained; differing files are never overwritten.
"""
import hashlib
import io
from pathlib import Path, PurePosixPath
import tarfile
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent
SOURCE = 'https://spamassassin.apache.org/old/publiccorpus/'
ARCHIVES = {
    '20030228_easy_ham.tar.bz2': ('easy_ham', '2b7b65904bcfcc31d2b5f51946f2d261370b257402cbbd62930b46ab83367438'),
    '20030228_hard_ham.tar.bz2': ('hard_ham', 'ce2ce67880643dbde65ea7f85bffbfe4417349c4bd80b6b0de56262ae6b0a9c9'),
    '20030228_spam.tar.bz2': ('spam', 'c08debc32413804949a866be45ef78195cec2cbafd1da744ed76cdb860589743'),
    '20050311_spam_2.tar.bz2': ('spam_2', '44280a0e28bf7645b2279e8e42659271ad82c6f40bf8d364dbda7f1df344a765'),
}


def checked_members(archive, subset):
    """Permit only ordinary files/directories inside the expected subset."""
    members = archive.getmembers()
    for member in members:
        path = PurePosixPath(member.name)
        if (path.is_absolute() or '..' in path.parts or not path.parts
                or path.parts[0] != subset or '\\' in member.name or ':' in member.name
                or not (member.isfile() or member.isdir())):
            raise ValueError(f'Unexpected archive member: {member.name}')
    return members


def download_data():
    raw = ROOT / 'data/raw'
    raw.mkdir(parents=True, exist_ok=True)
    for filename, (subset, expected) in ARCHIVES.items():
        print('Downloading:', SOURCE + filename, flush=True)
        with urlopen(SOURCE + filename, timeout=60) as response:
            payload = response.read()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError(f'Checksum mismatch for {filename}; extraction stopped.')
        # Read archives in memory, so downloaded compressed copies are not left behind.
        with tarfile.open(fileobj=io.BytesIO(payload), mode='r:bz2') as archive:
            members = checked_members(archive, subset)
            for member in members:
                destination = raw / member.name
                if not destination.resolve().is_relative_to(raw.resolve()):
                    raise ValueError(f'Extraction path escapes raw data: {member.name}')
                if member.isdir():
                    destination.mkdir(parents=True, exist_ok=True)
                    continue
                contents = archive.extractfile(member).read()
                if destination.exists():
                    if destination.read_bytes() != contents:
                        raise ValueError(f'Existing file differs; left untouched: {destination}')
                else:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(contents)
        print('Verified and extracted:', subset, flush=True)
    print('Data ready in:', raw)


if __name__ == '__main__':
    download_data()
