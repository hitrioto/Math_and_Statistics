"""The shared baseline preprocessing recipe; each call builds an unfitted pipeline."""

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

CATEGORICAL = ["SEX", "EDUCATION", "MARRIAGE",
               "PAY_0", "PAY_2", "PAY_3", "PAY_4", "PAY_5", "PAY_6"]
NUMERICAL = (["LIMIT_BAL", "AGE"]
             + [f"BILL_AMT{month}" for month in range(1, 7)]
             + [f"PAY_AMT{month}" for month in range(1, 7)])
# Code 0 represents unknown/undocumented education or marriage, not "other".
# Education 0 and marriage 0 already have this code; only education 5/6 change.
CATEGORY_MAPPING = {"EDUCATION": {5: 0, 6: 0}}


def build_preprocessor():
    # Include the fixed mapping in the saved pipeline so future records receive
    # the same treatment. DataFrame.replace is serializable without custom code.
    mapping = FunctionTransformer(
        pd.DataFrame.replace, kw_args={"to_replace": CATEGORY_MAPPING}
    )
    columns = ColumnTransformer([
        ("category", OneHotEncoder(drop="first", handle_unknown="ignore",
                                   sparse_output=False), CATEGORICAL),
        ("number", StandardScaler(), NUMERICAL),
    ], remainder="drop", verbose_feature_names_out=False)
    return Pipeline([("mapping", mapping), ("columns", columns)])

