"""Keep matching customer profiles together in a reproducible 60/20/20 split."""

from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

PROJECT_PATH = Path(__file__).resolve().parent
DATA_PATH = PROJECT_PATH / "data" / "default of credit card clients.xls"
OUTPUT_PATH = PROJECT_PATH / "data" / "splits"
RANDOM_SEED = 42
TARGET = "default"


def load_data():
    data = pd.read_excel(DATA_PATH, sheet_name="Data", header=1, engine="xlrd")
    return data.rename(columns={"default payment next month": TARGET})


def split_data(data):
    predictor_columns = data.columns.drop(["ID", TARGET]).tolist()
    # Same predictors = same group, even when the customers' outcomes differ.
    groups = data.groupby(predictor_columns, dropna=False, sort=False).ngroup()

    # Five approximately balanced folds: three for training, one for validation,
    # and one for testing. Stratification aims to preserve the default rate.
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)
    fold = pd.Series(index=data.index, dtype="int64")
    for number, (_, positions) in enumerate(
        splitter.split(data[predictor_columns], data[TARGET], groups)
    ):
        fold.iloc[positions] = number

    assignment = pd.Series("train", index=data.index)
    assignment.loc[fold == 3] = "validation"
    assignment.loc[fold == 4] = "test"
    splits = {name: data.loc[assignment == name].copy()
              for name in ["train", "validation", "test"]}

    # These checks protect the two key promises: retain every record and keep
    # every matching profile in exactly one split.
    assert sum(len(part) for part in splits.values()) == len(data)
    assert assignment.groupby(groups).nunique().max() == 1
    return splits, groups, assignment


def save_results(data, splits, groups, assignment):
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    lines = [
        "STEP 2: CREDIT DEFAULT DATA SPLIT",
        f"Random seed: {RANDOM_SEED}",
        "Method: five stratified group folds; train 0-2, validation 3, test 4.",
        "Target: default (1 = default; 0 = no default).",
        "ID is retained for tracing records; exclude it from model inputs.",
        "All 23 original predictors are retained. No cleaning is applied yet.",
        "",
        "Split          Rows    Share  Defaults  Default rate",
    ]
    for name, part in splits.items():
        part.to_csv(OUTPUT_PATH / f"{name}.csv", index=False)
        lines.append(
            f"{name:12} {len(part):6,d} {len(part) / len(data):8.2%} "
            f"{part[TARGET].sum():9,d} {part[TARGET].mean():13.2%}"
        )

    mixed_groups = data[TARGET].groupby(groups).nunique().gt(1).sum()
    crossing_groups = assignment.groupby(groups).nunique().gt(1).sum()
    lines.extend([
        "",
        f"Total records retained: {sum(len(part) for part in splits.values()):,}",
        f"Distinct predictor profiles: {groups.nunique():,}",
        f"Groups with mixed outcomes retained: {mixed_groups}",
        f"Predictor groups crossing splits: {crossing_groups}",
        "",
        "Use training data to fit preprocessing and models.",
        "Use validation data to choose settings and thresholds.",
        "Reserve test data for the final evaluation.",
        "Matching profiles can belong to different customers; no rows were removed.",
        "Rerunning this script replaces these split files reproducibly.",
    ])
    report = "\n".join(lines) + "\n"
    (OUTPUT_PATH / "split_report.txt").write_text(report, encoding="utf-8")
    print(report)
    print("Saved to:", OUTPUT_PATH)


def main():
    data = load_data()
    splits, groups, assignment = split_data(data)
    save_results(data, splits, groups, assignment)


if __name__ == "__main__":
    main()
