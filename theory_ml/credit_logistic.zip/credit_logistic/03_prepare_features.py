"""Prepare the baseline features, learning encoding and scaling from training only."""

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from preprocessing import CATEGORICAL, NUMERICAL, build_preprocessor

PROJECT_PATH = Path(__file__).resolve().parent
SPLIT_PATH = PROJECT_PATH / "data" / "splits"
OUTPUT_PATH = PROJECT_PATH / "data" / "prepared"
MODEL_PATH = PROJECT_PATH / "models" / "baseline"
TARGET = "default"


def report_unseen_categories(preprocessor, features, split_name):
    mapped = preprocessor.named_steps["mapping"].transform(features)
    encoder = preprocessor.named_steps["columns"].named_transformers_["category"]
    lines = []
    for column, known_values in zip(CATEGORICAL, encoder.categories_):
        unseen = mapped.loc[~mapped[column].isin(known_values), column]
        if not unseen.empty:
            lines.append(f"{split_name}: {column}: unseen values/counts {unseen.value_counts().to_dict()}")
    return lines or [f"{split_name}: no unseen categories."]


def main():
    splits = {name: pd.read_csv(SPLIT_PATH / f"{name}.csv")
              for name in ["train", "validation", "test"]}
    preprocessor = build_preprocessor()
    # Neither IDs nor outcomes are supplied to the preprocessing pipeline.
    train_features = splits["train"][CATEGORICAL + NUMERICAL]
    preprocessor.fit(train_features)
    columns = preprocessor.named_steps["columns"]
    feature_names = columns.get_feature_names_out()
    encoder = columns.named_transformers_["category"]

    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.mkdir(parents=True, exist_ok=True)
    lines = [
        "STEP 3: BASELINE FEATURE PREPARATION",
        "Fitted on training data only; validation/test use transform only.",
        "Education 0/5/6 -> 0 (unknown/undocumented); marriage 0 stays unknown.",
        "Documented other categories remain separate. Repayment codes are unchanged.",
        "Negative bills and extreme values are retained; no resampling is applied.",
        "Numerical features: (value - training mean) / training standard deviation.",
        f"Output features: {len(feature_names)}",
        "",
        "REFERENCE CATEGORIES (lowest observed training code, omitted from encoding):",
    ]
    for column, categories, index in zip(CATEGORICAL, encoder.categories_, encoder.drop_idx_):
        lines.append(f"{column}: {categories[index]}")
    lines.extend([
        "",
        "Unseen categories use all-zero encoding, the same as the reference category.",
        "Unknown/undocumented is a known category when code 0 occurs in training.",
        "",
    ])

    for name, data in splits.items():
        features = data[CATEGORICAL + NUMERICAL]
        lines.extend(report_unseen_categories(preprocessor, features, name))
        values = preprocessor.transform(features)
        if not np.isfinite(values).all():
            raise ValueError(f"Non-finite prepared values in {name}.")
        prepared = pd.DataFrame(values, columns=feature_names, index=data.index)
        prepared.to_csv(OUTPUT_PATH / f"X_{name}.csv", index=False)
        # Keep IDs and outcomes together in a separate file, in the same row order.
        data[["ID", TARGET]].to_csv(OUTPUT_PATH / f"y_{name}.csv", index=False)
        lines.append(f"{name}: {len(prepared):,} rows, {len(feature_names)} features.")

    joblib.dump(preprocessor, MODEL_PATH / "preprocessor.joblib")
    (OUTPUT_PATH / "feature_names.txt").write_text("\n".join(feature_names) + "\n", encoding="utf-8")
    lines.extend([
        "",
        "X files contain model inputs only. y files contain ID and default.",
        "Pair X and y by row order; use only the default column as the target.",
        "Saved pipeline includes fixed category mapping, encoding, and scaling.",
        "For new data, supply the original named predictor columns to transform().",
        "Rerunning replaces prepared files and the saved preprocessor.",
        "No logistic regression model has been fitted yet.",
    ])
    report = "\n".join(lines) + "\n"
    (OUTPUT_PATH / "preparation_report.txt").write_text(report, encoding="utf-8")
    print(report)
    print("Prepared data:", OUTPUT_PATH)
    print("Saved preprocessor:", MODEL_PATH / "preprocessor.joblib")


if __name__ == "__main__":
    main()
