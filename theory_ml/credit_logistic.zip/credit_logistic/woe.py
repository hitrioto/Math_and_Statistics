"""Readable training-only binning and weight-of-evidence calculations."""

import numpy as np
import pandas as pd

from preprocessing import CATEGORICAL, NUMERICAL, CATEGORY_MAPPING

MIN_BIN_SHARE = 0.01
MIN_CLASS_COUNT = 20


def assign_bins(series, rule):
    if rule["kind"] == "numeric":
        # Outer intervals cover any future finite numerical value.
        edges = [-np.inf] + rule["cut_points"] + [np.inf]
        return pd.cut(series, edges, labels=False, right=True).astype(str)
    # A known code must match even if a caller loads 1 as 1.0.
    # Nullable integer conversion also rejects fractional category codes.
    return series.astype("Int64").astype(str)


def fit_woe(features, target, max_bins=5, smoothing=0.5):
    if len(features) != len(target):
        raise ValueError("Features and target must have the same number of rows.")
    if max_bins < 1 or smoothing <= 0:
        raise ValueError("Use at least one bin and strictly positive smoothing.")
    data = features.replace(CATEGORY_MAPPING)
    if data.isna().any().any() or not set(target.unique()) == {0, 1}:
        raise ValueError("Training data needs complete predictors and both binary outcomes.")
    rules = {"education_mapping": {str(key): value for key, value in CATEGORY_MAPPING["EDUCATION"].items()}, "smoothing": smoothing,
             "convention": "ln(non_default_share / default_share)",
             "intervals": "right closed; outer bounds are negative/positive infinity",
             "unseen_category_woe": 0.0, "features": {}}
    tables = []
    for column in CATEGORICAL + NUMERICAL:
        if column in NUMERICAL:
            _, edges = pd.qcut(data[column], q=max_bins, retbins=True, duplicates="drop")
            rule = {"kind": "numeric", "cut_points": edges[1:-1].tolist()}
        else:
            rule = {"kind": "categorical"}
        bins = assign_bins(data[column], rule)
        # Use positions, not index alignment, to pair the supplied features and target.
        counts = pd.DataFrame({"bin": bins.to_numpy(), "default": target.to_numpy()})
        table = counts.groupby("bin", sort=True)["default"].agg(records="size", defaults="sum")
        table["non_defaults"] = table["records"] - table["defaults"]
        table["record_share"] = table["records"] / len(data)
        table["default_rate"] = table["defaults"] / table["records"]
        k = len(table)
        table["default_share"] = (table["defaults"] + smoothing) / (target.sum() + smoothing * k)
        table["non_default_share"] = (table["non_defaults"] + smoothing) / ((1 - target).sum() + smoothing * k)
        table["woe"] = np.log(table["non_default_share"] / table["default_share"])
        table["iv_contribution"] = (table["non_default_share"] - table["default_share"]) * table["woe"]
        table["small_share"] = table["record_share"] < MIN_BIN_SHARE
        table["few_defaults"] = table["defaults"] < MIN_CLASS_COUNT
        table["few_non_defaults"] = table["non_defaults"] < MIN_CLASS_COUNT
        table["needs_review"] = table[["small_share", "few_defaults", "few_non_defaults"]].any(axis=1)
        rule["woe_by_bin"] = table["woe"].to_dict()
        rules["features"][column] = rule
        table = table.reset_index()
        table.insert(0, "feature", column)
        if rule["kind"] == "numeric":
            boundaries = [-np.inf] + rule["cut_points"] + [np.inf]
            table.insert(2, "description", [f"({boundaries[int(b)]}, {boundaries[int(b)+1]}]" for b in table["bin"]])
        else:
            table.insert(2, "description", "category code " + table["bin"])
        tables.append(table)
    return rules, pd.concat(tables, ignore_index=True)


def transform_woe(features, rules):
    mapping = {int(key): value for key, value in rules["education_mapping"].items()}
    data = features.replace({"EDUCATION": mapping})
    if data.isna().any().any():
        raise ValueError("Missing predictors require an agreed handling rule.")
    output = pd.DataFrame(index=data.index)
    unseen = []
    for column, rule in rules["features"].items():
        bins = assign_bins(data[column], rule)
        values = bins.map(rule["woe_by_bin"])
        if values.isna().any():
            if rule["kind"] == "numeric":
                raise ValueError(f"Unmapped numerical bin in {column}.")
            for code, count in bins[values.isna()].value_counts().items():
                unseen.append({"feature": column, "category": code, "records": int(count)})
        output[column] = values.fillna(rules["unseen_category_woe"])
    return output, unseen
