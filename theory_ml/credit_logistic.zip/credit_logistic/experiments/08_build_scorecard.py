"""Optional lesson: express the saved WoE model as additive scorecard points."""

from pathlib import Path
import hashlib
import json
import sys

import joblib
import numpy as np
import pandas as pd
from scipy.special import expit

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from woe import assign_bins, transform_woe

MODEL_FILE = PROJECT_PATH / "models" / "woe" / "logistic_woe.joblib"
OUTPUT_PATH = PROJECT_PATH / "reports" / "scorecard"
BASE_SCORE = 600
BASE_GOOD_BAD_ODDS = 20
POINTS_TO_DOUBLE_ODDS = 20


def build_scorecard(bundle):
    model = bundle["model"]
    features = bundle["features"]
    if list(model.classes_) != [0, 1] or list(model.feature_names_in_) != features:
        raise ValueError("Expected default=1 and the original fitted feature order.")
    factor = POINTS_TO_DOUBLE_ODDS / np.log(2)
    offset = BASE_SCORE - factor * np.log(BASE_GOOD_BAD_ODDS)
    # Model z is log(default/non-default odds); higher scores mean lower risk.
    # score = offset - factor*z = base_points + sum(feature_points).
    base_points = offset - factor * float(model.intercept_[0])
    rows = []
    points_rules = {}
    for feature, coefficient in zip(features, model.coef_[0]):
        rule = bundle["rules"]["features"][feature]
        points_rules[feature] = {}
        for bin_id, woe in rule["woe_by_bin"].items():
            points = float(-factor * coefficient * woe)
            points_rules[feature][bin_id] = points
            if rule["kind"] == "numeric":
                edges = [-np.inf] + rule["cut_points"] + [np.inf]
                i = int(bin_id)
                description = f"({edges[i]}, {edges[i+1]}]"
            else:
                description = f"category code {bin_id}"
            rows.append({"feature": feature, "bin": bin_id, "description": description,
                         "woe": woe, "coefficient": coefficient,
                         "points": points, "display_points": round(points, 2)})
        if rule["kind"] == "categorical":
            rows.append({"feature": feature, "bin": "UNSEEN",
                         "description": "unseen category: neutral WoE fallback",
                         "woe": 0.0, "coefficient": coefficient,
                         "points": 0.0, "display_points": 0.0})
    definition = {
        "base_score": BASE_SCORE, "base_good_bad_odds": BASE_GOOD_BAD_ODDS,
        "points_to_double_odds": POINTS_TO_DOUBLE_ODDS,
        "factor": float(factor), "offset": float(offset), "base_points": float(base_points),
        "model_intercept": float(model.intercept_[0]),
        "features": features, "binning_rules": bundle["rules"],
        "points_by_feature_bin": points_rules, "unseen_category_points": 0.0,
        "source_model": "models/woe/logistic_woe.joblib",
        "source_sha256": hashlib.sha256(MODEL_FILE.read_bytes()).hexdigest(),
        "formula": "score = base_points + sum(feature points); p_default = expit((offset-score)/factor)",
    }
    return definition, pd.DataFrame(rows)


def verify_scorecard(bundle, definition):
    # Use validation only for arithmetic equivalence, not model assessment or tuning.
    raw = pd.read_csv(PROJECT_PATH / "data" / "splits" / "validation.csv")
    X, _ = transform_woe(raw[bundle["features"]], bundle["rules"])
    mapping = {int(k): v for k, v in bundle["rules"]["education_mapping"].items()}
    mapped = raw.replace({"EDUCATION": mapping})
    scores = np.full(len(raw), definition["base_points"])
    for feature in definition["features"]:
        rule = definition["binning_rules"]["features"][feature]
        bins = assign_bins(mapped[feature], rule)
        points = bins.map(definition["points_by_feature_bin"][feature])
        if rule["kind"] == "numeric" and points.isna().any():
            raise ValueError(f"Missing numerical scorecard bin for {feature}.")
        scores += points.fillna(definition["unseen_category_points"]).to_numpy()
    expected_score = definition["offset"] - definition["factor"] * bundle["model"].decision_function(X)
    recovered_probability = expit((definition["offset"]-scores)/definition["factor"])
    model_probability = bundle["model"].predict_proba(X)[:, 1]
    np.testing.assert_allclose(scores, expected_score, atol=1e-10, rtol=0)
    np.testing.assert_allclose(recovered_probability, model_probability, atol=1e-12, rtol=0)
    # Check the approved scale and its direction independently of the fitted data.
    for score, odds in [(BASE_SCORE, BASE_GOOD_BAD_ODDS),
                        (BASE_SCORE+POINTS_TO_DOUBLE_ODDS, 2*BASE_GOOD_BAD_ODDS)]:
        np.testing.assert_allclose(expit((definition["offset"]-score)/definition["factor"]), 1/(1+odds))
    return len(raw), float(np.max(abs(recovered_probability-model_probability)))


def main():
    bundle = joblib.load(MODEL_FILE)
    definition, table = build_scorecard(bundle)
    records, error = verify_scorecard(bundle, definition)
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUTPUT_PATH / "scorecard_points.csv", index=False)
    (OUTPUT_PATH / "scorecard_definition.json").write_text(
        json.dumps(definition, indent=2, allow_nan=False), encoding="utf-8")
    report = "\n".join([
        "OPTIONAL SCORECARD: POINTS SCALING OF THE EXISTING WoE MODEL",
        "Objective: express exactly the same probabilities as an additive points table.",
        f"Base scale: {BASE_SCORE} points at {BASE_GOOD_BAD_ODDS}:1 non-default/default odds.",
        f"Each additional {POINTS_TO_DOUBLE_ODDS} points doubles those odds; higher scores mean lower risk.",
        "600 points -> default probability 1/21 = 4.7619%; 620 -> 1/41 = 2.4390%.",
        f"Factor = PDO/ln(2) = {definition['factor']:.10f}",
        f"Offset = base score - factor*ln(base odds) = {definition['offset']:.10f}",
        f"Shared base points = offset - factor*intercept = {definition['base_points']:.10f}",
        "Feature points = -factor * coefficient * WoE for the assigned bin.",
        "Total = shared base points (once) + all 23 feature contributions.",
        "Keep the intercept/base separate rather than distributing it across variables.",
        "Default probability = expit((offset-total score)/factor).",
        "",
        f"Verified additive scores and probabilities on {records:,} validation records.",
        f"Maximum absolute probability difference: {error:.3e}.",
        "No fitting, threshold changes, or test-set access was performed.",
        "Use full-precision points for calculations; display_points is presentation only.",
        "Points can be fractional or negative. Scores are not clipped to a fixed range.",
        "Education mapping and numerical interval boundaries are included in the definition.",
        "Unseen categorical values use zero points; missing values still need an agreed policy.",
        "A points contribution describes this model, not a causal effect or a recommended action.",
        "",
        "This optional scorecard uses WoE. The frozen operating strategies selected the",
        "conventional baseline; their thresholds must NOT be applied to this different model.",
        "The 36 flagged WoE bins and coefficient interpretation limitations still apply.",
        "Source model hash is included for traceability. Rerunning replaces scorecard outputs only.",
        "Customer-level explanations belong to the separate, not-yet-implemented file 09.",
    ]) + "\n"
    (OUTPUT_PATH / "scorecard_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
