"""Assess saved validation probabilities; do not fit or recalibrate models."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, log_loss

PROJECT_PATH = Path(__file__).resolve().parents[1]
REPORT_PATH = PROJECT_PATH / "reports"
OUTPUT_PATH = REPORT_PATH / "diagnostics"
N_BINS = 10


def reliability_table(data):
    """Use common fixed probability bands so both models share the same boundaries."""
    frame = data.copy()
    frame["band"] = pd.cut(frame.default_probability, np.linspace(0, 1, N_BINS + 1),
                           include_lowest=True)
    table = frame.groupby("band", observed=False).agg(
        records=("default", "size"), defaults=("default", "sum"),
        mean_probability=("default_probability", "mean"), observed_rate=("default", "mean"))
    table["gap"] = table.observed_rate - table.mean_probability
    # Wilson intervals describe binomial uncertainty in the observed rate.
    # They do not include uncertainty from model fitting or correlated profiles.
    n = table.records.replace(0, np.nan)
    rate = table.observed_rate
    z = 1.96
    center = (rate + z*z/(2*n)) / (1 + z*z/n)
    half = z * np.sqrt(rate*(1-rate)/n + z*z/(4*n*n)) / (1 + z*z/n)
    table["observed_low"] = center-half
    table["observed_high"] = center+half
    return table.reset_index()


def risk_bands(data):
    frame = data.copy()
    # Quantiles describe this validation sample only; they are not deployment cutoffs.
    frame["band"] = pd.qcut(frame.default_probability, N_BINS, duplicates="drop")
    table = frame.groupby("band", observed=True).agg(
        records=("default", "size"), defaults=("default", "sum"),
        mean_probability=("default_probability", "mean"), observed_rate=("default", "mean"))
    table = table.sort_index(ascending=False)
    table["lift"] = table.observed_rate / frame.default.mean()
    table["cumulative_population_share"] = table.records.cumsum() / len(frame)
    table["cumulative_default_capture"] = table.defaults.cumsum() / frame.default.sum()
    return table.reset_index()


def main():
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    predictions = {name: pd.read_csv(REPORT_PATH / name / "validation_predictions.csv")
                   for name in ["baseline", "woe"]}
    pd.testing.assert_frame_equal(predictions["baseline"][["ID", "default"]],
                                  predictions["woe"][["ID", "default"]])
    train_target = pd.read_csv(PROJECT_PATH / "data" / "splits" / "train.csv")["default"]
    constant_probability = train_target.mean()
    rows = []
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), layout="constrained")
    axes[0].plot([0, 1], [0, 1], "--", color="gray", label="Perfect calibration")
    for name, data in predictions.items():
        if not data.default_probability.between(0, 1).all():
            raise ValueError(f"Invalid probabilities in {name}.")
        table = reliability_table(data)
        table.to_csv(OUTPUT_PATH / f"{name}_reliability.csv", index=False)
        risk_bands(data).to_csv(OUTPUT_PATH / f"{name}_risk_bands.csv", index=False)
        used = table[table.records > 0]
        error = np.vstack([used.observed_rate-used.observed_low, used.observed_high-used.observed_rate])
        axes[0].errorbar(used.mean_probability, used.observed_rate, yerr=error,
                         marker="o", capsize=3, label=name)
        axes[1].hist(data.default_probability, bins=np.linspace(0, 1, N_BINS+1),
                     histtype="step", linewidth=2, label=name)
        rows.append({"model": name, "records": len(data),
                     "observed_default_rate": data.default.mean(),
                     "mean_probability": data.default_probability.mean(),
                     "mean_probability_minus_observed": data.default_probability.mean()-data.default.mean(),
                     "brier_score": brier_score_loss(data.default, data.default_probability),
                     "log_loss": log_loss(data.default, data.default_probability),
                     "ece_10_bins": (used.records*used.gap.abs()).sum()/len(data)})
    target = predictions["baseline"].default
    reference = np.full(len(target), constant_probability)
    rows.append({"model": "training_prevalence_reference", "records": len(target),
                 "observed_default_rate": target.mean(), "mean_probability": constant_probability,
                 "mean_probability_minus_observed": constant_probability-target.mean(),
                 "brier_score": brier_score_loss(target, reference),
                 "log_loss": log_loss(target, reference),
                 "ece_10_bins": abs(constant_probability-target.mean())})
    summary = pd.DataFrame(rows)
    summary.to_csv(OUTPUT_PATH / "calibration_summary.csv", index=False)
    axes[0].set(xlabel="Mean predicted default probability", ylabel="Observed default rate",
                xlim=(0, 1), ylim=(0, 1), title="Validation reliability (approx. 95% intervals)")
    axes[1].set(xlabel="Predicted default probability", ylabel="Customers", title="Validation probability distribution")
    for axis in axes:
        axis.legend()
        axis.grid(alpha=0.2)
    fig.savefig(OUTPUT_PATH / "calibration.png", dpi=160)
    plt.close(fig)

    bins = pd.read_csv(REPORT_PATH / "woe" / "bin_table.csv")
    bin_summary = bins.groupby("feature", as_index=False).agg(
        bins=("bin", "size"), flagged_bins=("needs_review", "sum"),
        smallest_bin=("records", "min"), minimum_defaults=("defaults", "min"),
        minimum_non_defaults=("non_defaults", "min"))
    coefficients = pd.read_csv(REPORT_PATH / "woe" / "coefficients.csv")
    review = coefficients.merge(bin_summary, on="feature", validate="one_to_one")
    review.to_csv(OUTPUT_PATH / "woe_feature_review.csv", index=False)
    # Correlations are computed on training features, not used to remove variables.
    X = pd.read_csv(PROJECT_PATH / "data" / "woe" / "X_train.csv")
    corr = X.corr()
    pairs = [{"feature_1": a, "feature_2": b, "correlation": corr.loc[a,b]}
             for i,a in enumerate(corr.columns) for b in corr.columns[i+1:]]
    pairs = pd.DataFrame(pairs).sort_values("correlation", key=lambda x:x.abs(), ascending=False)
    pairs.to_csv(OUTPUT_PATH / "woe_training_correlations.csv", index=False)
    report = "\n".join([
        "CALIBRATION AND DIAGNOSTICS: VALIDATION ONLY",
        "Objective: assess probability accuracy, risk concentration, and WoE warning signs.",
        "No models fitted, bins changed, thresholds selected, or test predictions evaluated.",
        "",
        summary.round(6).to_string(index=False),
        "",
        "Brier score is mean squared probability error; lower is better.",
        "Brier and log loss reflect more than calibration alone; inspect reliability tables too.",
        "Positive mean_probability_minus_observed indicates overall overprediction.",
        "ECE is weighted absolute bin gap, sensitive to the chosen ten fixed bands.",
        "The prevalence reference can have near-zero ECE yet cannot rank customers.",
        "Reliability plot: above diagonal means underprediction; below means overprediction.",
        "Empty bands remain in CSV with missing rates. Sparse high-risk bands are uncertain.",
        "Wilson intervals are approximate and do not include model-fitting or dependence uncertainty.",
        "Risk-band files are descending validation quantiles; ties can reduce bin count.",
        "Lift compares each band's actual default rate with the whole validation default rate.",
        "These quantile boundaries are descriptive, not fitted policy cutoffs.",
        "",
        "WOE FEATURES WITH POSITIVE COEFFICIENTS OR SPARSE BINS:",
        review.loc[review.positive_sign_review | (review.flagged_bins > 0)].round(4).to_string(index=False),
        "",
        "STRONGEST TEN TRAINING CORRELATIONS (WoE features):",
        pairs.head(10).round(4).to_string(index=False),
        "Correlation can help interpret conditional signs but does not prove their cause.",
        "No significance test or automatic feature selection is applied.",
        "Assess these findings before deciding whether recalibration or bin revision is worthwhile.",
        "Any future calibrator must use predictions independent of its base-model fit;",
        "do not fit and assess calibration on the same observations.",
    ]) + "\n"
    (OUTPUT_PATH / "diagnostic_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
