"""Final test evaluation of frozen review strategies; no selection or refitting."""

from pathlib import Path
import hashlib
import json
import sys

import joblib
import pandas as pd
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix,
                             log_loss, roc_auc_score)

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from woe import transform_woe

REPORT_PATH = PROJECT_PATH / "reports" / "strategies"


def main():
    if (REPORT_PATH / "test_report.txt").exists():
        raise FileExistsError("Final test results already exist. Read them; do not tune and rerun on this holdout.")
    frozen = json.loads((REPORT_PATH / "frozen_strategies.json").read_text())
    for path, digest in frozen["sha256"].items():
        if hashlib.sha256((PROJECT_PATH/path).read_bytes()).hexdigest() != digest:
            raise ValueError(f"Model artifact changed since selection: {path}")
    data = pd.read_csv(PROJECT_PATH / "data" / "splits" / "test.csv")
    target = data["default"]
    probabilities = {}
    unseen_rows = []
    for name in sorted({choice["model"] for choice in frozen["choices"]}):
        if name == "baseline":
            preprocessor = joblib.load(PROJECT_PATH / "models/baseline/preprocessor.joblib")
            model = joblib.load(PROJECT_PATH / "models/baseline/logistic_baseline.joblib")
            columns = preprocessor.named_steps["columns"]
            raw = data.drop(columns=["ID", "default"])
            mapped = preprocessor.named_steps["mapping"].transform(raw)
            encoder = columns.named_transformers_["category"]
            for column, known in zip(columns.transformers_[0][2], encoder.categories_):
                for code, count in mapped.loc[~mapped[column].isin(known), column].value_counts().items():
                    unseen_rows.append({"model": name, "feature": column, "category": str(code), "records": int(count)})
            X = pd.DataFrame(preprocessor.transform(raw), columns=columns.get_feature_names_out())
        else:
            bundle = joblib.load(PROJECT_PATH / "models/woe/logistic_woe.joblib")
            model = bundle["model"]
            X, unseen = transform_woe(data[bundle["features"]], bundle["rules"])
            unseen_rows.extend({"model": name, **row} for row in unseen)
        probabilities[name] = model.predict_proba(X)[:, 1]
    rows = []
    predictions = data[["ID", "default"]].copy()
    for choice in frozen["choices"]:
        strategy, name, threshold = choice["strategy"], choice["model"], choice["threshold"]
        probability = probabilities[name]
        predicted = probability >= threshold
        tn, fp, fn, tp = confusion_matrix(target, predicted, labels=[0, 1]).ravel()
        recall, fpr = tp/(tp+fn), fp/(fp+tn)
        rows.append({"strategy": strategy, "model": name, "threshold": threshold,
                     "precision": tp/(tp+fp) if tp+fp else 0, "recall": recall,
                     "false_positive_rate": fpr, "alerts": int(predicted.sum()),
                     "alert_rate": predicted.mean(), "true_positive": tp, "false_positive": fp,
                     "false_negative": fn, "true_negative": tn,
                     "validation_target_met_on_test": bool(recall >= frozen["target_recall"] if strategy == "protective" else fpr <= frozen["max_false_positive_rate"]),
                     "roc_auc": roc_auc_score(target, probability),
                     "average_precision": average_precision_score(target, probability),
                     "log_loss": log_loss(target, probability),
                     "brier_score": brier_score_loss(target, probability)})
        predictions[f"{strategy}_probability"] = probability
        predictions[f"{strategy}_review_flag"] = predicted.astype(int)
    results = pd.DataFrame(rows)
    results.to_csv(REPORT_PATH / "test_metrics.csv", index=False)
    predictions.to_csv(REPORT_PATH / "test_predictions.csv", index=False)
    pd.DataFrame(unseen_rows, columns=["model", "feature", "category", "records"]).to_csv(
        REPORT_PATH / "test_unseen_categories.csv", index=False)
    report = "\n".join([
        "FINAL TEST EVALUATION: FROZEN REVIEW STRATEGIES",
        f"Test records: {len(data):,}; actual defaults: {target.sum():,}.",
        "Models and exact thresholds were frozen on validation before this evaluation.",
        "No retraining, threshold adjustment, or winner selection uses these test results.",
        "",
        results.round(6).to_string(index=False),
        "",
        "Targets can miss on test because validation estimates do not guarantee future performance.",
        "Do not change these thresholds to make this test set meet the targets.",
        "A review flag is not evidence that an intervention prevents default.",
        "Growth/profit and intervention effects are not measured by this dataset.",
        "These are point estimates on one historical holdout, not temporal or production validation.",
        "This holdout is now exposed; further development requires new independent evaluation data.",
    ]) + "\n"
    (REPORT_PATH / "test_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
