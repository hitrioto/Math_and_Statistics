"""Choose models and thresholds on validation only, then freeze the choices."""

from pathlib import Path
import hashlib
import json
import sys

import pandas as pd

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from operating_strategies import choose_strategy, threshold_table
from artifact_checks import verify_validation_predictions

OUTPUT_PATH = PROJECT_PATH / "reports" / "strategies"
TARGET_RECALL = 0.80
MAX_FALSE_POSITIVE_RATE = 0.05
ARTIFACTS = {
    "baseline": ["models/baseline/preprocessor.joblib", "models/baseline/logistic_baseline.joblib"],
    "woe": ["models/woe/logistic_woe.joblib"],
}


def main():
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    frozen_path = OUTPUT_PATH / "frozen_strategies.json"
    if frozen_path.exists():
        raise FileExistsError("Choices are already frozen. Inspect them instead of overwriting after test exposure.")
    tables = []
    reference = None
    for name in ARTIFACTS:
        data = pd.read_csv(PROJECT_PATH / "reports" / name / "validation_predictions.csv")
        verify_validation_predictions(PROJECT_PATH, name, data)
        if reference is not None:
            pd.testing.assert_frame_equal(reference, data[["ID", "default"]])
        reference = data[["ID", "default"]]
        tables.append(threshold_table(data.default, data.default_probability).assign(model=name))
    candidates = pd.concat(tables, ignore_index=True)
    choices = []
    comparisons = []
    for strategy in ["protective", "growth"]:
        winner = choose_strategy(candidates, strategy, TARGET_RECALL, MAX_FALSE_POSITIVE_RATE)
        choices.append({"strategy": strategy, **winner.to_dict()})
        for name in ARTIFACTS:
            candidate = choose_strategy(candidates[candidates.model == name], strategy,
                                        TARGET_RECALL, MAX_FALSE_POSITIVE_RATE)
            comparisons.append({"strategy": strategy, **candidate.to_dict()})
    pd.DataFrame(comparisons).to_csv(OUTPUT_PATH / "validation_candidates.csv", index=False)
    pd.DataFrame(choices).to_csv(OUTPUT_PATH / "validation_selected.csv", index=False)
    frozen = {"flag_action": "review request; no automatic rejection or limit reduction",
              "target_recall": TARGET_RECALL, "max_false_positive_rate": MAX_FALSE_POSITIVE_RATE,
              "decision_rule": "probability >= threshold", "choices": choices,
              "model_files": ARTIFACTS,
              "sha256": {path: hashlib.sha256((PROJECT_PATH/path).read_bytes()).hexdigest()
                         for files in ARTIFACTS.values() for path in files}}
    frozen_path.write_text(json.dumps(frozen, indent=2, allow_nan=False), encoding="utf-8")
    report = "\n".join([
        "OPERATING STRATEGIES: VALIDATION SELECTION ONLY",
        "A flag means a review request in this exercise, not a lending decision.",
        "Protective: recall >=80%, minimize false alerts; ties maximize detected defaults.",
        "Growth: false-positive rate <=5%, maximize detected defaults; ties minimize false alerts.",
        "Remaining ties prefer baseline, then higher threshold. Tied customer scores stay together.",
        "Compare both fitted models; no retraining. Selection uses all distinct validation score cutoffs.",
        "",
        pd.DataFrame(comparisons).round(6).to_string(index=False),
        "",
        "FROZEN SELECTIONS:",
        pd.DataFrame(choices).round(6).to_string(index=False),
        "",
        "Targets are validation constraints, not guarantees for test or future customers.",
        "Growth is shorthand for fewer unnecessary reviews; revenue and actual growth are not measured.",
        "Precision is zero by convention when there are no alerts; it is undefined in practice.",
        "The frozen file records exact thresholds and model hashes. Do not tune to test results.",
    ]) + "\n"
    (OUTPUT_PATH / "selection_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
