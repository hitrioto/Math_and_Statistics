"""Prepare a WoE experiment for review; do not fit a classifier yet."""

from pathlib import Path
import json
import sys

import pandas as pd

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from preprocessing import CATEGORICAL, NUMERICAL
from woe import MIN_BIN_SHARE, MIN_CLASS_COUNT, fit_woe, transform_woe

SPLIT_PATH = PROJECT_PATH / "data" / "splits"
OUTPUT_PATH = PROJECT_PATH / "data" / "woe"
REPORT_PATH = PROJECT_PATH / "reports" / "woe"
MODEL_PATH = PROJECT_PATH / "models" / "woe"
MAX_BINS = 5
SMOOTHING = 0.5


def main():
    train = pd.read_csv(SPLIT_PATH / "train.csv")
    predictors = CATEGORICAL + NUMERICAL
    rules, bins = fit_woe(train[predictors], train["default"], MAX_BINS, SMOOTHING)
    for path in [OUTPUT_PATH, REPORT_PATH, MODEL_PATH]:
        path.mkdir(parents=True, exist_ok=True)
    (MODEL_PATH / "binning_rules.json").write_text(json.dumps(rules, indent=2, allow_nan=False), encoding="utf-8")
    bins.to_csv(REPORT_PATH / "bin_table.csv", index=False)
    bins.loc[bins["needs_review"]].to_csv(REPORT_PATH / "sparse_bins.csv", index=False)
    iv = bins.groupby("feature", as_index=False).agg(
        information_value=("iv_contribution", "sum"),
        bins=("bin", "size"), flagged_bins=("needs_review", "sum"),
    ).sort_values("information_value", ascending=False)
    iv.to_csv(REPORT_PATH / "information_value.csv", index=False)
    unseen_rows = []
    for name in ["train", "validation"]:
        data = train if name == "train" else pd.read_csv(SPLIT_PATH / "validation.csv")
        prepared, unseen = transform_woe(data[predictors], rules)
        prepared.to_csv(OUTPUT_PATH / f"X_{name}.csv", index=False)
        data[["ID", "default"]].to_csv(OUTPUT_PATH / f"y_{name}.csv", index=False)
        unseen_rows.extend({"split": name, **row} for row in unseen)
    pd.DataFrame(unseen_rows, columns=["split", "feature", "category", "records"]).to_csv(
        REPORT_PATH / "unseen_categories.csv", index=False)
    report = "\n".join([
        "WOE PREPARATION: REVIEW BEFORE MODEL FITTING",
        f"Training records: {len(train):,}; predictors: {len(predictors)}.",
        f"Up to {MAX_BINS} training quantile bins per numerical feature; duplicate edges removed.",
        "Categorical codes use the approved mappings; no automatic category merging.",
        "WoE = ln(smoothed non-default share / smoothed default share).",
        f"Add {SMOOTHING} to both class counts in EVERY bin; adjust each class total by bins * smoothing.",
        "IV = sum((non-default share - default share) * WoE). No IV-based feature deletion.",
        f"Flags: record share <{MIN_BIN_SHARE:.0%}, defaults <{MIN_CLASS_COUNT}, OR non-defaults <{MIN_CLASS_COUNT}.",
        f"Flagged bins: {int(bins.needs_review.sum())} of {len(bins)}. No bins were automatically merged.",
        "Smoothing keeps values finite; it does not make sparse bins reliable.",
        "Numerical outer bins cover future extremes; intervals are right closed.",
        "Unseen categories receive neutral WoE=0 and are listed separately.",
        "",
        iv.round(6).to_string(index=False),
        "",
        "IV is a univariate training statistic, not validation performance or causal evidence.",
        "Correlated monthly predictors can repeat the same information.",
        "Inspect bin counts, default rates and WoE in bin_table.csv before deciding on merges.",
        "No monotonicity constraint was imposed. Sparse cutoffs are teaching heuristics.",
        "Only training outcomes determine WoE. Validation outcomes are copied for later evaluation.",
        "No test data loaded and no logistic regression fitted in this step.",
        "Future CV must refit both bins and WoE inside each fold.",
        "Load JSON rules and call woe.transform_woe on original named predictors to reuse.",
        "Rerunning replaces WoE preparation outputs only. X and y files share row order.",
    ]) + "\n"
    (REPORT_PATH / "preparation_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
