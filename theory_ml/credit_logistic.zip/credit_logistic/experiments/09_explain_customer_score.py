"""Optional lesson: explain one validation customer's additive WoE score."""

from pathlib import Path
import hashlib
import json
import sys

import joblib
import numpy as np
import pandas as pd
from scipy.special import expit

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from woe import assign_bins, transform_woe

# Change this ID in Spyder to explain another customer in the validation split.
CUSTOMER_ID = 1
SCORECARD_PATH = PROJECT_PATH / "reports" / "scorecard"
MODEL_PATH = PROJECT_PATH / "models" / "woe" / "logistic_woe.joblib"
OUTPUT_PATH = SCORECARD_PATH / "customers"


def explain_customer(customer, definition, bundle):
    """Return a feature table and full-precision score/probability for one row."""
    if len(customer) != 1:
        raise ValueError("Select exactly one customer.")
    features = definition["features"]
    raw = customer[features]
    rules = definition["binning_rules"]
    mapping = {int(key): value for key, value in rules["education_mapping"].items()}
    mapped = raw.replace({"EDUCATION": mapping})
    X, _ = transform_woe(raw, rules)
    rows = []
    for feature, coefficient in zip(features, bundle["model"].coef_[0]):
        rule = rules["features"][feature]
        bin_id = assign_bins(mapped[feature], rule).iloc[0]
        fallback = bin_id not in rule["woe_by_bin"]
        if rule["kind"] == "numeric":
            edges = [-np.inf] + rule["cut_points"] + [np.inf]
            index = int(bin_id)
            description = f"({edges[index]}, {edges[index+1]}]"
        else:
            description = f"category code {bin_id}"
            if feature in ["EDUCATION", "MARRIAGE"] and bin_id == "0":
                description += " (unknown/undocumented)"
        points = definition["points_by_feature_bin"][feature].get(
            bin_id, definition["unseen_category_points"])
        rows.append({"feature": feature, "original_value": raw[feature].iloc[0],
                     "mapped_value": mapped[feature].iloc[0], "bin": bin_id,
                     "description": description, "woe": X[feature].iloc[0],
                     "coefficient": coefficient, "points": points,
                     "unseen_fallback": fallback})
    table = pd.DataFrame(rows)
    score = definition["base_points"] + table.points.sum()
    probability = float(expit((definition["offset"]-score)/definition["factor"]))
    model_probability = float(bundle["model"].predict_proba(X)[0, 1])
    np.testing.assert_allclose(table.points, -definition["factor"]*table.coefficient*table.woe,
                               atol=1e-10, rtol=0)
    np.testing.assert_allclose(probability, model_probability, atol=1e-12, rtol=0)
    return table, float(score), probability


def main():
    definition = json.loads((SCORECARD_PATH / "scorecard_definition.json").read_text())
    if hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest() != definition["source_sha256"]:
        raise ValueError("The WoE model changed. Rebuild the optional scorecard with file 08 first.")
    bundle = joblib.load(MODEL_PATH)
    if definition["features"] != list(bundle["model"].feature_names_in_):
        raise ValueError("Scorecard feature order does not match the model.")
    data = pd.read_csv(PROJECT_PATH / "data" / "splits" / "validation.csv")
    customer = data.loc[data.ID == CUSTOMER_ID]
    if customer.empty:
        raise ValueError(f"ID {CUSTOMER_ID} is not in validation. Choose an ID from data/splits/validation.csv.")
    table, score, probability = explain_customer(customer, definition, bundle)
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUTPUT_PATH / f"customer_{CUSTOMER_ID}_contributions.csv", index=False)
    report = "\n".join([
        f"OPTIONAL SCORECARD EXPLANATION: CUSTOMER {CUSTOMER_ID}",
        "Source: validation split. This is an explanation of the saved WoE model.",
        f"Shared base points: {definition['base_points']:.6f}",
        f"Sum of feature contributions: {table.points.sum():.6f}",
        f"Total score: {score:.6f}",
        f"Predicted default probability: {probability:.4%}",
        "",
        table.round({"woe": 6, "coefficient": 6, "points": 2}).to_string(index=False),
        "",
        "Shared base points are included once, not once per variable.",
        "Positive contributions raise the score; negative contributions lower it.",
        "Contributions are relative to the shared base, not to an average or ideal customer.",
        "Higher total scores mean lower predicted risk. 600 points corresponds to 20:1 good/bad odds.",
        "All calculations use full precision; rounded displayed rows may not sum exactly.",
        "The outcome column is not used in this explanation or its probability calculation.",
        "Unseen fallback=True means neutral WoE/zero points, not observed evidence of low risk.",
        f"Unseen category fallbacks for this customer: {int(table.unseen_fallback.sum())}.",
        "Missing values are not silently imputed. Repayment -2/0 retain their undocumented meanings.",
        "These contributions are model arithmetic, not causal reasons, improvement advice, or adverse-action codes.",
        "The approved baseline review strategies use a different model; no review flag is assigned here.",
        "Verified: contributions sum to score, and score probability matches the saved WoE model.",
        "No retraining, threshold adjustment, or test-data access. Rerunning replaces this customer's reports.",
    ]) + "\n"
    (OUTPUT_PATH / f"customer_{CUSTOMER_ID}_explanation.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
