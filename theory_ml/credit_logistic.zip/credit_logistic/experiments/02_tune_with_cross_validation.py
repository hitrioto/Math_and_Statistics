"""Choose regularization with grouped cross-validation inside the training split."""

from pathlib import Path
import sys
import warnings

import joblib
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, confusion_matrix, log_loss,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline

# Allow this script to run directly from Spyder or any working directory.
PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from preprocessing import CATEGORICAL, NUMERICAL, build_preprocessor

DATA_PATH = PROJECT_PATH / "data" / "splits"
REPORT_PATH = PROJECT_PATH / "reports" / "cross_validation"
MODEL_PATH = PROJECT_PATH / "models" / "cross_validation"
C_VALUES = [0.01, 0.1, 1.0, 10.0]
FOLDS = 5
RANDOM_SEED = 42
MAX_ITERATIONS = 1000
THRESHOLD = 0.5


def build_model(c):
    return Pipeline([
        ("preprocessing", build_preprocessor()),
        ("model", LogisticRegression(C=c, l1_ratio=0.0, solver="lbfgs",
                                     class_weight=None, max_iter=MAX_ITERATIONS)),
    ])


def fit_model(model, features, target):
    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        model.fit(features, target)


def probability_scores(target, probability):
    return {"log_loss": log_loss(target, probability),
            "roc_auc": roc_auc_score(target, probability),
            "average_precision": average_precision_score(target, probability)}


def main():
    train = pd.read_csv(DATA_PATH / "train.csv")
    predictors = CATEGORICAL + NUMERICAL
    X = train[predictors]
    y = train["default"]
    # Group original predictors before recoding, exactly as in Step 2.
    groups = X.groupby(predictors, dropna=False, sort=False).ngroup()
    splitter = StratifiedGroupKFold(n_splits=FOLDS, shuffle=True, random_state=RANDOM_SEED)
    folds = list(splitter.split(X, y, groups))
    assignments = train[["ID", "default"]].copy()
    assignments["profile_group"] = groups
    assignments["held_out_fold"] = -1
    for fold, (fitting, held_out) in enumerate(folds, start=1):
        assert set(groups.iloc[fitting]).isdisjoint(groups.iloc[held_out])
        assignments.loc[held_out, "held_out_fold"] = fold

    rows = []
    for c in C_VALUES:
        for fold, (fitting, held_out) in enumerate(folds, start=1):
            # Fresh preprocessing for every fit: held-out rows cannot affect
            # category vocabularies or numerical means and scales.
            model = build_model(c)
            fit_model(model, X.iloc[fitting], y.iloc[fitting])
            probability = model.predict_proba(X.iloc[held_out])[:, 1]
            rows.append({"C": c, "fold": fold,
                         "fitting_rows": len(fitting), "held_out_rows": len(held_out),
                         "iterations": int(model.named_steps["model"].n_iter_[0]),
                         **probability_scores(y.iloc[held_out], probability)})
        print(f"Finished five folds for C={c}", flush=True)

    scores = pd.DataFrame(rows)
    summary = scores.groupby("C", as_index=False).agg(
        mean_log_loss=("log_loss", "mean"), std_log_loss=("log_loss", "std"),
        mean_roc_auc=("roc_auc", "mean"), std_roc_auc=("roc_auc", "std"),
        mean_average_precision=("average_precision", "mean"),
        std_average_precision=("average_precision", "std"),
    ).sort_values(["mean_log_loss", "C"])
    # The selection rule is fixed before looking at separate validation results.
    best_c = float(summary.iloc[0]["C"])
    selected = build_model(best_c)
    fit_model(selected, X, y)

    validation = pd.read_csv(DATA_PATH / "validation.csv")
    probability = selected.predict_proba(validation[predictors])[:, 1]
    predicted = (probability >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(validation["default"], predicted, labels=[0, 1]).ravel()
    validation_scores = {
        "C": best_c, **probability_scores(validation["default"], probability),
        "threshold": THRESHOLD,
        "precision": precision_score(validation["default"], predicted, zero_division=0),
        "recall": recall_score(validation["default"], predicted, zero_division=0),
        "true_negative": tn, "false_positive": fp,
        "false_negative": fn, "true_positive": tp,
    }
    predictions = validation[["ID", "default"]].copy()
    predictions["default_probability"] = probability
    predictions["predicted_default"] = predicted

    REPORT_PATH.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.mkdir(parents=True, exist_ok=True)
    scores.to_csv(REPORT_PATH / "fold_scores.csv", index=False)
    summary.to_csv(REPORT_PATH / "cv_summary.csv", index=False)
    assignments.to_csv(REPORT_PATH / "fold_assignments.csv", index=False)
    predictions.to_csv(REPORT_PATH / "validation_predictions.csv", index=False)
    pd.DataFrame([validation_scores]).to_csv(REPORT_PATH / "validation_metrics.csv", index=False)
    joblib.dump(selected, MODEL_PATH / "pipeline.joblib")
    report = "\n".join([
        "CROSS-VALIDATION EXPERIMENT",
        f"Five grouped training folds; seed={RANDOM_SEED}; C candidates={C_VALUES}.",
        "Each candidate uses the same folds. No matching profile crosses a fold boundary.",
        "Encoding and scaling are fitted afresh inside every training fold.",
        "Select the lowest unweighted mean fold log loss; exact ties prefer smaller C.",
        "Standard deviations describe variation across folds, not confidence intervals.",
        "",
        summary.round(6).to_string(index=False),
        "",
        f"Selected C={best_c}; refitted on all {len(train):,} training records.",
        f"Refit iterations: {selected.named_steps['model'].n_iter_[0]}; all fits converged.",
        "Separate validation results (not used to select C):",
        pd.DataFrame([validation_scores]).round(6).to_string(index=False),
        "",
        "No test data was loaded. The baseline artifacts were not modified.",
        "The saved pipeline accepts original named predictors and includes preprocessing.",
        "A small validation improvement is not proof that the selected model is better.",
        "Cross-validation selects model settings; threshold selection is a separate choice.",
        "Rerunning replaces this experiment's outputs only.",
    ]) + "\n"
    (REPORT_PATH / "cv_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
