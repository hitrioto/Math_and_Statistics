"""Fit unscaled WoE logistic regression and compare with the saved baseline."""

from pathlib import Path
import json
import sys
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, confusion_matrix, log_loss,
                             precision_score, recall_score, roc_auc_score)

PROJECT_PATH = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_PATH))
from woe import transform_woe
from artifact_checks import write_prediction_manifest

MODEL_PATH = PROJECT_PATH / "models" / "woe"
REPORT_PATH = PROJECT_PATH / "reports" / "woe"
C = 1.0
THRESHOLD = 0.5
MAX_ITERATIONS = 1000


def main():
    rules = json.loads((MODEL_PATH / "binning_rules.json").read_text())
    features = list(rules["features"])
    datasets = {}
    for name in ["train", "validation"]:
        raw = pd.read_csv(PROJECT_PATH / "data" / "splits" / f"{name}.csv")
        prepared = pd.read_csv(PROJECT_PATH / "data" / "woe" / f"X_{name}.csv")
        labels = pd.read_csv(PROJECT_PATH / "data" / "woe" / f"y_{name}.csv")
        # Avoid silently combining stale prepared files with new rules or splits.
        pd.testing.assert_frame_equal(labels, raw[["ID", "default"]])
        transformed, _ = transform_woe(raw[features], rules)
        pd.testing.assert_frame_equal(prepared, transformed, check_exact=False, rtol=1e-10, atol=1e-12)
        datasets[name] = (prepared, labels)

    model = LogisticRegression(C=C, l1_ratio=0.0, solver="lbfgs",
                               class_weight=None, max_iter=MAX_ITERATIONS)
    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        model.fit(datasets["train"][0], datasets["train"][1]["default"])

    baseline_predictions = pd.read_csv(PROJECT_PATH / "reports" / "baseline" / "validation_predictions.csv")
    pd.testing.assert_frame_equal(baseline_predictions[["ID", "default"]], datasets["validation"][1])
    rows = []
    for name, (X, labels) in datasets.items():
        target = labels["default"]
        probability = model.predict_proba(X)[:, 1]
        predicted = (probability >= THRESHOLD).astype(int)
        tn, fp, fn, tp = confusion_matrix(target, predicted, labels=[0, 1]).ravel()
        rows.append({"split": name, "roc_auc": roc_auc_score(target, probability),
                     "average_precision": average_precision_score(target, probability),
                     "log_loss": log_loss(target, probability),
                     "precision": precision_score(target, predicted, zero_division=0),
                     "recall": recall_score(target, predicted, zero_division=0),
                     "true_negative": tn, "false_positive": fp,
                     "false_negative": fn, "true_positive": tp})
        output = labels.copy()
        output["default_probability"] = probability
        output["predicted_default"] = predicted
        output.to_csv(REPORT_PATH / f"{name}_predictions.csv", index=False)

    metrics = pd.DataFrame(rows)
    baseline = pd.read_csv(PROJECT_PATH / "reports" / "baseline" / "metrics.csv")
    comparison = pd.concat([baseline.assign(model="baseline"), metrics.assign(model="woe")], ignore_index=True)
    comparison = comparison[["model"] + metrics.columns.tolist()]
    coefficients = pd.DataFrame({"feature": features, "coefficient": model.coef_[0],
                                 "odds_ratio_per_woe_unit": np.exp(model.coef_[0]),
                                 "positive_sign_review": model.coef_[0] > 0})
    metrics.to_csv(REPORT_PATH / "metrics.csv", index=False)
    comparison.to_csv(REPORT_PATH / "baseline_comparison.csv", index=False)
    coefficients.to_csv(REPORT_PATH / "coefficients.csv", index=False)
    # Bundle the exact fitted rules with the model so future preparation cannot
    # silently replace the transformation needed by this saved classifier.
    joblib.dump({"model": model, "rules": rules, "features": features,
                 "threshold": THRESHOLD}, MODEL_PATH / "logistic_woe.joblib")
    write_prediction_manifest(PROJECT_PATH, "woe", ["models/woe/logistic_woe.joblib"])
    positive = coefficients.loc[coefficients.positive_sign_review, "feature"].tolist()
    flagged_bins = len(pd.read_csv(REPORT_PATH / "sparse_bins.csv"))
    report = "\n".join([
        "WOE LOGISTIC REGRESSION: FIRST COMPARISON",
        f"All {len(features)} WoE predictors retained, without scaling or automatic sparse-bin merging.",
        f"L2; C={C}; lbfgs; class_weight=None; threshold={THRESHOLD}.",
        f"Converged in {model.n_iter_[0]} iterations (limit {MAX_ITERATIONS}).",
        "Only training data fitted the model. No test data was loaded.",
        "",
        comparison.round(4).to_string(index=False),
        "",
        f"Intercept: {model.intercept_[0]:.6f}",
        "Positive WoE indicates relatively more non-defaults; negative coefficients are generally expected.",
        f"Positive coefficients to inspect: {', '.join(positive) or 'none'}.",
        "Correlated predictors can reverse conditional signs; no signs were forced or features removed.",
        "exp(coefficient) is the odds multiplier per one WoE-unit increase, other inputs fixed.",
        "It is not a probability multiplier or causal effect. The intercept applies when all WoE values are zero.",
        "",
        coefficients.round(6).to_string(index=False),
        "",
        "Training metrics are optimistic: training outcomes were also used to construct WoE.",
        f"The {flagged_bins} flagged bins remain; smoothing does not eliminate rare-bin uncertainty.",
        "Same C does not mean equivalent regularization across differently scaled representations.",
        "Compare validation ranking, log loss, and precision/recall together; no final winner is selected.",
        "Future WoE CV must refit bins and WoE within each fold; do not CV these prepared matrices.",
        "Reuse: bundle = joblib.load(models/woe/logistic_woe.joblib);",
        "X, unseen = transform_woe(raw[bundle['features']], bundle['rules']);",
        "probabilities = bundle['model'].predict_proba(X)[:, 1]. Inspect unseen reports.",
        "Rerunning overwrites this model's results only; baseline artifacts remain unchanged.",
    ]) + "\n"
    (REPORT_PATH / "training_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
