"""Explore the baseline's validation trade-offs without fitting another model."""

from pathlib import Path

import pandas as pd
from sklearn.metrics import confusion_matrix, precision_score, recall_score

PROJECT_PATH = Path(__file__).resolve().parents[1]
INPUT_PATH = PROJECT_PATH / "reports" / "baseline" / "validation_predictions.csv"
OUTPUT_PATH = PROJECT_PATH / "reports" / "thresholds"
THRESHOLDS = [0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90]


def main():
    data = pd.read_csv(INPUT_PATH)
    rows = []
    for threshold in THRESHOLDS:
        predicted = (data["default_probability"] >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(data["default"], predicted, labels=[0, 1]).ravel()
        rows.append({
            "threshold": threshold,
            "precision": precision_score(data["default"], predicted, zero_division=0),
            "recall": recall_score(data["default"], predicted, zero_division=0),
            "alerts": int(predicted.sum()), "alert_rate": predicted.mean(),
            "true_negative": tn, "false_positive": fp,
            "missed_defaults": fn, "detected_defaults": tp,
        })
    comparison = pd.DataFrame(rows)
    OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
    comparison.to_csv(OUTPUT_PATH / "threshold_comparison.csv", index=False)
    report = "\n".join([
        "THRESHOLD EXPERIMENT: BASELINE VALIDATION PREDICTIONS",
        "No model was retrained; no test data was loaded.",
        "Probability quality (ROC-AUC, average precision, log loss) is unchanged.",
        "Only the rule probability >= threshold changes.",
        "Precision is reported as 0 if there are no alerts; it is then undefined in practice.",
        "",
        comparison.round(4).to_string(index=False),
        "",
        "Lower thresholds usually increase recall and the number of false alerts.",
        "Precision need not increase monotonically as the threshold increases.",
        "Choose a threshold only after deciding costs, review capacity, or recall goals.",
        "This experiment does not select a winning threshold or overwrite the baseline.",
        "Reusing validation results for many choices can overfit the validation set.",
    ]) + "\n"
    (OUTPUT_PATH / "threshold_report.txt").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
