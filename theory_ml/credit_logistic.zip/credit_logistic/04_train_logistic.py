"""Fit the first logistic regression and inspect training/validation performance."""

from pathlib import Path
import warnings

import joblib
import numpy as np
import pandas as pd
from artifact_checks import check_prepared, write_prediction_manifest
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, confusion_matrix, log_loss,
                             precision_score, recall_score, roc_auc_score)

PROJECT_PATH = Path(__file__).resolve().parent
DATA_PATH = PROJECT_PATH / "data" / "prepared"
MODEL_PATH = PROJECT_PATH / "models" / "baseline"
REPORT_PATH = PROJECT_PATH / "reports" / "baseline"
C = 1.0
MAX_ITERATIONS = 1000
THRESHOLD = 0.5


def evaluate(model, features, target, name):
    probabilities = model.predict_proba(features)[:, 1]
    predictions = (probabilities >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(target, predictions, labels=[0, 1]).ravel()
    metrics = {
        "split": name,
        "roc_auc": roc_auc_score(target, probabilities),
        "average_precision": average_precision_score(target, probabilities),
        "log_loss": log_loss(target, probabilities),
        "precision": precision_score(target, predictions, zero_division=0),
        "recall": recall_score(target, predictions, zero_division=0),
        "true_negative": tn, "false_positive": fp,
        "false_negative": fn, "true_positive": tp,
    }
    return metrics, probabilities, predictions


def coefficient_table(model, features, preprocessor):
    columns = preprocessor.named_steps["columns"]
    encoder = columns.named_transformers_["category"]
    categorical = columns.transformers_[0][2]
    numerical = columns.transformers_[1][2]
    meanings = []
    for column, categories, reference in zip(categorical, encoder.categories_, encoder.drop_idx_):
        for index, value in enumerate(categories):
            if index != reference:
                meanings.append(f"{column}: code {value} versus reference code {categories[reference]}")
    meanings.extend(f"{column}: increase of one training standard deviation" for column in numerical)
    return pd.DataFrame({
        "feature": features.columns,
        "coefficient": model.coef_[0],
        "odds_ratio": np.exp(model.coef_[0]),
        "interpretation": meanings,
    })


def main():
    X_train = pd.read_csv(DATA_PATH / "X_train.csv")
    y_train = pd.read_csv(DATA_PATH / "y_train.csv")
    X_validation = pd.read_csv(DATA_PATH / "X_validation.csv")
    y_validation = pd.read_csv(DATA_PATH / "y_validation.csv")
    preprocessor = joblib.load(MODEL_PATH / "preprocessor.joblib")
    expected = preprocessor.named_steps["columns"].get_feature_names_out().tolist()
    if X_train.columns.tolist() != expected or X_validation.columns.tolist() != expected:
        raise ValueError("Prepared columns do not match the preprocessor. Rerun Step 3.")
    for name, X, labels in [("train", X_train, y_train), ("validation", X_validation, y_validation)]:
        raw = pd.read_csv(PROJECT_PATH / "data" / "splits" / f"{name}.csv")
        check_prepared(raw, X, labels, preprocessor)

    # In our installed sklearn version, l1_ratio=0 selects L2 regularization.
    # C controls its strength: smaller C means stronger regularization.
    model = LogisticRegression(C=C, l1_ratio=0.0, solver="lbfgs",
                               class_weight=None, max_iter=MAX_ITERATIONS)
    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        model.fit(X_train, y_train["default"])

    REPORT_PATH.mkdir(parents=True, exist_ok=True)
    results = []
    for name, features, labels in [("train", X_train, y_train),
                                    ("validation", X_validation, y_validation)]:
        metrics, probabilities, predictions = evaluate(model, features, labels["default"], name)
        results.append(metrics)
        if name == "validation":
            output = labels.copy()
            output["default_probability"] = probabilities
            output["predicted_default"] = predictions
            output.to_csv(REPORT_PATH / "validation_predictions.csv", index=False)

    metrics = pd.DataFrame(results)
    metrics.to_csv(REPORT_PATH / "metrics.csv", index=False)
    coefficients = coefficient_table(model, X_train, preprocessor)
    coefficients.to_csv(REPORT_PATH / "coefficients.csv", index=False)
    joblib.dump(model, MODEL_PATH / "logistic_baseline.joblib")
    write_prediction_manifest(PROJECT_PATH, "baseline", [
        "models/baseline/preprocessor.joblib", "models/baseline/logistic_baseline.joblib"])

    report = [
        "STEP 4: BASELINE LOGISTIC REGRESSION",
        f"L2 regularization; C={C}; solver=lbfgs; class_weight=None.",
        f"Converged without a convergence warning in {model.n_iter_[0]} iterations (limit {MAX_ITERATIONS}).",
        f"Classification threshold: {THRESHOLD}; positive class: default=1.",
        "Training data alone fitted the model. Test data was not loaded.",
        "",
        metrics.round(4).to_string(index=False),
        "",
        "Confusion matrix counts: rows are actual classes, columns predicted classes.",
        "[[true_negative, false_positive], [false_negative, true_positive]]",
        "Higher ROC-AUC and average precision are better; lower log loss is better.",
        "Precision: fraction of predicted defaults that defaulted.",
        "Recall: fraction of actual defaults detected at the initial threshold.",
        "",
        f"Intercept: {model.intercept_[0]:.6f}",
        "z = intercept + sum(coefficient * prepared feature)",
        "Probability of default = 1 / (1 + exp(-z)).",
        "Log loss penalizes wrong, confident probabilities; fitting also adds an L2 penalty.",
        "exp(coefficient) is an odds multiplier, holding other model inputs fixed.",
        "It is not a probability multiplier or evidence of a causal effect.",
        "The intercept corresponds to reference categories and training-mean numerical values.",
        "Education/marriage code 0 means unknown/undocumented, distinct from other.",
        "Repayment -2/0 remain uninterpreted codes. Unseen codes share reference encoding.",
        "Correlated predictors and sparse categories can make individual coefficients unstable.",
        "",
        "COEFFICIENTS (original feature order):",
        coefficients.round(4).to_string(index=False),
        "",
        "Reuse: load preprocessor.joblib and logistic_baseline.joblib together.",
        "Transform original named predictors, wrap the result in a DataFrame with",
        "the preprocessor's feature names, then call model.predict_proba(X)[:, 1].",
        "Rerun Step 4 after changing preprocessing; keep the matching saved files together.",
        "Tuning, threshold selection, and final test evaluation remain for later steps.",
    ]
    text = "\n".join(report) + "\n"
    (REPORT_PATH / "training_report.txt").write_text(text, encoding="utf-8")
    print("\n".join(report[:22]))
    print("\nFirst 10 coefficients:")
    print(coefficients.head(10).round(4).to_string(index=False))
    print("\nFull report and outputs:", REPORT_PATH)


if __name__ == "__main__":
    main()
