"""Threshold comparisons for review strategies; higher probability means higher risk."""

import numpy as np
import pandas as pd


def threshold_table(target, probability):
    """Evaluate all distinct score cutoffs, keeping tied scores together."""
    y = np.asarray(target)
    p = np.asarray(probability)
    if len(y) != len(p) or set(np.unique(y)) != {0, 1}:
        raise ValueError("Expected aligned binary outcomes containing both classes.")
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("Probabilities must be finite and between zero and one.")
    order = np.argsort(-p, kind="stable")
    y, p = y[order], p[order]
    # Evaluate only after the last member of each tied score group.
    ends = np.r_[np.flatnonzero(p[:-1] != p[1:]), len(p)-1]
    alerts = np.r_[0, ends+1]
    tp = np.r_[0, np.cumsum(y)[ends]]
    fp = alerts-tp
    positives, negatives = y.sum(), len(y)-y.sum()
    return pd.DataFrame({
        "threshold": np.r_[np.nextafter(1.0, np.inf), p[ends]],
        "true_positive": tp, "false_positive": fp,
        "false_negative": positives-tp, "true_negative": negatives-fp,
        "recall": tp/positives, "false_positive_rate": fp/negatives,
        "precision": np.divide(tp, alerts, out=np.zeros(len(alerts), dtype=float), where=alerts != 0),
        "alerts": alerts, "alert_rate": alerts/len(y),
    })


def choose_strategy(candidates, strategy, target_recall=0.8, max_fpr=0.05):
    # Primary objectives first; tie-breakers prefer more useful detections,
    # then the baseline and a higher threshold for reproducibility.
    if strategy == "protective":
        feasible = candidates.loc[candidates.recall >= target_recall]
        columns = ["false_positive", "true_positive", "model", "threshold"]
        ascending = [True, False, True, False]
    elif strategy == "growth":
        feasible = candidates.loc[candidates.false_positive_rate <= max_fpr]
        columns = ["true_positive", "false_positive", "model", "threshold"]
        ascending = [False, True, True, False]
    else:
        raise ValueError("Unknown strategy.")
    return feasible.sort_values(columns, ascending=ascending).iloc[0]
