CREDIT LOGISTIC -- REPRODUCIBLE TEACHING PACKAGE
==============================================

Source code, three notebooks, guides and dependencies only. No data, trained
models, reports, notebook outputs, caches, virtual environment or history.
Python 3.13 recommended; verified environment: Python 3.13.16.

QUICK START (Windows PowerShell)
Extract the ZIP and open a terminal in the extracted credit_logistic folder:
  py -3.13 -m venv .venv
  .\.venv\Scripts\python.exe -m pip install -r requirements-notebooks.txt
  .\.venv\Scripts\python.exe download_data.py
  .\.venv\Scripts\python.exe run_all.py
  .\.venv\Scripts\python.exe -m unittest discover -s tests -v
  .\.venv\Scripts\python.exe -m notebook notebooks

On macOS/Linux, use python3.13 -m venv .venv and .venv/bin/python.
An existing compatible environment is also fine. For scripts only, install
requirements.txt. Internet is needed for package installation and downloading.
The downloader uses the standard library and needs no ML dependencies.

Select this environment's kernel in Jupyter. If it is not offered:
  .\.venv\Scripts\python.exe -m ipykernel install --user --name credit-logistic --display-name "Credit Logistic"
Then select Credit Logistic. Check the Python path printed in notebook setup.

DATA SOURCE AND ATTRIBUTION
Yeh, I. (2009). Default of Credit Card Clients [Dataset].
UCI Machine Learning Repository. https://doi.org/10.24432/C55S3H
  https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients
License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/

download_data.py fetches the official UCI ZIP, reads only the expected workbook
and checks its SHA-256 against the original exercise. It saves
data/default of credit card clients.xls without retaining the compressed ZIP.
Matching existing data is reused; differing data is not overwritten. Changed
upstream content fails verification. No alternative version is silently used.
Data is not bundled. See data_dictionary.txt for the column descriptions.

RUN ORDER AND SCOPE
run_all.py runs these scripts in order using its own interpreter:
  Root 01-04: inspection, grouped splitting, preparation, baseline logistic fit.
  experiments/01: compare thresholds using validation probabilities.
  experiments/02: grouped cross-validation, C selected by mean log loss.
  experiments/03-04: training-only WoE rules and WoE logistic regression.
  experiments/05: calibration and diagnostics.
  experiments/06: select and freeze validation operating strategies.
  experiments/07: evaluate the frozen choices on the historical test split.
  experiments/08-09: optional scorecard points and customer explanation.

To omit scorecard steps, use python run_all.py --skip-scorecard.
The first two notebooks then work; the third and the full test suite require
scorecard outputs. To add them afterward, run experiments/08_build_scorecard.py
and experiments/09_explain_customer_score.py individually.

Generated data go to data/splits/, data/prepared/ and data/woe/ as defined by
the scripts; fitted objects go to models/, results/charts to reports/, and
console transcripts to reports/run_logs/. No historical snapshot is required.

RERUN BOUNDARIES
The runner checks for frozen policies/final results BEFORE fitting anything.
It refuses to overwrite a completed exercise. Use a fresh ZIP extraction for
a full reproduction; do not delete the safeguards to tune to exposed test data.
If a run fails, inspect its transcript and resume the remaining individual
scripts as appropriate. Training scripts can replace earlier generated files.

The original test set was already examined. Regeneration reproduces the
historical exercise, not a new untouched holdout. Protective and growth rules
are educational review flags, not real lending decisions. The scorecard is
an optional presentation of the WoE logistic model, not a separately fitted model.

NOTEBOOKS (run_all.py must run first)
  notebooks/01_logistic_regression.ipynb
  notebooks/02_woe_logistic_regression.ipynb
  notebooks/03_optional_scorecard.ipynb
Each runs independently in a fresh kernel and writes only to notebooks/outputs/.
They mix in-memory demonstrations with reading regenerated experiment results.
The distributed notebooks have cleared outputs. Restart kernel and run all.
step_objectives.txt and development_decisions.txt provide teaching context.
The latter describes some historical work not included in the source package.

MAINTENANCE
tools/build_first_notebook.py, build_second_notebook.py, build_third_notebook.py
rebuild notebooks and overwrite direct notebook edits, clearing outputs.
Execute a notebook with a fresh kernel using the current interpreter:
  python tools/execute_notebook.py 01_logistic_regression.ipynb
  python tools/execute_notebook.py 02_woe_logistic_regression.ipynb
  python tools/execute_notebook.py 03_optional_scorecard.ipynb
The executor checks that data, models and reports remain unchanged.
