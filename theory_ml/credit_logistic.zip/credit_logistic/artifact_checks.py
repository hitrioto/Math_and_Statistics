"""Small checks linking prepared rows and predictions to their source artifacts."""

import hashlib
import json

import joblib
import numpy as np
import pandas as pd

from woe import transform_woe


def check_prepared(raw, prepared, labels, preprocessor):
    try:
        pd.testing.assert_frame_equal(labels, raw[["ID", "default"]])
        expected = pd.DataFrame(
            preprocessor.transform(raw.drop(columns=["ID", "default"])),
            columns=preprocessor.named_steps["columns"].get_feature_names_out())
        pd.testing.assert_frame_equal(prepared, expected, check_exact=False, rtol=1e-10, atol=1e-12)
    except AssertionError as error:
        raise ValueError("Prepared rows, labels, or preprocessing disagree. Rebuild preparation together.") from error


def check_predictions(raw, saved, probability):
    try:
        pd.testing.assert_frame_equal(saved[["ID", "default"]], raw[["ID", "default"]])
        np.testing.assert_allclose(saved.default_probability, probability, rtol=1e-10, atol=1e-12)
    except AssertionError as error:
        raise ValueError("Saved predictions do not match these rows and this model. Rebuild the prediction report.") from error


def verify_validation_predictions(project, name, saved):
    raw = pd.read_csv(project / "data/splits/validation.csv")
    if name == "baseline":
        preprocessing = joblib.load(project / "models/baseline/preprocessor.joblib")
        model = joblib.load(project / "models/baseline/logistic_baseline.joblib")
        X = pd.DataFrame(preprocessing.transform(raw.drop(columns=["ID", "default"])),
                         columns=preprocessing.named_steps["columns"].get_feature_names_out())
    elif name == "woe":
        bundle = joblib.load(project / "models/woe/logistic_woe.joblib")
        model = bundle["model"]
        X, _ = transform_woe(raw[bundle["features"]], bundle["rules"])
    else:
        raise ValueError("Unknown model name.")
    check_predictions(raw, saved, model.predict_proba(X)[:, 1])


def write_prediction_manifest(project, name, model_files):
    """For future training runs: record inputs and predictions as one auditable set."""
    paths = model_files + ["data/splits/train.csv", "data/splits/validation.csv",
                          f"reports/{name}/validation_predictions.csv"]
    manifest = {"model": name, "sha256": {
        path: hashlib.sha256((project / path).read_bytes()).hexdigest() for path in paths}}
    (project / f"reports/{name}/prediction_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8")
