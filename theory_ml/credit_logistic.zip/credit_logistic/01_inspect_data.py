"""Exercise 1: inspect the original UCI credit-card dataset before cleaning.

Requires pandas and xlrd. Reads the local Excel file and prints observations.
"""

from pathlib import Path

import pandas as pd

PROJECT_PATH = Path(__file__).resolve().parent
DATA_PATH = PROJECT_PATH / "data" / "default of credit card clients.xls"
TARGET = "default payment next month"
SAMPLES = 5

PAYMENT_STATUS = ["PAY_0", "PAY_2", "PAY_3", "PAY_4", "PAY_5", "PAY_6"]
BILL_AMOUNTS = [f"BILL_AMT{month}" for month in range(1, 7)]
PAYMENT_AMOUNTS = [f"PAY_AMT{month}" for month in range(1, 7)]

# These are the codes described in UCI's online summary, not cleaning rules.
DOCUMENTED_CODES = {
    "SEX": [1, 2],
    "EDUCATION": [1, 2, 3, 4],
    "MARRIAGE": [1, 2, 3],
}
for column in PAYMENT_STATUS:
    DOCUMENTED_CODES[column] = [-1, 1, 2, 3, 4, 5, 6, 7, 8, 9]


def load_data():
    # Excel row 1 contains X1, X2, ..., Y. Row 2 contains the useful names.
    # pandas counts rows from zero, so header=1 selects Excel row 2.
    return pd.read_excel(DATA_PATH, sheet_name="Data", header=1, engine="xlrd")


def inspect_structure(data):
    print(f"Rows: {len(data):,}; columns: {len(data.columns)}")
    print("Columns include one ID, 23 predictors, and one target.")
    preview_columns = ["ID", "LIMIT_BAL", "AGE", "PAY_0", "BILL_AMT1", "PAY_AMT1", TARGET]
    print("\nFIRST ROWS (selected columns):")
    print(data[preview_columns].head(SAMPLES).to_string(index=False))

    summary = pd.DataFrame({
        "data_type": data.dtypes.astype(str),
        "missing": data.isna().sum(),
        "distinct_values": data.nunique(),
    })
    print("\nCOLUMN SUMMARY:")
    print(summary.to_string())
    print("Numeric storage does not make a coded category a continuous variable.")


def inspect_target(data):
    counts = data[TARGET].value_counts().sort_index()
    print("\nTARGET: 0 = no default, 1 = default next month")
    for label, count in counts.items():
        print(f"{label}: {count:,} records ({count / len(data):.2%})")
    print(f"Always predict no default: {counts.get(0, 0) / len(data):.2%} accuracy")


def inspect_duplicates(data):
    predictor_columns = data.columns.drop(["ID", TARGET]).tolist()
    print("\nREPEATED RECORDS:")
    print("Repeated IDs:", data["ID"].duplicated().sum())
    print("Repeated full rows:", data.duplicated().sum())
    print("Repeated rows excluding ID:", data.drop(columns="ID").duplicated().sum())
    print("Repeated predictor rows:", data[predictor_columns].duplicated().sum())
    outcomes_per_profile = data.groupby(predictor_columns, dropna=False)[TARGET].nunique()
    print("Predictor groups with different outcomes:", (outcomes_per_profile > 1).sum())
    print("Repeated-row counts exclude the first occurrence. Matching profiles may be different people.")


def inspect_categories(data):
    print("\nCATEGORY COUNTS:")
    for column, documented in DOCUMENTED_CODES.items():
        counts = data[column].value_counts(dropna=False).sort_index()
        print(f"\n{column}: {counts.to_dict()}")
        unexplained = data.loc[~data[column].isin(documented), column].value_counts().sort_index()
        if not unexplained.empty:
            print("Codes not described in the UCI summary:", unexplained.to_dict())
    print("Unexplained codes are not automatically missing or invalid; investigate their meaning.")


def inspect_numbers(data):
    columns = ["LIMIT_BAL", "AGE"] + BILL_AMOUNTS + PAYMENT_AMOUNTS
    print("\nNUMERICAL SUMMARY (money in New Taiwan dollars; age in years):")
    print(data[columns].describe().T.round(2).to_string())
    print("\nNUMBER OF NEGATIVE BILL AMOUNTS:")
    print((data[BILL_AMOUNTS] < 0).sum().to_string())
    print("Negative bills and unusually large amounts need interpretation before correction.")


def main():
    data = load_data()
    print("UCI DEFAULT OF CREDIT CARD CLIENTS")
    print("Source file:", DATA_PATH)
    inspect_structure(data)
    inspect_target(data)
    inspect_duplicates(data)
    inspect_categories(data)
    inspect_numbers(data)

    print("\nEXERCISE QUESTIONS:")
    print("1. Which columns are identifiers, categories, numerical predictors, and the target?")
    print("2. Which codes are absent from the dictionary? Does no blank data mean no ambiguity?")
    print("3. Why is an always-no-default classifier a useful baseline?")
    print("4. Do matching predictor values necessarily identify the same customer?")
    print("5. What might negative bill amounts mean, and what evidence would justify changing them?")
    print("6. Which preparation choices must be learned after splitting the data?")
    print("\nInspection complete. No records were changed or removed.")


if __name__ == "__main__":
    main()
