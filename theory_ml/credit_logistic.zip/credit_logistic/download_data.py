"""Download the original UCI workbook with only the Python standard library."""
import hashlib
import io
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
URL = 'https://archive.ics.uci.edu/static/public/350/default%2Bof%2Bcredit%2Bcard%2Bclients.zip'
FILENAME = 'default of credit card clients.xls'
SHA256 = '30c6be3abd8dcfd3e6096c828bad8c2f011238620f5369220bd60cfc82700933'


def main():
    destination = ROOT / 'data' / FILENAME
    if destination.exists():
        if hashlib.sha256(destination.read_bytes()).hexdigest() != SHA256:
            raise ValueError('Existing workbook differs from the original; left untouched.')
        print('Original workbook already present and verified:', destination)
        return
    print('Downloading:', URL, flush=True)
    with urlopen(URL, timeout=60) as response:
        payload = response.read()
    # Read only the expected member; never extract archive-provided paths.
    with ZipFile(io.BytesIO(payload)) as archive:
        workbook = archive.read(FILENAME)
    if hashlib.sha256(workbook).hexdigest() != SHA256:
        raise ValueError('Downloaded workbook checksum mismatch; no data saved.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(workbook)
    print('Saved and verified:', destination)


if __name__ == '__main__':
    main()
