"""Generate a fresh exercise, including the optional scorecard by default."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-scorecard', action='store_true', help='Stop after final logistic strategy evaluation.')
    args = parser.parse_args()
    # Check before any fitting: never partially overwrite a completed exercise.
    if (ROOT / 'reports/strategies/frozen_strategies.json').exists() or (ROOT / 'reports/strategies/test_report.txt').exists():
        raise SystemExit('This copy already has frozen choices/results. Read them or use a fresh ZIP extraction.')
    if not (ROOT / 'data/default of credit card clients.xls').exists():
        raise SystemExit('Run python download_data.py first.')
    scripts = sorted(ROOT.glob('[0-9][0-9]_*.py'))
    scripts += [p for p in sorted((ROOT / 'experiments').glob('[0-9][0-9]_*.py'))
                if not args.skip_scorecard or int(p.name[:2]) < 8]
    logs = ROOT / 'reports/run_logs'
    logs.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, PYTHONIOENCODING='utf-8', MPLBACKEND='Agg')
    for script in scripts:
        result = subprocess.run([sys.executable, str(script)], cwd=ROOT, env=environment,
                                capture_output=True, encoding='utf-8')
        log = logs / (script.parent.name + '_' + script.stem + '.txt')
        log.write_text(result.stdout + result.stderr, encoding='utf-8')
        if result.returncode:
            raise RuntimeError(f'{script.name} failed. See {log}')
        print('Completed:', script.relative_to(ROOT), flush=True)
    print('Exercise generated. Notebooks can now be run independently.')


if __name__ == '__main__':
    main()
