"""Protect row alignment, policy selection, and scorecard arithmetic."""
from pathlib import Path
import importlib.util
import json
import sys
import unittest

import joblib
import numpy as np
import pandas as pd

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from artifact_checks import check_prepared, check_predictions
from operating_strategies import threshold_table, choose_strategy
from preprocessing import CATEGORICAL, NUMERICAL, build_preprocessor


class WorkflowTests(unittest.TestCase):
    def test_tied_and_boundary_thresholds(self):
        for y, p in [([0, 1, 1, 0], [.5, .5, .9, .1]), ([0, 1], [1., 1.]), ([0, 1], [0., 0.])]:
            table = threshold_table(y, p)
            for row in table.itertuples():
                flags = np.asarray(p) >= row.threshold
                self.assertEqual(flags.sum(), row.alerts)
                self.assertEqual((flags & (np.asarray(y) == 1)).sum(), row.true_positive)
            candidates = table.assign(model="baseline")
            protective = choose_strategy(candidates, "protective")
            growth = choose_strategy(candidates, "growth")
            self.assertGreaterEqual(protective.recall, .8)
            self.assertEqual(protective.false_positive, candidates.loc[candidates.recall >= .8, "false_positive"].min())
            self.assertLessEqual(growth.false_positive_rate, .05)
            self.assertEqual(growth.true_positive, candidates.loc[candidates.false_positive_rate <= .05, "true_positive"].max())

    def test_stale_predictions_rejected(self):
        raw = pd.DataFrame({"ID": [1, 2], "default": [0, 1]})
        saved = raw.assign(default_probability=[.1, .8])
        check_predictions(raw, saved, [.1, .8])
        with self.assertRaises(ValueError):
            check_predictions(raw, saved, [.3, .7])
        with self.assertRaises(ValueError):
            check_predictions(raw, saved.iloc[::-1].reset_index(drop=True), [.8, .1])

    def test_shuffled_prepared_rows_rejected(self):
        raw = pd.DataFrame({c: [1, 2, 1] for c in CATEGORICAL})
        for column in NUMERICAL:
            raw[column] = [10, 20, 40]
        raw["ID"], raw["default"] = [1, 2, 3], [0, 1, 0]
        processor = build_preprocessor().fit(raw[CATEGORICAL + NUMERICAL])
        X = pd.DataFrame(processor.transform(raw[CATEGORICAL + NUMERICAL]),
                         columns=processor.named_steps["columns"].get_feature_names_out())
        check_prepared(raw, X, raw[["ID", "default"]], processor)
        with self.assertRaises(ValueError):
            check_prepared(raw, X.iloc[::-1].reset_index(drop=True), raw[["ID", "default"]], processor)

    def test_saved_customer_score_and_outcome_independence(self):
        spec = importlib.util.spec_from_file_location("explanation", PROJECT / "experiments/09_explain_customer_score.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        definition = json.loads((PROJECT / "reports/scorecard/scorecard_definition.json").read_text())
        bundle = joblib.load(PROJECT / "models/woe/logistic_woe.joblib")
        raw = pd.read_csv(PROJECT / "data/splits/validation.csv").head(1)
        table, score, probability = module.explain_customer(raw, definition, bundle)
        self.assertAlmostEqual(score, definition["base_points"] + table.points.sum(), places=10)
        raw["default"] = 1 - raw["default"]
        _, changed_score, changed_probability = module.explain_customer(raw, definition, bundle)
        self.assertEqual(score, changed_score)
        self.assertEqual(probability, changed_probability)


if __name__ == "__main__":
    unittest.main()
