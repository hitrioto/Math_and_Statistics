"""Regression checks for reusable WoE rules; no model fitting or file writes."""

from pathlib import Path
import json
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from preprocessing import CATEGORICAL, NUMERICAL
from woe import fit_woe, transform_woe


class WoeTests(unittest.TestCase):
    def setUp(self):
        self.X = pd.DataFrame({column: [1, 1, 2, 2] for column in CATEGORICAL})
        for column in NUMERICAL:
            self.X[column] = 7
        self.y = pd.Series([0, 0, 1, 1])
        self.rules, self.table = fit_woe(self.X, self.y)

    def test_float_categories_and_json_roundtrip(self):
        rules = json.loads(json.dumps(self.rules, allow_nan=False))
        original, _ = transform_woe(self.X, rules)
        floats, unseen = transform_woe(self.X.astype(float), rules)
        pd.testing.assert_frame_equal(original, floats)
        self.assertEqual(unseen, [])

    def test_zero_counts_and_constant_columns(self):
        table = self.table[self.table.feature == "SEX"].sort_values("bin")
        np.testing.assert_allclose(table.woe, [np.log(5), -np.log(5)])
        totals = self.table.groupby("feature")[["default_share", "non_default_share"]].sum()
        np.testing.assert_allclose(totals, 1)
        self.assertTrue(np.isfinite(self.table.woe).all())

    def test_unseen_and_numerical_extremes(self):
        probe = self.X.copy()
        probe["SEX"] = 99
        probe["AGE"] = [-1e9, 0, 1e9, 10]
        result, unseen = transform_woe(probe, self.rules)
        self.assertTrue(result.SEX.eq(0).all())
        self.assertEqual(unseen, [{"feature": "SEX", "category": "99", "records": 4}])
        self.assertTrue(np.isfinite(result.to_numpy()).all())

    def test_invalid_fit_inputs(self):
        with self.assertRaises(ValueError):
            fit_woe(self.X, self.y.iloc[:3])
        with self.assertRaises(ValueError):
            fit_woe(self.X, self.y, smoothing=0)


if __name__ == "__main__":
    unittest.main()
