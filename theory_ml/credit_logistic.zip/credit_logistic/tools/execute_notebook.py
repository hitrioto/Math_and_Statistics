"""Execute one lesson by filename, preserving models, reports, snapshots and data."""
from pathlib import Path
import hashlib
import os
import sys

PROJECT = Path(__file__).resolve().parents[1]
allowed = ["01_logistic_regression.ipynb", "02_woe_logistic_regression.ipynb", "03_optional_scorecard.ipynb"]
if len(sys.argv) != 2 or sys.argv[1] not in allowed:
    raise SystemExit("Supply one notebook filename: " + ", ".join(allowed))
path = PROJECT / "notebooks" / sys.argv[1]
output = path.parent / "outputs" / path.stem
output.mkdir(parents=True, exist_ok=True)
for key, folder in [("JUPYTER_RUNTIME_DIR", "runtime"), ("IPYTHONDIR", "ipython"),
                    ("MPLCONFIGDIR", "matplotlib_cache")]:
    os.environ[key] = str(output / folder)

import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager


def protected_hashes():
    return {str(f): hashlib.sha256(f.read_bytes()).hexdigest()
            for root in ["models", "reports", "baseline_snapshot", "data"]
            for f in (PROJECT / root).rglob("*") if f.is_file()}


before = protected_hashes()
notebook = nbformat.read(path, as_version=4)
nbformat.validate(notebook)
manager = KernelManager(kernel_name="python3")
manager.kernel_spec.argv[0] = sys.executable
try:
    NotebookClient(notebook, km=manager, timeout=180,
                   resources={"metadata": {"path": str(path.parent)}}).execute()
finally:
    if manager.has_kernel:
        manager.shutdown_kernel(now=True)
    if protected_hashes() != before:
        raise RuntimeError("Protected files changed during notebook execution.")
nbformat.write(notebook, path)
print("Executed", sum(c.cell_type == "code" for c in notebook.cells), "code cells in", path.name)
print("Protected files unchanged:", len(before))
