"""Rebuild the guided notebook source; execution is a separate verification step."""
import json
from pathlib import Path
from textwrap import dedent

cells = []


def md(text):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": dedent(text).strip()})


def code(text):
    cells.append({"cell_type": "code", "metadata": {}, "source": dedent(text).strip(),
                  "execution_count": None, "outputs": []})


md('''
# Logistic regression: from customer data to review strategies

**Audience:** learners comfortable with basic Python and pandas. Run cells in order using the shared project `.venv` kernel.

By the end, you should be able to explain a probability of default, fit a regularized logistic regression, read its validation results, and distinguish model selection from threshold selection.

This notebook follows the completed UCI credit-card exercise. It fits a fresh demonstration model **in memory**, reads saved experiments, and writes only to `notebooks/outputs/01_logistic_regression/`. It does not replace frozen models or rerun final test evaluation. Our test set has already been exposed; its saved results are historical evidence, not data for further tuning.

**Route:** data РІвЂ вЂ™ existing splits РІвЂ вЂ™ preprocessing РІвЂ вЂ™ fitting РІвЂ вЂ™ validation РІвЂ вЂ™ coefficients РІвЂ вЂ™ cross-validation РІвЂ вЂ™ calibration РІвЂ вЂ™ operating strategies. WoE modeling and points scorecards belong to later, optional notebooks.
''')
md('''
## 1. [RUN] Find the project and environment

The setup locates the project from the workspace, project, or notebook directory. It imports the same preprocessing recipe as the scripts. Verify the printed Python path ends in our shared `.venv/Scripts/python.exe`.
''')
code('''
from pathlib import Path
import os
import sys
import warnings

def locate_project():
    for parent in [Path.cwd(), *Path.cwd().parents]:
        for candidate in [parent, parent / "credit_logistic"]:
            if (candidate / "preprocessing.py").exists() and (candidate / "data/splits/train.csv").exists():
                return candidate
    raise FileNotFoundError("Open this notebook inside the exercise workspace.")

PROJECT = locate_project()
OUTPUT = PROJECT / "notebooks/outputs/01_logistic_regression"
OUTPUT.mkdir(parents=True, exist_ok=True)
os.environ["MPLCONFIGDIR"] = str(OUTPUT / "matplotlib_cache")
sys.path.insert(0, str(PROJECT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Image
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import (roc_auc_score, average_precision_score, log_loss,
                             confusion_matrix, precision_score, recall_score)
from preprocessing import CATEGORICAL, NUMERICAL, build_preprocessor

pd.set_option("display.max_columns", 12)
print("Python:", sys.executable)
print("Project:", PROJECT)
''')
md('''
## 2. [RUN] What are we predicting?

The dataset describes existing credit-card customers, not a new-applicant approval process. The target is next-month default: **1 = default; 0 = no default**. `ID` traces a row; it is not a predictor.

We inspect the training partition here. The original full-data inspection is in `01_inspect_data.py`; there is no need to reload the final test records for this lesson. Numerical storage does not make codes such as education continuous measurements.
''')
code('''
train = pd.read_csv(PROJECT / "data/splits/train.csv")
validation = pd.read_csv(PROJECT / "data/splits/validation.csv")
predictors = CATEGORICAL + NUMERICAL
display(train[["ID", "LIMIT_BAL", "AGE", "EDUCATION", "PAY_0", "default"]].head())
display(pd.DataFrame({"dtype": train.dtypes.astype(str),
                      "missing": train.isna().sum(), "distinct": train.nunique()}))
print("Training default rate:", f"{train.default.mean():.2%}")
''')
md('''
## 3. [RUN] Why preserve the existing splits?

Our approximately 60/20/20 split keeps identical original predictor profiles together. Matching profiles may be different people, even with different outcomes, so we retained all rows. The split uses seed 42 for reproducibility, not because that seed gave better results.

Training fits the model; validation supports development decisions; the test set was reserved for final evaluation. We do not resplit until we get attractive metrics. A historical random holdout is not an out-of-time assessment.
''')
code('''
display(pd.DataFrame([
    {"split": name, "records": len(frame), "defaults": int(frame.default.sum()),
     "default_rate": frame.default.mean()}
    for name, frame in [("train", train), ("validation", validation)]
]))
profiles_train = pd.MultiIndex.from_frame(train[predictors])
profiles_validation = pd.MultiIndex.from_frame(validation[predictors])
assert len(profiles_train.intersection(profiles_validation)) == 0
print("No identical original predictor profile crosses training and validation.")
''')
md('''
## 4. [RUN] Prepare features without leakage

Our fixed rules map education codes 0/5/6 to unknown code 0; marriage code 0 remains unknown. Documented 'other' stays separate. Repayment -2 and 0 remain distinct, without invented meanings. Negative bills are retained.

We one-hot encode nine categorical columns and standardize fourteen numerical columns. Standardization is `(value - training mean) / training standard deviation`. The encoder drops a reference category and learns its vocabulary from training only. Unseen validation codes receive all-zero encoding like the reference; the expected warning makes that limitation visible.
''')
code('''
preprocessor = build_preprocessor()
train_values = preprocessor.fit_transform(train[predictors])
validation_values = preprocessor.transform(validation[predictors])
columns = preprocessor.named_steps["columns"]
feature_names = columns.get_feature_names_out()
X_train = pd.DataFrame(train_values, columns=feature_names)
X_validation = pd.DataFrame(validation_values, columns=feature_names)
y_train = train["default"]
y_validation = validation["default"]
print("Prepared features:", len(feature_names))
display(X_train.iloc[:4, :8])
encoder = columns.named_transformers_["category"]
display(pd.DataFrame({"variable": CATEGORICAL,
                      "reference_code": [values[index] for values, index in zip(encoder.categories_, encoder.drop_idx_)]}))
''')
md(r'''
## 5. [RUN] What does logistic regression learn?

It forms a linear predictor $z=b_0+\sum_j b_jx_j$, then converts it to a probability with the sigmoid:

$$p(\text{default})=\frac{1}{1+e^{-z}}.$$

Log loss rewards accurate probabilities and penalizes confident mistakes. L2 regularization also discourages large coefficients. Smaller `C` means stronger regularization; it is not a classification threshold.

Our baseline uses `C=1`, `lbfgs`, no class weights, and up to 1,000 optimization iterations. Convergence means the optimizer finished, not that future predictions are guaranteed accurate.
''')
code('''
model = LogisticRegression(C=1.0, l1_ratio=0.0, solver="lbfgs",
                           class_weight=None, max_iter=1000)
with warnings.catch_warnings():
    warnings.simplefilter("error", ConvergenceWarning)
    model.fit(X_train, y_train)
probability = model.predict_proba(X_validation)[:, 1]
np.testing.assert_allclose(probability, expit(X_validation.to_numpy() @ model.coef_[0] + model.intercept_[0]))
print("Iterations:", model.n_iter_[0])
display(pd.DataFrame({"ID": validation.ID.head(), "probability": probability[:5],
                      "actual_default": y_validation.head()}))
''')
md('''
## 6. [RUN] Evaluate probabilities and decisions separately

ROC-AUC summarizes ranking. Average precision summarizes the precision-recall relationship. Log loss evaluates probabilities. Precision and recall require a threshold: here we initially flag probability >= 0.5.

**Precision:** of the customers flagged, how many defaulted? **Recall:** of all defaults, how many did we flag? Predicting no default for everyone has superficially high accuracy but zero recall.
''')
code('''
def evaluate(y, p, threshold=0.5):
    predicted = p >= threshold
    return {"roc_auc": roc_auc_score(y, p),
            "average_precision": average_precision_score(y, p),
            "log_loss": log_loss(y, p),
            "precision": precision_score(y, predicted, zero_division=0),
            "recall": recall_score(y, predicted, zero_division=0)}

metrics = pd.DataFrame([
    {"split": "train", **evaluate(y_train, model.predict_proba(X_train)[:, 1])},
    {"split": "validation", **evaluate(y_validation, probability)}
])
display(metrics.round(4))
display(pd.DataFrame(confusion_matrix(y_validation, probability >= 0.5),
                     index=["actual no default", "actual default"],
                     columns=["not flagged", "flagged"]))
metrics.to_csv(OUTPUT / "demonstration_metrics.csv", index=False)
''')
md('''
The recorded baseline had validation precision about 67% and recall about 36%: most alerts were correct, but many defaults were missed. Small train-validation gaps are reassuring, not proof against overfitting. The table above comes from the fresh demonstration fit; later sections read explicitly labeled saved experiments.

**Think about it:** if review is inexpensive, would a higher recall be worth more false alerts?
''')
md('''
## 7. [RUN] Read coefficients carefully

`exp(coefficient)` is an odds multiplier, holding other inputs fixedРІР‚вЂќnot a probability multiplier or causal effect. A numeric coefficient represents one training standard deviation; a category coefficient compares with its omitted reference.

Correlated monthly predictors and rare reference categories complicate interpretation. L2 does not make coefficients causal or eliminate those limitations.
''')
code('''
coefficients = pd.DataFrame({"feature": feature_names,
                             "coefficient": model.coef_[0],
                             "odds_ratio": np.exp(model.coef_[0])})
display(coefficients.head(12).round(4))
print("Intercept:", model.intercept_[0])
''')
md('''
## 8. [SAVED] Cross-validation selects model settings

**Saved experiment:** five grouped folds inside training; `C` in 0.01, 0.1, 1, 10. Every candidate uses the same folds. Each fit learns fresh preprocessing on four folds and evaluates the fifth. Average log loss chooses `C`, then the selected pipeline is refitted on all training rows.

Do not feed the already-prepared matrix into this procedure: its scaling and vocabulary would include held-out-fold information. The visible implementation is `experiments/02_tune_with_cross_validation.py`.

The five-fold standard deviation describes variation; it is not a confidence interval. Validation was not used to choose `C` in this search.
''')
code('''
cv = pd.read_csv(PROJECT / "reports/cross_validation/cv_summary.csv")
display(cv.round(6))
print("Selected C from lowest mean log loss:", cv.sort_values("mean_log_loss").iloc[0]["C"])
''')
md('''
The selected `C=1` matched our baseline. Cross-validation can confirm a starting choice without producing an improvement. Searching repeatedly until validation improves can still overfit development data.
''')
md('''
## 9. [SAVED] Calibration: do the probabilities match observed rates?

**Saved diagnostics:** the reliability plot groups validation predictions into common probability bands. Above the diagonal means underprediction; below means overprediction. Error bars describe approximate observed-rate uncertainty, not all uncertainty from fitting the model.

Brier score is mean squared probability error. It and log loss reflect more than calibration alone. ECE averages absolute gaps across chosen bins and depends on those bins. A constant prevalence prediction can have tiny ECE yet no ranking skill.

WoE appears here only as a saved comparison; its construction is reserved for notebook 02. We assessed calibration without fitting a calibrator.
''')
code('''
display(pd.read_csv(PROJECT / "reports/diagnostics/calibration_summary.csv").round(6))
display(Image(filename=str(PROJECT / "reports/diagnostics/calibration.png"), width=950))
''')
md('''
Both models slightly overpredicted overall defaults; their Brier scores were nearly identical. High-probability bands were sparse. These summaries alone did not justify automatically recalibrating either model.
''')
md('''
## 10. [RUN] Thresholds express an operating objective

We interpret a flag as a **review request**, not rejection or proof that an intervention prevents default. Lower thresholds usually increase recall and workload. Precision need not rise monotonically with threshold.

The following small calculation uses this notebook's fresh model. It is exploratory validation arithmetic only; it does not replace the frozen strategies.
''')
code('''
rows = []
for threshold in [0.1, 0.2, 0.3, 0.5, 0.7]:
    predicted = probability >= threshold
    tn, fp, fn, tp = confusion_matrix(y_validation, predicted).ravel()
    rows.append({"threshold": threshold, "precision": tp/(tp+fp) if tp+fp else 0,
                 "recall": tp/(tp+fn), "false_positive_rate": fp/(fp+tn),
                 "reviews": int(predicted.sum())})
thresholds = pd.DataFrame(rows)
display(thresholds.round(4))
ax = thresholds.plot(x="threshold", y=["precision", "recall"], marker="o",
                     figsize=(7, 3.5), ylim=(0, 1), title="Validation decision trade-off")
ax.set_ylabel("Proportion")
plt.show()
''')
md('''
## 11. [SAVED] The two frozen strategies

**Saved decisions:** protective targets at least 80% validation recall while minimizing false alerts. Growth-oriented limits the false-positive rate to 5% while maximizing detected defaults. FPR divides false alerts by actual non-defaultersРІР‚вЂќnot by all alerts.

Both existing models were considered on validation; the baseline won both objectives with different thresholds. Exact choices and model hashes were frozen before test evaluation. Growth-oriented is shorthand for fewer unnecessary reviews; this dataset does not measure revenue or approval growth.
''')
code('''
selected = pd.read_csv(PROJECT / "reports/strategies/validation_selected.csv")
display(selected[["strategy", "model", "threshold", "recall", "false_positive_rate", "precision", "alerts"]].round(6))
''')
md('''
## 12. [SAVED] Historical final test results РІР‚вЂќ read only

The original final evaluation is complete. This cell reads its saved report; it does not load test predictors, choose thresholds, or rerun inference. Do not use these results to tune the exercises above. Further development needs fresh independent evaluation.
''')
code('''
final_results = pd.read_csv(PROJECT / "reports/strategies/test_metrics.csv")
display(final_results[["strategy", "recall", "precision", "false_positive_rate", "alerts",
                       "true_positive", "false_positive", "false_negative"]].round(4))
''')
md('''
The protective policy detected about 83% of defaults but required reviewing about 55% of customers. The growth-oriented policy detected about 38%, with about 5% of non-defaulters flagged. Neither is universally preferable: objectives determine the trade-off.

## [EXERCISE] Review questions and optional exercises

1. Explain why `C` and the classification threshold change different things.
2. Why can a model have reasonable precision and low recall?
3. Why must scaling be refitted inside each cross-validation fold?
4. Inspect a different validation threshold in section 10. Describe the workload change without claiming better test performance.
5. Explain why small ECE does not guarantee a useful ranking model.

The next notebook will examine **binning, WoE and IV**. The third will optionally turn the WoE model into **points and customer explanations**. Both follow-on notebooks are available in this folder.

## Reference files

- `README.txt`: commands and sequence.
- `development_decisions.txt`: rationale and trade-offs.
- `step_objectives.txt`: learning objectives.
- `README.txt`: dated results and limitations.
- `README.txt`: scorecard methodology review and source links.

Technical references: [scikit-learn calibration](https://scikit-learn.org/stable/modules/calibration.html) and [SAS scorecard walkthrough](https://communities.sas.com/t5/SAS-Communities-Library/Credit-Scoring-by-Example-in-SAS-Enterprise-Miner/ta-p/234284).
''')

for index, cell in enumerate(cells):
    cell["id"] = f"lesson-{index:02d}"
notebook = {"cells": cells, "metadata": {
    "kernelspec": {"display_name": "Python (exercise .venv)", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.13.15"}}, "nbformat": 4, "nbformat_minor": 5}
(Path(__file__).resolve().parents[1] / "notebooks").joinpath("01_logistic_regression.ipynb").write_text(json.dumps(notebook, indent=1), encoding="utf-8")
