"""Build the optional points-scorecard lesson; execution is a separate check."""
import json
from pathlib import Path
from textwrap import dedent

cells = []


def md(text):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": dedent(text).strip()})


def code(text):
    cells.append({"cell_type": "code", "metadata": {}, "source": dedent(text).strip(),
                  "execution_count": None, "outputs": []})


md('''
# Optional: from WoE logistic regression to a points scorecard

**Objective:** express the existing WoE model as additive points, then explain one customer's calculation. This lesson changes presentation, not predictions.

You can stop after notebooks 01 and 02 and still have a complete logistic regression exercise. This optional notebook runs independently using saved artifacts; it does not require variables from previous kernels.

**Scope:** no fitting, bin revision, threshold selection, or test access. Our frozen review strategies selected the conventional baseline model. This scorecard represents the different WoE model and does not replace those strategies.

Route: probability Р Р†РІР‚В РІР‚в„ў odds Р Р†РІР‚В РІР‚в„ў points Р Р†РІР‚В РІР‚в„ў bin table Р Р†РІР‚В РІР‚в„ў customer contributions Р Р†РІР‚В РІР‚в„ў equivalence checks. All demonstration outputs stay under `notebooks/outputs/03_optional_scorecard/`.
''')
md('''
## 1. [RUN] Load the saved model and verify its identity

Use the shared `.venv` kernel. The scorecard definition records the source model's hash. Checking it helps prevent accidentally explaining a newer model with an older points table.
''')
code('''
from pathlib import Path
import os
import sys
import json
import hashlib
import importlib.util

def locate_project():
    for parent in [Path.cwd(), *Path.cwd().parents]:
        for candidate in [parent, parent / "credit_logistic"]:
            if (candidate / "woe.py").exists() and (candidate / "reports/scorecard/scorecard_definition.json").exists():
                return candidate
    raise FileNotFoundError("Open this notebook inside the exercise workspace after building the scorecard.")

PROJECT = locate_project()
OUTPUT = PROJECT / "notebooks/outputs/03_optional_scorecard"
OUTPUT.mkdir(parents=True, exist_ok=True)
os.environ["MPLCONFIGDIR"] = str(OUTPUT / "matplotlib_cache")
sys.path.insert(0, str(PROJECT))

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display
from scipy.special import expit
from woe import assign_bins, transform_woe

definition = json.loads((PROJECT / "reports/scorecard/scorecard_definition.json").read_text())
model_file = PROJECT / "models/woe/logistic_woe.joblib"
assert hashlib.sha256(model_file.read_bytes()).hexdigest() == definition["source_sha256"]
bundle = joblib.load(model_file)
model = bundle["model"]
assert list(model.classes_) == [0, 1]
assert definition["features"] == list(model.feature_names_in_) == bundle["features"]
assert definition["binning_rules"] == bundle["rules"]
print("Python:", sys.executable)
print("Verified saved WoE model and scorecard rules.")
''')
md(r'''
## 2. [RUN] Probability and odds are different

If $p$ is default probability, default/non-default odds are $p/(1-p)$. Our points scale uses the reverse: **non-default/default odds**, $(1-p)/p$.

20:1 odds means 20 non-defaults per default in the implied probability distribution, so $p=1/(20+1)$, about 4.76%. It does not mean a guarantee about any individual customer.

The approved convention is **600 points at 20:1 odds**, with **20 points to double those odds (PDO)**. Higher points mean lower predicted risk. Doubling odds does not exactly halve the probability.
''')
code('''
BASE_SCORE = definition["base_score"]
BASE_ODDS = definition["base_good_bad_odds"]
PDO = definition["points_to_double_odds"]
examples = pd.DataFrame({"non_default_to_default_odds": [10, 20, 40, 80]})
examples["default_probability"] = 1 / (1 + examples.non_default_to_default_odds)
examples["score"] = BASE_SCORE + PDO * np.log2(examples.non_default_to_default_odds / BASE_ODDS)
display(examples)
''')
md(r'''
## 3. [RUN] Derive the scaling formula

Let $z=b_0+sum_j b_j WoE_j$ be the saved model's log **default/non-default** odds. Good/bad log odds are therefore $-z$.

$$F=PDO/ln(2),quad A=S_0-Fln(O_0),quad S=A-Fz.$$

Here $F$ is the factor, $A$ the offset, and $(S_0,O_0)$ the base-score/base-odds pair. Inverting gives $p=operatorname{sigmoid}((A-S)/F)$.

The offset and the model's shared base contribution are different quantities. Keep the intercept contribution separate so it is counted only once.
''')
code('''
factor = PDO / np.log(2)
offset = BASE_SCORE - factor * np.log(BASE_ODDS)
base_points = offset - factor * float(model.intercept_[0])
np.testing.assert_allclose([factor, offset, base_points],
                          [definition["factor"], definition["offset"], definition["base_points"]])
display(pd.Series({"factor": factor, "offset": offset, "model_intercept": model.intercept_[0],
                   "shared_base_points": base_points}))
np.testing.assert_allclose(expit((offset-600)/factor), 1/21)
np.testing.assert_allclose(expit((offset-620)/factor), 1/41)
''')
md('''
## 4. [RUN] Inspect the score/probability relationship

The curve is just a different representation of probabilities. It does not add information or improve AUC. The plotted range is illustrative, not a clipping rule or an approved score band.
''')
code('''
illustrative_scores = np.linspace(350, 750, 250)
fig, ax = plt.subplots(figsize=(8, 3.5))
ax.plot(illustrative_scores, expit((offset-illustrative_scores)/factor))
ax.scatter([600, 620], [1/21, 1/41], color="darkorange", zorder=3)
ax.set(xlabel="Score points (illustrative range)", ylabel="Predicted default probability",
       title="Higher points represent lower predicted risk")
ax.grid(alpha=0.2)
plt.show()
''')
md(r'''
## 5. [RUN] Build the feature points table visibly

For each feature's assigned bin, its contribution is $-F b_j WoE_j$. The total is **shared base points + all 23 feature contributions**. Points can be fractional or negative; we do not cap them or round during calculation.

The saved definition holds the full-precision contributions. Here we calculate them independently from the fitted coefficients and WoE values and check agreement. Unseen categorical values use neutral WoE=0, hence zero contribution.
''')
code('''
rows = []
for feature, coefficient in zip(bundle["features"], model.coef_[0]):
    rule = bundle["rules"]["features"][feature]
    for bin_id, woe_value in rule["woe_by_bin"].items():
        points = -factor * coefficient * woe_value
        np.testing.assert_allclose(points, definition["points_by_feature_bin"][feature][bin_id])
        rows.append({"feature": feature, "bin": bin_id, "woe": woe_value,
                     "coefficient": coefficient, "points": points})
points_table = pd.DataFrame(rows)
print("Learned bin contributions:", len(points_table))
display(points_table.loc[points_table.feature == "PAY_0"].round(4))
''')
md('''
## 6. [RUN] Select one validation customer

Change `CUSTOMER_ID` to an ID present in the validation split, then rerun the cells below. The default is customer 1. Their actual outcome is not used to calculate the score or construct its explanation.

An ID absent from validation produces an explicit error rather than silently switching to a different customer or the test set.
''')
code('''
CUSTOMER_ID = 1
validation = pd.read_csv(PROJECT / "data/splits/validation.csv")
customer = validation.loc[validation.ID == CUSTOMER_ID]
if len(customer) != 1:
    raise ValueError("Choose exactly one customer ID from data/splits/validation.csv.")
display(customer[["ID", "LIMIT_BAL", "AGE", "EDUCATION", "PAY_0"]])
''')
md('''
## 7. [RUN] Trace values through bins, WoE and points

Reuse the checked explanation function from file 09. Loading that module does not call its `main()` or write its reports. The table retains original and mapped values, shows the assigned category/interval, and flags unseen fallbacks.

Education 5/6 maps to 0; education/marriage 0 means unknown/undocumented. Repayment -2/0 remain uninterpreted codes. Positive contributions raise the score; negative contributions lower it. These are contributions relative to the shared baseР Р†Р вЂљРІР‚Сњnot deviations from an average or ideal customer.
''')
code('''
spec = importlib.util.spec_from_file_location("customer_explanation",
    PROJECT / "experiments/09_explain_customer_score.py")
explanation_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(explanation_module)
contributions, total_score, score_probability = explanation_module.explain_customer(customer, definition, bundle)
display(contributions.round({"woe": 5, "coefficient": 5, "points": 2}))
display(pd.Series({"shared_base_points": base_points,
                   "sum_feature_points": contributions.points.sum(),
                   "total_score": total_score,
                   "predicted_default_probability": score_probability}))
print("Unseen category fallbacks:", int(contributions.unseen_fallback.sum()))
''')
md('''
## 8. [RUN] Visualize all contributions

The bars show arithmetic contributions, not causal explanations, adverse-action codes, or advice about what the customer should change. Correlated predictors can make individual conditional effects difficult to interpret. The shared base contribution is not plotted as another variable.
''')
code('''
ordered = contributions.sort_values("points")
colors = np.where(ordered.points >= 0, "#147d73", "#b55332")
fig, ax = plt.subplots(figsize=(9, 7), layout="constrained")
ax.barh(ordered.feature, ordered.points, color=colors)
ax.axvline(0, color="black", linewidth=0.8)
ax.set(xlabel="Feature points: negative lowers score, positive raises score",
       title=f"Customer {CUSTOMER_ID}: contributions relative to shared base")
ax.text(0.02, 0.98, f"Base {base_points:.2f} + contributions {contributions.points.sum():.2f}\\nTotal {total_score:.2f} points",
        transform=ax.transAxes, ha="left", va="top", fontsize=9,
        bbox={"facecolor": "white", "alpha": 0.9, "edgecolor": "lightgray"})
plt.show()
''')
md('''
## 9. [RUN] Verify the calculation, not just the display

First sum full-precision points and invert the scale. Then independently ask the saved logistic model for its probability. Display rounding can make visible rows sum slightly differently; never use rounded points for verification.
''')
code('''
X_customer, _ = transform_woe(customer[bundle["features"]], bundle["rules"])
direct_probability = float(model.predict_proba(X_customer)[0, 1])
sum_score = base_points + contributions.points.sum()
recovered_probability = float(expit((offset-sum_score)/factor))
np.testing.assert_allclose(sum_score, total_score, atol=1e-10, rtol=0)
np.testing.assert_allclose(recovered_probability, direct_probability, atol=1e-12, rtol=0)
print("Score probability:", recovered_probability)
print("Model probability:", direct_probability)
print("Absolute difference:", abs(recovered_probability-direct_probability))
print("Sum of displayed, two-decimal feature points:", contributions.points.round(2).sum())
''')
md('''
## 10. [RUN] Check equivalence across validation records

This is an arithmetic check, not a new performance evaluation. Apply the saved bin-points lookup to every validation row, then compare with the model probabilities. No test records or outcomes enter this check.
''')
code('''
raw = validation[bundle["features"]]
mapping = {int(k): v for k, v in bundle["rules"]["education_mapping"].items()}
mapped = raw.replace({"EDUCATION": mapping})
all_scores = np.full(len(raw), base_points)
for feature in bundle["features"]:
    rule = definition["binning_rules"]["features"][feature]
    assigned = assign_bins(mapped[feature], rule)
    feature_points = assigned.map(definition["points_by_feature_bin"][feature])
    if rule["kind"] == "numeric" and feature_points.isna().any():
        raise ValueError(f"Missing numeric bin points for {feature}.")
    all_scores += feature_points.fillna(definition["unseen_category_points"]).to_numpy()
X_validation, unseen = transform_woe(raw, bundle["rules"])
all_probabilities = expit((offset-all_scores)/factor)
expected = model.predict_proba(X_validation)[:, 1]
np.testing.assert_allclose(all_probabilities, expected, atol=1e-12, rtol=0)
print("Validation records checked:", len(raw))
print("Maximum absolute probability difference:", np.max(abs(all_probabilities-expected)))
display(pd.DataFrame(unseen))
''')
md('''
## 11. [RUN] Understand fallback and input limitations

An unseen category produces zero contribution, not evidence of low risk. Here we deliberately create a synthetic unseen sex code to inspect that fallback; this is not a real customer edit or a recommendation. Missing data still raises an error instead of silently receiving neutral evidence.

The 36 flagged WoE bins remain flagged. Points scaling cannot repair sparse estimates, unexpected conditional signs, or probability miscalibration.
''')
code('''
synthetic = customer.copy()
synthetic["SEX"] = 99
fallback_table, _, _ = explanation_module.explain_customer(synthetic, definition, bundle)
display(fallback_table.loc[fallback_table.feature == "SEX"])
assert fallback_table.loc[fallback_table.feature == "SEX", "unseen_fallback"].iloc[0]
assert fallback_table.loc[fallback_table.feature == "SEX", "points"].iloc[0] == 0
''')
md('''
## 12. [RUN] Save demonstration outputs separately

These files are for this lesson only. The original scorecard definition, customer reports and operating strategies are not overwritten. There is deliberately no protective/growth flag: those policies belong to the conventional baseline model.
''')
code('''
points_table.to_csv(OUTPUT / "demonstration_points_table.csv", index=False)
contributions.to_csv(OUTPUT / f"customer_{CUSTOMER_ID}_contributions.csv", index=False)
summary = {"customer_id": CUSTOMER_ID, "model": "saved WoE logistic regression",
           "base_points": float(base_points), "feature_points": float(contributions.points.sum()),
           "total_score": total_score, "default_probability": score_probability,
           "source_model_sha256": definition["source_sha256"]}
(OUTPUT / f"customer_{CUSTOMER_ID}_summary.json").write_text(
    json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8")
print("Lesson outputs:", OUTPUT)
''')
md('''
## [EXERCISE] Review questions

1. Why do we subtract the model's log odds when higher score means lower default risk?
2. Explain why 20 more points doubles non-default/default odds but does not exactly halve default probability.
3. What is the difference between offset and shared base points?
4. Why should we retain full precision even if the score is shown as an integer?
5. Why is zero fallback contribution not a statement that an unseen category is safe?
6. Why cannot the baseline review thresholds simply be reused on this different model?

**Optional exercise:** choose another validation ID and trace its bins. Do not interpret contribution changes as causal effects or use the exposed test set for tuning.

## What is now complete?

The three lessons distinguish conventional logistic regression, WoE representation, and optional points presentation. The regression exercise remains complete without this notebook. Real deployment would require additional decisions and evidence beyond an educational historical dataset; no deployment or credit action is implied here.

Reference implementation: `experiments/08_build_scorecard.py` and `experiments/09_explain_customer_score.py`. Read `development_decisions.txt`, `step_objectives.txt`, and `README.txt` for the recorded scope and trade-offs.
''')

for i, cell in enumerate(cells):
    cell["id"] = f"scorecard-lesson-{i:02d}"
notebook = {"cells": cells, "metadata": {
    "kernelspec": {"display_name": "Python (exercise .venv)", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.13.15"}}, "nbformat": 4, "nbformat_minor": 5}
(Path(__file__).resolve().parents[1] / "notebooks").joinpath("03_optional_scorecard.ipynb").write_text(json.dumps(notebook, indent=1), encoding="utf-8")
