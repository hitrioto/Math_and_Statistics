"""Build the WoE teaching notebook; execute separately to save checked outputs."""
import json
from pathlib import Path
from textwrap import dedent

cells = []


def md(text):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": dedent(text).strip()})


def code(text):
    cells.append({"cell_type": "code", "metadata": {}, "source": dedent(text).strip(),
                  "execution_count": None, "outputs": []})


md('''
# WoE logistic regression: bins, evidence and interpretation

**Prerequisite:** notebook 01's treatment of logistic regression, validation and thresholds. This notebook runs independently from a fresh kernel; it does not need variables from notebook 01.

**Objectives:** inspect bins, calculate weight of evidence (WoE) and information value (IV), fit a WoE model, and interpret its comparison with the conventional baseline.

We reuse the original train/validation membership and shared `woe.py` calculations. Demonstration objects are fitted in memory. Outputs go only into `notebooks/outputs/02_woe_logistic_regression/`. No frozen models, reports or strategies are overwritten; no test data is loaded. The historical test set is already exposed and cannot guide new tuning.

Points scaling is different from WoE encoding and belongs to the third, optional notebookРІР‚вЂќnot this lesson.
''')
md('''
## 1. [RUN] Set up an independent session

Use the shared `.venv` kernel and run all cells in order. The original split files and saved baseline reports must exist. The first print identifies the Python interpreter actually running this notebook.
''')
code('''
from pathlib import Path
import os
import sys
import json
import warnings

def locate_project():
    for parent in [Path.cwd(), *Path.cwd().parents]:
        for candidate in [parent, parent / "credit_logistic"]:
            if (candidate / "woe.py").exists() and (candidate / "data/splits/train.csv").exists():
                return candidate
    raise FileNotFoundError("Open the notebook inside the exercise workspace.")

PROJECT = locate_project()
OUTPUT = PROJECT / "notebooks/outputs/02_woe_logistic_regression"
OUTPUT.mkdir(parents=True, exist_ok=True)
os.environ["MPLCONFIGDIR"] = str(OUTPUT / "matplotlib_cache")
sys.path.insert(0, str(PROJECT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import (roc_auc_score, average_precision_score, log_loss,
                             brier_score_loss, confusion_matrix, precision_score, recall_score)
from sklearn.calibration import calibration_curve
from preprocessing import CATEGORICAL, NUMERICAL, CATEGORY_MAPPING
from woe import fit_woe, transform_woe

print("Python:", sys.executable)
print("Project:", PROJECT)
''')
md('''
## 2. [RUN] One-hot encoding versus WoE

One-hot encoding creates category indicators without looking at outcomes. WoE replaces each category or numerical bin with one number derived from its training class counts. Our model therefore has **one coefficient per original predictor**.

WoE is supervised: learning it on validation would leak outcomes. Also, 23 fitted coefficients do not mean only 23 learned quantitiesРІР‚вЂќthe bins and their WoE estimates are part of the learned representation.

We retain all records and all 23 predictors. Education 0/5/6 maps to unknown code 0, marriage 0 remains unknown, and documented 'other' stays separate. Repayment -2/0 remain distinct codes without invented meanings.
''')
code('''
train = pd.read_csv(PROJECT / "data/splits/train.csv")
validation = pd.read_csv(PROJECT / "data/splits/validation.csv")
predictors = CATEGORICAL + NUMERICAL
display(pd.DataFrame([
    {"split": name, "records": len(data), "default_rate": data.default.mean()}
    for name, data in [("train", train), ("validation", validation)]
]))
display(train[["EDUCATION", "MARRIAGE", "PAY_0", "LIMIT_BAL", "default"]].head())
print("Fixed mapping:", CATEGORY_MAPPING)
''')
md('''
## 3. [RUN] Learn bins from training only

We use up to five quantile bins for numerical variables. Tied values can reduce the number of bins and prevent exactly equal counts. Outer bins extend to negative and positive infinity so finite future extremes remain assignable.

Categorical codes retain their agreed groups. We flag bins below 1% of training records, with fewer than 20 defaults, **or** fewer than 20 non-defaults. These are teaching heuristics, not universal thresholds. We do not merge bins automatically or force monotonic trends.
''')
code('''
MAX_BINS = 5
SMOOTHING = 0.5
rules, bins = fit_woe(train[predictors], train["default"], max_bins=MAX_BINS, smoothing=SMOOTHING)
print("Bins:", len(bins), "| flagged:", int(bins.needs_review.sum()))
display(bins.loc[bins.feature == "LIMIT_BAL", ["description", "records", "defaults", "default_rate", "woe", "needs_review"]])
assert bins.groupby("feature").records.sum().eq(len(train)).all()
''')
md(r'''
## 4. [RUN] Work through one bin's WoE

For bin $i$, let $g_i$ be non-defaults, $b_i$ defaults, and $G,B$ the corresponding totals. With $K$ bins and smoothing $a=0.5$:

$$s_{g,i}=\frac{g_i+a}{G+Ka},\qquad s_{b,i}=\frac{b_i+a}{B+Ka},\qquad WoE_i=\ln\left(\frac{s_{g,i}}{s_{b,i}}\right).$$

These are each bin's **shares of the two classes**, not its within-bin default rate. Positive WoE means relatively more non-defaults; negative means relatively more defaults.

We add smoothing to both class counts in **every** bin and adjust both totals consistently. This prevents infinite values but does not make rare estimates reliable.
''')
code('''
feature_bins = bins.loc[bins.feature == "PAY_0"].copy()
example = feature_bins.loc[feature_bins["bin"] == "2"].iloc[0]
K = len(feature_bins)
total_bad = int(train.default.sum())
total_good = len(train) - total_bad
good_share = (example.non_defaults + SMOOTHING) / (total_good + K*SMOOTHING)
bad_share = (example.defaults + SMOOTHING) / (total_bad + K*SMOOTHING)
manual_woe = np.log(good_share / bad_share)
display(pd.Series({"non_defaults_in_bin": example.non_defaults, "defaults_in_bin": example.defaults,
                   "within_bin_default_rate": example.default_rate,
                   "share_of_non_defaults": good_share, "share_of_defaults": bad_share,
                   "calculated_woe": manual_woe}))
np.testing.assert_allclose(manual_woe, example.woe)
np.testing.assert_allclose([feature_bins.non_default_share.sum(), feature_bins.default_share.sum()], [1, 1])
''')
md('''
**A tiny zero-count example:** a category with two non-defaults and no defaults would have infinite unsmoothed WoE. With two bins, two customers of each class overall, and 0.5 smoothing, its class shares are 2.5/3 and 0.5/3. The resulting WoE is ln(5), finite but supported by very few observations.
''')
code('''
toy_woe = np.log(((2 + 0.5)/(2 + 2*0.5)) / ((0 + 0.5)/(2 + 2*0.5)))
print("Smoothed WoE:", toy_woe)
np.testing.assert_allclose(toy_woe, np.log(5))
''')
md(r'''
## 5. [RUN] IV describes one variable's separation

$$IV=\sum_i(s_{g,i}-s_{b,i})WoE_i.$$

We use IV as descriptive training evidence, not an automatic feature-deletion rule. It does not measure held-out predictive performance, and correlated monthly variables can repeat information. High IV is a reason to understand a predictor and its timing, not proof it will generalize.
''')
code('''
manual_iv = ((feature_bins.non_default_share - feature_bins.default_share) * feature_bins.woe).sum()
np.testing.assert_allclose(manual_iv, feature_bins.iv_contribution.sum())
iv = bins.groupby("feature", as_index=False).agg(
    information_value=("iv_contribution", "sum"), bin_count=("bin", "size"),
    flagged_bins=("needs_review", "sum")).sort_values("information_value", ascending=False)
display(iv.round(5))
''')
md('''
## 6. [RUN] Review the bins, not just IV

The plot shows training default rates by ordered numerical interval. A smooth monotonic pattern is not imposed. Inspect both rates and sample counts before considering any merging. Sparse categorical bins are listed separately below.
''')
code('''
limit_bins = bins.loc[bins.feature == "LIMIT_BAL"].sort_values("bin", key=lambda s:s.astype(int))
fig, axes = plt.subplots(1, 2, figsize=(11, 3.5), layout="constrained")
axes[0].plot(range(len(limit_bins)), limit_bins.default_rate, marker="o")
axes[0].set(xlabel="LIMIT_BAL bin (ascending)", ylabel="Observed training default rate",
            title="Training risk pattern")
axes[1].bar(range(len(limit_bins)), limit_bins.records)
axes[1].set(xlabel="LIMIT_BAL bin (ascending)", ylabel="Records", title="Evidence per bin")
plt.show()
display(bins.loc[bins.needs_review, ["feature", "description", "records", "defaults", "non_defaults", "woe"]].head(15))
print("All flagged bins retained for this approved initial model.")
''')
md('''
## 7. [RUN] Transform validation using the saved training rules

Validation labels are never passed to the transformer. Unseen categories receive neutral WoE=0 and are reported. Neutral fallback is not evidence that a customer is safe. Missing values require a separate policy; the current data contains no missing cells.

We also check a JSON roundtrip: rules should be reusable rather than dependent on notebook state.
''')
code('''
X_train, unseen_train = transform_woe(train[predictors], rules)
restored_rules = json.loads(json.dumps(rules, allow_nan=False))
X_validation, unseen_validation = transform_woe(validation[predictors], restored_rules)
assert not unseen_train
assert np.isfinite(X_train.to_numpy()).all() and np.isfinite(X_validation.to_numpy()).all()
display(X_train.head())
display(pd.DataFrame(unseen_validation))
print("WoE feature count:", X_train.shape[1])
''')
md('''
## 8. [RUN] Fit the initial WoE logistic regression

Use all 23 unscaled features, L2, `C=1`, `lbfgs`, and no class weights. This matches the initial baseline settings, but the same C does not impose equivalent regularization across differently scaled feature representations.

No bins are revised here and no parameter search is performed. Training performance is optimistic because those outcomes helped construct the WoE mapping as well as fit the regression.
''')
code('''
model = LogisticRegression(C=1.0, l1_ratio=0.0, solver="lbfgs", class_weight=None, max_iter=1000)
with warnings.catch_warnings():
    warnings.simplefilter("error", ConvergenceWarning)
    model.fit(X_train, train.default)
probability = model.predict_proba(X_validation)[:, 1]
np.testing.assert_allclose(probability, expit(X_validation.to_numpy() @ model.coef_[0] + model.intercept_[0]))
print("Converged in", model.n_iter_[0], "iterations")
''')
md('''
## 9. [RUN] Compare validation results with the conventional baseline

The WoE rows below are calculated in this notebook. The conventional baseline rows are read from the completed exercise. Customer IDs and actual outcomes are checked for matching validation membership.

We compare probabilities and threshold-dependent metrics. A slightly higher AUC does not necessarily produce higher recall at threshold 0.5.
''')
code('''
def evaluate(y, p):
    predicted = p >= 0.5
    return {"roc_auc": roc_auc_score(y, p), "average_precision": average_precision_score(y, p),
            "log_loss": log_loss(y, p), "precision": precision_score(y, predicted, zero_division=0),
            "recall": recall_score(y, predicted, zero_division=0)}

baseline_predictions = pd.read_csv(PROJECT / "reports/baseline/validation_predictions.csv")
pd.testing.assert_frame_equal(baseline_predictions[["ID", "default"]], validation[["ID", "default"]])
baseline = pd.read_csv(PROJECT / "reports/baseline/metrics.csv")
metric_names = ["roc_auc", "average_precision", "log_loss", "precision", "recall"]
woe_metrics = pd.DataFrame([
    {"split": "train", **evaluate(train.default, model.predict_proba(X_train)[:, 1])},
    {"split": "validation", **evaluate(validation.default, probability)}])
comparison = pd.concat([baseline[["split"]+metric_names].assign(model="baseline (saved)"),
                        woe_metrics.assign(model="woe (notebook)")], ignore_index=True)
display(comparison.round(4))
display(pd.DataFrame(confusion_matrix(validation.default, probability >= 0.5),
                     index=["actual no default", "actual default"], columns=["not flagged", "flagged"]))
''')
md('''
In the recorded comparison, WoE slightly improved validation AUC and log loss, while precision and recall at 0.5 were lower. That is a mixed result, not a clear winner. These small differences have not been established as statistically reliable.

Our final protective and growth-oriented strategies selected the conventional baseline. This notebook does not revisit their selection or access the exposed test set.
''')
md('''
## 10. [RUN] Interpret conditional coefficients

Positive WoE represents relatively more non-defaults, so negative regression coefficients are generally expected for default=1. Correlated inputs can produce positive conditional coefficients. We flag them for inspection rather than forcing signs or removing predictors.

`exp(coefficient)` is the odds multiplier for a one-unit increase in WoE, holding other inputs fixed. It is neither a probability multiplier nor a causal explanation. This unit is not one year of age or one currency unit.
''')
code('''
coefficients = pd.DataFrame({"feature": predictors, "coefficient": model.coef_[0],
                             "odds_ratio_per_woe_unit": np.exp(model.coef_[0])})
display(coefficients.round(5))
display(coefficients.loc[coefficients.coefficient > 0])
print("Training correlation of BILL_AMT1 and BILL_AMT2 WoE:", X_train.BILL_AMT1.corr(X_train.BILL_AMT2))
''')
md('''
## 11. [RUN] Check probability reliability

We calculate validation Brier scores and reliability curves for the fresh WoE fit and saved baseline. The curves use ten common equal-width probability bands; empty bands are omitted. Counts show why sparse high-risk bands need caution. This simple plot does not show confidence intervals; the completed diagnostic report includes them.

Brier and log loss are not pure calibration measures. Better calibration also does not guarantee better ranking. We assess, but do not fit a calibrator here.
''')
code('''
fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")
axes[0].plot([0, 1], [0, 1], "--", color="gray", label="Perfect calibration")
for label, p in [("Baseline (saved)", baseline_predictions.default_probability), ("WoE (notebook)", probability)]:
    observed, predicted = calibration_curve(validation.default, p, n_bins=10, strategy="uniform")
    axes[0].plot(predicted, observed, marker="o", label=label)
    axes[1].hist(p, bins=np.linspace(0, 1, 11), histtype="step", linewidth=2, label=label)
    print(label, "Brier:", round(brier_score_loss(validation.default, p), 6))
axes[0].set(xlabel="Mean predicted probability", ylabel="Observed default rate", xlim=(0, 1), ylim=(0, 1))
axes[1].set(xlabel="Predicted probability", ylabel="Validation customers")
for ax in axes:
    ax.legend()
    ax.grid(alpha=0.2)
plt.show()
''')
md('''
## 12. [RUN] Why future WoE cross-validation must start from raw features

For each training fold: learn numerical boundaries, calculate WoE with that fold's outcomes, transform the held-out fold, then fit/evaluate the model appropriately. More precisely, fit the classifier on the transformed fitting fold and evaluate its predictions on the transformed held-out fold.

**Do not run CV on `X_train` above.** Its WoE values already contain outcomes from all training records, including the rows a CV split would hold out. Even the unsupervised numerical boundaries should be learned inside each fitting fold.

This notebook does not add WoE tuning. It preserves the approved initial comparison, avoiding a new search against the already-exposed test results.
''')
md('''
## 13. [RUN] Save demonstration tables separately

These exports belong only to this lesson. The existing model bundles, points tables and final strategy reports stay untouched.
''')
code('''
bins.to_csv(OUTPUT / "demonstration_bin_table.csv", index=False)
iv.to_csv(OUTPUT / "demonstration_information_value.csv", index=False)
comparison.to_csv(OUTPUT / "demonstration_comparison.csv", index=False)
coefficients.to_csv(OUTPUT / "demonstration_coefficients.csv", index=False)
print("Saved lesson tables to", OUTPUT)
''')
md('''
## [EXERCISE] Questions to consolidate the lesson

1. Why does WoE require class-distribution shares instead of just the bin's default rate?
2. What does 0.5 smoothing fix, and what uncertainty does it leave?
3. Why can a high-IV variable add little information alongside another variable?
4. Explain the leakage if you cross-validate the precomputed WoE matrix.
5. Why can WoE improve AUC but lower recall at the same numerical threshold?
6. Pick a flagged bin and describe what evidence you would want before merging it. Do not choose merges by checking final test performance.

**Next, optionally:** turn this fitted representation into scorecard points and customer explanations. Scaling points does not improve predictions; it changes presentation. That material is reserved for notebook 03, which is available as the optional next lesson.

Reference implementation: `woe.py`, `experiments/03_prepare_woe.py`, and `experiments/04_train_woe_logistic.py`. See `development_decisions.txt` and `README.txt` for trade-offs and methodological references.
''')

for i, cell in enumerate(cells):
    cell["id"] = f"woe-lesson-{i:02d}"
notebook = {"cells": cells, "metadata": {
    "kernelspec": {"display_name": "Python (exercise .venv)", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.13.15"}}, "nbformat": 4, "nbformat_minor": 5}
(Path(__file__).resolve().parents[1] / "notebooks").joinpath("02_woe_logistic_regression.ipynb").write_text(json.dumps(notebook, indent=1), encoding="utf-8")
